(function () {



/* Exports */
Package._define("coffeescript");

})();
