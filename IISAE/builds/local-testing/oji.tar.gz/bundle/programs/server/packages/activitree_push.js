(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var EJSON = Package.ejson.EJSON;
var Random = Package.random.Random;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"activitree:push":{"lib":{"server":{"pushToDevice.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/activitree_push/lib/server/pushToDevice.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Push;
module.link("./pushToDB", {
  Push(v) {
    Push = v;
  }

}, 1);
let sendNotification;
module.link("./notification", {
  sendNotification(v) {
    sendNotification = v;
  }

}, 2);

Push.setBadge = function () {
  /* throw new Error('Push.setBadge not implemented on the server' */
};

let isConfigured = false;

const sendWorker = (task, interval, isDebug) => {
  if (isDebug) {
    console.log('Push: Send worker started, using interval: ' + interval);
  }

  return Meteor.setInterval(() => {
    try {
      task();
    } catch (error) {
      if (isDebug) {
        console.log('Push: Error while sending:', error.message);
      }
    }
  }, interval);
};

Push.Configure = serverConfig => {
  const isDebug = Push.debug;
  const self = this;

  if (isConfigured) {
    throw new Error('Push.Configure should not be called more than once!');
  }

  isConfigured = true;

  if (isDebug) {
    console.log('Push.Configure', serverConfig);
  } // Rig FCM connection


  const admin = require('firebase-admin');

  const fcm = admin.initializeApp({
    credential: admin.credential.cert(serverConfig.firebaseAdmin && serverConfig.firebaseAdmin.serviceAccountData),
    databaseURL: serverConfig.firebaseAdmin && serverConfig.firebaseAdmin.databaseURL
  });
  const fcmConnections = fcm.messaging(); // FCM with Firebase Admin

  if (serverConfig.firebaseAdmin) {
    if (isDebug) {
      console.log('Firebase Admin for Android Messaging configured');
    }

    if (!serverConfig.firebaseAdmin.serviceAccountData) {
      console.error('ERROR: Push server could not find Android serviceAccountData information');
    }

    if (!serverConfig.firebaseAdmin.databaseURL) {
      console.error('ERROR: Push server could not find databaseURL information');
    }

    self.sendNotification = (userTokens, mongoNote) => sendNotification(isDebug, fcmConnections, serverConfig.defaults, userTokens, mongoNote);
  }
  /**
   * 'querySend' functions distributes the notifications to be send with the right
   * providers based on the tokens they are send to
   */


  const querySend = (query, mongoNote) => {
    const countApn = [];
    const countAndroid = [];
    const countWeb = [];
    Push.appCollection.find(query).map(app => {
      if (isDebug) {
        console.log('Send to token', app.token);

        if (app.token.apn) {
          countApn.push('x');
        }

        if (app.token.android) {
          countAndroid.push('x');
        }

        if (app.token.web) {
          countWeb.push('x');
        }
      }

      self.sendNotification(app.token.apn || app.token.android || app.token.web, mongoNote);
    });

    if (isDebug) {
      console.log('Push: Sent message "' + mongoNote.title + '" to ' + countApn.length + ' ios apps | ' + countAndroid.length + ' android apps | ', countWeb.length, ' web apps'); // Add some verbosity about the send result, making sure the developer
      // understands what just happened.

      if (!countApn.length && !countAndroid.length && !countWeb.length) {
        if (!Push.appCollection.findOne()) {
          console.log('Push, GUIDE: The "Push.appCollection" might be empty. No clients have registered on the server yet...');
        }
      } else if (!countApn.length) {
        if (!Push.appCollection.findOne({
          'token.apn': {
            $exists: true
          }
        })) {
          console.log('Push, GUIDE: The "Push.appCollection" - No APN clients have registred on the server yet...');
        }
      } else if (!countAndroid.length) {
        if (!Push.appCollection.findOne({
          'token.android': {
            $exists: true
          }
        })) {
          console.log('Push, GUIDE: The "Push.appCollection" - No ANDROID clients have registered on the server yet...');
        }
      } else if (!countWeb.length) {
        if (!Push.appCollection.findOne({
          'token.web': {
            $exists: true
          }
        })) {
          console.log('Push, GUIDE: The "Push.appCollection" - No Web clients have registered on the server yet...');
        }
      }
    }

    return {
      apn: countApn,
      fcm: countAndroid,
      wen: countWeb
    };
  };
  /**
   *Constructs a query and passed it as parameter on 'querySend' function
   * mongoNote = the gross notification saved into Mongo, before serialization for the two Providers, APN and Android
   */


  self.serverSend = mongoNote => {
    let query; // set some minimum requirements for a notification to be eligible for sending.
    // TODO implement some checking for data. Perhaps not right here but once implemented remove the next 2 lines

    if (mongoNote.title !== '' + mongoNote.title) {
      throw new Error('Push.send: option "title" not a string');
    }

    if (mongoNote.body !== '' + mongoNote.body) {
      throw new Error('Push.send: option "text" not a string');
    }

    if (mongoNote.token || mongoNote.tokens) {
      const tokenList = mongoNote.token ? [mongoNote.token] : mongoNote.tokens;

      if (isDebug) {
        console.log('Push: Send message "' + mongoNote.title + '" via token(s)', tokenList);
      }

      query = {
        token: {
          $in: tokenList
        },
        enabled: {
          $ne: false
        }
      };
    } else if (mongoNote.tokenId || mongoNote.tokenIds) {
      const tokenIdsList = mongoNote.tokenId ? [mongoNote.tokenId] : mongoNote.tokenIds;

      if (isDebug) {
        console.log('Push: Send message "' + mongoNote.title + '" via token Id(s)', tokenIdsList);
      }

      query = {
        _id: {
          $in: tokenIdsList
        },
        enabled: {
          $ne: false
        }
      };
      /*
      query = {
        $or: [
          {
            $and: [
              { token: { $in: tokenList } },
              { enabled: { $ne: false } }
            ]
          },
          {
            $and: [
              { _id: { $in: tokenList } },
              {
                $or: [
                  { 'token.apn': { $exists: true } },
                  { 'token.android': { $exists: true } },
                  { 'token.web': { $exists: true } }
                ]
              },
              { enabled: { $ne: false } }
            ]
          }
        ]
      }
       */
    } else if (mongoNote.userId || mongoNote.userIds) {
      const userIdsList = mongoNote.userId ? [mongoNote.userId] : mongoNote.userIds;

      if (isDebug) {
        console.log('Push: Send message "' + mongoNote.title + '" to user: ', userIdsList);
      }

      query = {
        userId: {
          $in: userIdsList
        },
        enabled: {
          $ne: false
        }
      };
      /*
      query = {
        $and: [
          { userId: mongoNote.userId },
          {
            $or: [
              { 'token.apn': { $exists: true } },
              { 'token.android': { $exists: true } },
              { 'token.web': { $exists: true } }
            ]
          },
          { enabled: { $ne: false } }
        ]
      }
       */
    }

    if (query) {
      return querySend(query, mongoNote);
    } else {
      if (isDebug) {
        throw new Error('Push.send: please set option token/tokens, tokenId/tokenIds, userId/userIds');
      }
    }
  };

  let isSendingNotification = false;

  if (serverConfig.defaults && serverConfig.defaults.sendInterval !== null) {
    const sendNotification = mongoNote => {
      // Reserve notification
      const now = Date.now();
      const timeoutAt = now + serverConfig.defaults && serverConfig.defaults.sendTimeout;
      const reserved = Push.notifications.update({
        _id: mongoNote._id,
        sent: false,
        sending: {
          $lt: now
        }
      }, {
        $set: {
          sending: timeoutAt
        }
      }); // Make sure we only handle notifications reserved by this instance

      if (reserved) {
        const result = self.serverSend(mongoNote);

        if (!(serverConfig.defaults && serverConfig.defaults.keepNotifications)) {
          Push.notifications.remove({
            _id: mongoNote._id
          });
        } else {
          Push.notifications.update({
            _id: mongoNote._id
          }, {
            $set: {
              sent: true,
              sentAt: Date.now(),
              count: result,
              sending: 0
            }
          });
        } // Not sure what is this next one for. In my environment self.emit ... is not a function.
        // self.emit('send', { notification: notification._id, result: result })

      }
    };

    sendWorker(() => {
      if (isSendingNotification) {
        return;
      }

      try {
        isSendingNotification = true;
        const batchSize = serverConfig.defaults && serverConfig.defaults.sendBatchSize || 1;
        const now = Date.now();
        const pendingNotifications = Push.notifications.find({
          $and: [{
            sent: false
          }, {
            sending: {
              $lt: now
            }
          }, {
            $or: [{
              delayUntil: {
                $exists: false
              }
            }, {
              delayUntil: {
                $lte: now
              }
            }]
          }]
        }, {
          sort: {
            createdAt: 1
          },
          limit: batchSize
        });
        pendingNotifications.map(mongoNote => {
          try {
            sendNotification(mongoNote);
          } catch (error) {
            if (isDebug) {
              console.log('Show Full error', error);
              console.log('Push: Could not send notification id: "' + mongoNote._id + '", Error: ' + error.message);
            }
          }
        });
      } finally {
        isSendingNotification = false;
      }
    }, serverConfig.defaults && serverConfig.defaults.sendInterval || 15000, isDebug);
  } else {
    if (isDebug) {
      console.log('Push: Send server is disabled');
    }
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"internalMethods.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/activitree_push/lib/server/internalMethods.js                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Match, check;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  },

  check(v) {
    check = v;
  }

}, 0);
let Push;
module.link("./pushToDB", {
  Push(v) {
    Push = v;
  }

}, 1);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
Push.appCollection = new Mongo.Collection('_push_app_tokens');

Push.appCollection._ensureIndex({
  userId: 1
});

const matchToken = Match.OneOf({
  web: String
}, {
  android: String
}, {
  apn: String
}, {
  ios: String
});
Meteor.methods({
  'push-update': function (options) {
    if (Push.debug) {
      console.log('Push: Got push token from app:', options);
    }

    check(options, {
      id: Match.Optional(String),
      token: matchToken,
      appName: String,
      userId: Match.OneOf(String, null),
      metadata: Match.Optional(Object)
    }); // The if user id is set then user id should match on client and connection

    if (options.userId && options.userId !== this.userId) {
      throw new Meteor.Error(403, 'Forbidden access');
    }

    let doc;

    if (options.userId) {
      doc = Push.appCollection.findOne({
        userId: options.userId
      });
    } // No doc was found - we check the database to see if
    // we can find a match for the app via token and appName


    if (!doc) {
      doc = Push.appCollection.findOne({
        $and: [{
          token: options.token
        }, // Match token
        {
          appName: options.appName
        }, // Match appName
        {
          token: {
            $exists: true
          }
        } // Make sure token exists
        ]
      });
    } // if we could not find the id or token then create it


    if (!doc) {
      doc = {
        token: options.token,
        appName: options.appName,
        userId: options.userId,
        enabled: true,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      doc._id = Random.id();
      Push.appCollection.insert(doc, (err, res) => {
        if (err) {
          if (Push.debug) {
            console.log('I have an error when inserting something int he appCollection, server.js, line 60:', err);
          }
        } else {
          if (Push.debug) {
            console.log('Successfully inserted something in the Push.appCollection and saved to local storage', res);
          }
        }
      });
    } else {
      Push.appCollection.update({
        _id: doc._id
      }, {
        $set: {
          updatedAt: Date.now(),
          token: options.token
        }
      }, (err, res) => {
        if (err) {
          if (Push.debug) {
            console.log('I have an error when updating something int he appCollection, server.js, line 73:', err);
          }
        } else {
          if (Push.debug) {
            console.log('Successfully updated something in the Push.appCollection', res);
          }
        }
      });
    }

    let removed = false;

    if (doc) {
      Push.appCollection.remove({
        $and: [{
          _id: {
            $ne: doc._id
          }
        }, {
          token: doc.token
        }, {
          appName: doc.appName
        }, {
          token: {
            $exists: true
          }
        }]
      }, (err, res) => {
        if (err) {
          console.log('I have an error when deleting something int he appCollection, server.js, line 90:', err);
        } else {
          if (Push.debug) {
            if (Push.debug) {
              console.log('Push: Removed ' + res + ' existing app items');
            }

            if (res > 0) {
              removed = true;
            }
          }
        }
      });
    }

    if (!doc) {
      throw new Meteor.Error(500, 'setPushToken could not create record');
    } // Return the doc we want to use


    return {
      doc,
      removed
    };
  },
  'push-setuser': function (pushTokenDBId) {
    if (!pushTokenDBId) {
      if (Push.debug) {
        console.log('Push: I am probably after an App update where I installed a new version of the App' + 'and I cleared the local store but I am still logged when I start the new version for the first time.' + 'I will skip a user update in this situation.');
      }

      return;
    }

    check(pushTokenDBId, String);

    if (Push.debug) {
      console.log('Push: Settings userId "' + this.userId + '" for app:', pushTokenDBId);
    }

    const found = Push.appCollection.update({
      _id: pushTokenDBId
    }, {
      $set: {
        userId: this.userId
      }
    }, (err, res) => {
      if (err) {
        console.log('I have an error when updating the FOUND  the appCollection, server.js, line 120:', err);
      } else {
        if (Push.debug) {
          console.log('Successfully updated the FOUND in the Push.appCollection', res);
        }
      }
    });
    return !!found;
  },
  'push-metadata': function (data) {
    check(data, {
      id: String,
      metadata: Object
    }); // Set the metadata

    const found = Push.appCollection.update({
      _id: data.id
    }, {
      $set: {
        metadata: data.metadata
      }
    });
    return !!found;
  },
  'push-enable': function (data) {
    check(data, {
      id: String,
      enabled: Boolean
    });

    if (Push.debug) {
      console.log('Push: Setting enabled to "' + data.enabled + '" for app:', data.id);
    }

    const found = Push.appCollection.update({
      _id: data.id
    }, {
      $set: {
        enabled: data.enabled
      }
    });
    return !!found;
  },
  'push-check-is-enabled': function (data) {
    check(data, {
      id: String,
      enabled: Boolean
    });

    if (Push.debug) {
      console.log('Push: Setting enabled to "' + data.enabled + '" for app:', data.id);
    }

    const found = Push.appCollection.findOne({
      _id: data.id,
      enabled: {
        $exists: true
      }
    }, {
      fields: {
        enabled: 1
      }
    });
    return found && found.enabled;
  },
  'push-unsub-webpush': function (pushTokenId) {
    check(pushTokenId, String);
    return Push.appCollection.remove({
      _id: pushTokenId
    });
  }
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pushToDB.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/activitree_push/lib/server/pushToDB.js                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  Push: () => Push
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let Match, check;
module.link("meteor/check", {
  Match(v) {
    Match = v;
  },

  check(v) {
    check = v;
  }

}, 2);

function EventState() {}

const Push = new EventState();
Push.notifications = new Mongo.Collection('_push_notifications');

Push.notifications._ensureIndex({
  createdAt: 1
});

Push.notifications._ensureIndex({
  sent: 1
});

Push.notifications._ensureIndex({
  sending: 1
});

Push.notifications._ensureIndex({
  delayUntil: 1
});

Push.notifications._ensureIndex({
  userId: 1
});

const validateDocument = notification => {
  const matchToken = Match.OneOf({
    apn: String
  }, {
    android: String
  }, {
    web: String
  });
  check(notification, {
    from: Match.Optional(String),
    title: String,
    body: String,
    imageUrl: Match.Optional(String),
    badge: Match.Optional(Match.Integer),
    userId: Match.Optional(String),
    userIds: Match.Optional(Array),
    token: Match.Optional(matchToken),
    tokens: Match.Optional([matchToken]),
    tokenId: Match.Optional(String),
    tokenIds: Match.Optional(Array),
    topic: Match.Optional(String),
    // mandatory for IOS (via initialization), optional for Android (can send to a topic instead of token(s)
    sound: Match.Optional(String),
    icon: Match.Optional(String),
    color: Match.Optional(String),
    vibrate: Match.Optional(Boolean),
    contentAvailable: Match.Optional(Boolean),
    launchImage: Match.Optional(String),
    category: Match.Optional(String),
    threadId: Match.Optional(String),
    sent: Match.Optional(Boolean),
    sending: Match.Optional(Match.Integer),
    delayUntil: Match.Optional(Match.Where(timestamp => new Date(timestamp).getTime() > 0)),
    // like Date.now()
    notId: Match.Optional(Match.Integer),
    createdAt: Match.Where(timestamp => new Date(timestamp).getTime() > 0),
    // like Date.now()
    createdBy: Match.OneOf(String, null),
    data: Match.Optional(Object),
    // Make sure this object only contains string keys.
    iosData: Match.Optional(Object),
    androidData: Match.Optional(Object),
    // Android data ca only take string values do further validation here
    webData: Match.Optional(Object),
    action: Match.Optional(String)
  }); // Make sure a token selector or query have been set

  if (!notification.token && !notification.tokens && !notification.userId && !notification.userIds && !notification.tokenId && !notification.tokenIds) {
    throw new Error('No token selector or user found');
  } // If tokens array is set it should not be empty


  if (notification.userIds && !notification.userIds.length) {
    throw new Error('No tokens in array');
  } // If tokens array is set it should not be empty


  if (notification.tokens && !notification.tokens.length) {
    throw new Error('No tokens in array');
  }
};

Push.send = content => {
  const currentUser = Meteor.isClient && Meteor.userId() || Meteor.isServer && (content.createdBy || '<SERVER>') || null;

  const notification = _objectSpread({
    createdAt: Date.now(),
    createdBy: currentUser,
    sent: false,
    sending: 0
  }, content);

  validateDocument(notification);
  return Push.notifications.insert(notification);
};

Push.allow = rules => {
  if (rules.send) {
    Push.notifications.allow({
      insert: function (userId, notification) {
        // Validate the notification
        // validateDocument(notification)
        // Set the user defined "send" rules
        return rules.send.apply(this, [userId, notification]);
      }
    });
  }
};

Push.deny = rules => {
  if (rules.send) {
    Push.notifications.deny({
      insert: function (userId, notification) {
        // Validate the notification
        // validateDocument(notification)
        // Set the user defined "send" rules
        return rules.send.apply(this, [userId, notification]);
      }
    });
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notification.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/activitree_push/lib/server/notification.js                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
module.export({
  sendNotification: () => sendNotification
});

const sendNotification = (isDebug, fcmConnections, defaults, userToken, mongoNote) => {
  // https://firebase.google.com/docs/reference/fcm/rest/v1/projects.messages

  /**
   * For Android, the entire notification goes into 'data' as per the best practices of cordova-push-plugin
   * All commented fields are part of the Firebase-Admin but are not necessary for the present setup. For example, all keys of the
   * 'data' object must be strings while in Firebase-Admin some keys which would normally go under 'notification', are boolean.
   * I keep the commented fields just as quick reference for the standard.
   */
  const noteAndroidData = mongoNote.androidData || {};
  const noteIosData = mongoNote.iosData || {};
  const noteWebData = mongoNote.webData || {};
  const globalData = mongoNote.data || {};
  const note = {
    android: {
      // ttl: '86400s', // use default max of 4 weeks
      // collapse_key: string,
      priority: defaults.priority,
      // restricted_package_name: string,
      data: _objectSpread(_objectSpread({
        title: mongoNote.title,
        body: mongoNote.body,
        icon: mongoNote.icon || defaults.icon,
        color: mongoNote.color || defaults.color,
        sound: mongoNote.sound || defaults.sound,
        tag: "".concat(mongoNote.notId),
        // click_action: mongoNote.action
        channel_id: mongoNote.channelId || defaults.channelId || defaults.topic,
        notification_priority: mongoNote.notificationPriority || defaults.notificationPriority,
        visibility: mongoNote.visibility || defaults.visibility,
        // notification_count: mongoNote.badge || defaults.badge, // this is supposed to be a number, can't send it because I need it to be a string.
        image: mongoNote.imageUrl || defaults.imageUrl
      }, globalData), noteAndroidData),
      fcm_options: {
        analytics_label: mongoNote.analyticsLabel || defaults.analyticsLabel
      }
    },
    apns: {
      headers: {
        'apns-priority': defaults.apnsPriority
      },
      payload: {
        aps: {
          alert: {
            title: mongoNote.title,
            body: mongoNote.body,
            'launch-image': mongoNote.launchImage || defaults.launchImage
          },
          badge: mongoNote.badge || defaults.badge,
          sound: mongoNote.sound ? "".concat(mongoNote.sound, ".caf") : defaults.sound ? "".concat(defaults.sound, ".caf") : '',
          // 'click-action' // TODO check on this,
          data: _objectSpread(_objectSpread(_objectSpread(_objectSpread({}, defaults.data), defaults.iosData), globalData), noteIosData)
        }
      },
      fcm_options: {
        analytics_label: mongoNote.analyticsLabel || defaults.analyticsLabel,
        image: mongoNote.imageUrl || defaults.imageUrl
      }
    },
    webpush: {
      headers: {
        Urgency: 'high',
        TTL: defaults.webTTL // mandatory, in seconds

      },
      data: _objectSpread(_objectSpread(_objectSpread(_objectSpread({}, defaults.data), defaults.webData), globalData), noteWebData),
      notification: {
        title: mongoNote.title,
        body: mongoNote.body,
        icon: mongoNote.webIcon || defaults.webIcon,
        image: mongoNote.imageUrl || defaults.imageUrl
        /*
        actions: [
          {
            action: mongoNote.action || defaults.action,
            title: 'Book Appointment'
          }
        ] */

      },
      // Can take valued from here: https://developer.mozilla.org/en-US/docs/Web/API/Notification.
      fcm_options: {
        link: mongoNote.action || defaults.action
      }
    }
  };

  if (userToken) {
    note.token = userToken;
  } else if (note.topic) {
    note.topic = mongoNote.topic;
  } else {
    if (isDebug) {
      console.log('Missing scope, no token or topic to send to');
    }

    return;
  }

  if (isDebug) {
    console.log('Final notification right before shoot out:', JSON.stringify(note, null, 6));
  }

  fcmConnections.send(note).then(response => {
    if (isDebug) {
      console.log('Successfully sent message:', response);
    }
  }).catch(error => {
    if (isDebug) {
      console.log('FCM Sending Error: ', JSON.stringify(error, null, 4));
    }
  });
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"node_modules":{"firebase-admin":{"package.json":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/activitree_push/node_modules/firebase-admin/package.json                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.exports = {
  "name": "firebase-admin",
  "version": "9.11.0",
  "main": "lib/index.js"
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// node_modules/meteor/activitree_push/node_modules/firebase-admin/lib/index.js                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.useNode();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/activitree:push/lib/server/pushToDevice.js");
require("/node_modules/meteor/activitree:push/lib/server/internalMethods.js");
var exports = require("/node_modules/meteor/activitree:push/lib/server/pushToDB.js");

/* Exports */
Package._define("activitree:push", exports);

})();

//# sourceURL=meteor://💻app/packages/activitree_push.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYWN0aXZpdHJlZTpwdXNoL2xpYi9zZXJ2ZXIvcHVzaFRvRGV2aWNlLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9hY3Rpdml0cmVlOnB1c2gvbGliL3NlcnZlci9pbnRlcm5hbE1ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL2FjdGl2aXRyZWU6cHVzaC9saWIvc2VydmVyL3B1c2hUb0RCLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9hY3Rpdml0cmVlOnB1c2gvbGliL3NlcnZlci9ub3RpZmljYXRpb24uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJQdXNoIiwic2VuZE5vdGlmaWNhdGlvbiIsInNldEJhZGdlIiwiaXNDb25maWd1cmVkIiwic2VuZFdvcmtlciIsInRhc2siLCJpbnRlcnZhbCIsImlzRGVidWciLCJjb25zb2xlIiwibG9nIiwic2V0SW50ZXJ2YWwiLCJlcnJvciIsIm1lc3NhZ2UiLCJDb25maWd1cmUiLCJzZXJ2ZXJDb25maWciLCJkZWJ1ZyIsInNlbGYiLCJFcnJvciIsImFkbWluIiwicmVxdWlyZSIsImZjbSIsImluaXRpYWxpemVBcHAiLCJjcmVkZW50aWFsIiwiY2VydCIsImZpcmViYXNlQWRtaW4iLCJzZXJ2aWNlQWNjb3VudERhdGEiLCJkYXRhYmFzZVVSTCIsImZjbUNvbm5lY3Rpb25zIiwibWVzc2FnaW5nIiwidXNlclRva2VucyIsIm1vbmdvTm90ZSIsImRlZmF1bHRzIiwicXVlcnlTZW5kIiwicXVlcnkiLCJjb3VudEFwbiIsImNvdW50QW5kcm9pZCIsImNvdW50V2ViIiwiYXBwQ29sbGVjdGlvbiIsImZpbmQiLCJtYXAiLCJhcHAiLCJ0b2tlbiIsImFwbiIsInB1c2giLCJhbmRyb2lkIiwid2ViIiwidGl0bGUiLCJsZW5ndGgiLCJmaW5kT25lIiwiJGV4aXN0cyIsIndlbiIsInNlcnZlclNlbmQiLCJib2R5IiwidG9rZW5zIiwidG9rZW5MaXN0IiwiJGluIiwiZW5hYmxlZCIsIiRuZSIsInRva2VuSWQiLCJ0b2tlbklkcyIsInRva2VuSWRzTGlzdCIsIl9pZCIsInVzZXJJZCIsInVzZXJJZHMiLCJ1c2VySWRzTGlzdCIsImlzU2VuZGluZ05vdGlmaWNhdGlvbiIsInNlbmRJbnRlcnZhbCIsIm5vdyIsIkRhdGUiLCJ0aW1lb3V0QXQiLCJzZW5kVGltZW91dCIsInJlc2VydmVkIiwibm90aWZpY2F0aW9ucyIsInVwZGF0ZSIsInNlbnQiLCJzZW5kaW5nIiwiJGx0IiwiJHNldCIsInJlc3VsdCIsImtlZXBOb3RpZmljYXRpb25zIiwicmVtb3ZlIiwic2VudEF0IiwiY291bnQiLCJiYXRjaFNpemUiLCJzZW5kQmF0Y2hTaXplIiwicGVuZGluZ05vdGlmaWNhdGlvbnMiLCIkYW5kIiwiJG9yIiwiZGVsYXlVbnRpbCIsIiRsdGUiLCJzb3J0IiwiY3JlYXRlZEF0IiwibGltaXQiLCJNYXRjaCIsImNoZWNrIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiX2Vuc3VyZUluZGV4IiwibWF0Y2hUb2tlbiIsIk9uZU9mIiwiU3RyaW5nIiwiaW9zIiwibWV0aG9kcyIsIm9wdGlvbnMiLCJpZCIsIk9wdGlvbmFsIiwiYXBwTmFtZSIsIm1ldGFkYXRhIiwiT2JqZWN0IiwiZG9jIiwidXBkYXRlZEF0IiwiUmFuZG9tIiwiaW5zZXJ0IiwiZXJyIiwicmVzIiwicmVtb3ZlZCIsInB1c2hUb2tlbkRCSWQiLCJmb3VuZCIsImRhdGEiLCJCb29sZWFuIiwiZmllbGRzIiwicHVzaFRva2VuSWQiLCJfb2JqZWN0U3ByZWFkIiwiZGVmYXVsdCIsImV4cG9ydCIsIkV2ZW50U3RhdGUiLCJ2YWxpZGF0ZURvY3VtZW50Iiwibm90aWZpY2F0aW9uIiwiZnJvbSIsImltYWdlVXJsIiwiYmFkZ2UiLCJJbnRlZ2VyIiwiQXJyYXkiLCJ0b3BpYyIsInNvdW5kIiwiaWNvbiIsImNvbG9yIiwidmlicmF0ZSIsImNvbnRlbnRBdmFpbGFibGUiLCJsYXVuY2hJbWFnZSIsImNhdGVnb3J5IiwidGhyZWFkSWQiLCJXaGVyZSIsInRpbWVzdGFtcCIsImdldFRpbWUiLCJub3RJZCIsImNyZWF0ZWRCeSIsImlvc0RhdGEiLCJhbmRyb2lkRGF0YSIsIndlYkRhdGEiLCJhY3Rpb24iLCJzZW5kIiwiY29udGVudCIsImN1cnJlbnRVc2VyIiwiaXNDbGllbnQiLCJpc1NlcnZlciIsImFsbG93IiwicnVsZXMiLCJhcHBseSIsImRlbnkiLCJ1c2VyVG9rZW4iLCJub3RlQW5kcm9pZERhdGEiLCJub3RlSW9zRGF0YSIsIm5vdGVXZWJEYXRhIiwiZ2xvYmFsRGF0YSIsIm5vdGUiLCJwcmlvcml0eSIsInRhZyIsImNoYW5uZWxfaWQiLCJjaGFubmVsSWQiLCJub3RpZmljYXRpb25fcHJpb3JpdHkiLCJub3RpZmljYXRpb25Qcmlvcml0eSIsInZpc2liaWxpdHkiLCJpbWFnZSIsImZjbV9vcHRpb25zIiwiYW5hbHl0aWNzX2xhYmVsIiwiYW5hbHl0aWNzTGFiZWwiLCJhcG5zIiwiaGVhZGVycyIsImFwbnNQcmlvcml0eSIsInBheWxvYWQiLCJhcHMiLCJhbGVydCIsIndlYnB1c2giLCJVcmdlbmN5IiwiVFRMIiwid2ViVFRMIiwid2ViSWNvbiIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0aGVuIiwicmVzcG9uc2UiLCJjYXRjaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQXpCLEVBQTJDLENBQTNDO0FBQThDLElBQUlFLGdCQUFKO0FBQXFCSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQkFBWixFQUE2QjtBQUFDRyxrQkFBZ0IsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLG9CQUFnQixHQUFDRixDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBN0IsRUFBdUUsQ0FBdkU7O0FBSTVJQyxJQUFJLENBQUNFLFFBQUwsR0FBZ0IsWUFBMkI7QUFBRTtBQUFxRSxDQUFsSDs7QUFFQSxJQUFJQyxZQUFZLEdBQUcsS0FBbkI7O0FBRUEsTUFBTUMsVUFBVSxHQUFHLENBQUNDLElBQUQsRUFBT0MsUUFBUCxFQUFpQkMsT0FBakIsS0FBNkI7QUFDOUMsTUFBSUEsT0FBSixFQUFhO0FBQ1hDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGdEQUFnREgsUUFBNUQ7QUFDRDs7QUFFRCxTQUFPVixNQUFNLENBQUNjLFdBQVAsQ0FBbUIsTUFBTTtBQUM5QixRQUFJO0FBQ0ZMLFVBQUk7QUFDTCxLQUZELENBRUUsT0FBT00sS0FBUCxFQUFjO0FBQ2QsVUFBSUosT0FBSixFQUFhO0FBQ1hDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDRSxLQUFLLENBQUNDLE9BQWhEO0FBQ0Q7QUFDRjtBQUNGLEdBUk0sRUFRSk4sUUFSSSxDQUFQO0FBU0QsQ0FkRDs7QUFnQkFOLElBQUksQ0FBQ2EsU0FBTCxHQUFpQkMsWUFBWSxJQUFJO0FBQy9CLFFBQU1QLE9BQU8sR0FBR1AsSUFBSSxDQUFDZSxLQUFyQjtBQUNBLFFBQU1DLElBQUksR0FBRyxJQUFiOztBQUNBLE1BQUliLFlBQUosRUFBa0I7QUFBRSxVQUFNLElBQUljLEtBQUosQ0FBVSxxREFBVixDQUFOO0FBQXdFOztBQUM1RmQsY0FBWSxHQUFHLElBQWY7O0FBQ0EsTUFBSUksT0FBSixFQUFhO0FBQUVDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQThCSyxZQUE5QjtBQUE2QyxHQUw3QixDQU8vQjs7O0FBQ0EsUUFBTUksS0FBSyxHQUFHQyxPQUFPLENBQUMsZ0JBQUQsQ0FBckI7O0FBQ0EsUUFBTUMsR0FBRyxHQUFHRixLQUFLLENBQUNHLGFBQU4sQ0FBb0I7QUFDOUJDLGNBQVUsRUFBRUosS0FBSyxDQUFDSSxVQUFOLENBQWlCQyxJQUFqQixDQUFzQlQsWUFBWSxDQUFDVSxhQUFiLElBQThCVixZQUFZLENBQUNVLGFBQWIsQ0FBMkJDLGtCQUEvRSxDQURrQjtBQUU5QkMsZUFBVyxFQUFFWixZQUFZLENBQUNVLGFBQWIsSUFBOEJWLFlBQVksQ0FBQ1UsYUFBYixDQUEyQkU7QUFGeEMsR0FBcEIsQ0FBWjtBQUtBLFFBQU1DLGNBQWMsR0FBR1AsR0FBRyxDQUFDUSxTQUFKLEVBQXZCLENBZCtCLENBY1E7O0FBQ3ZDLE1BQUlkLFlBQVksQ0FBQ1UsYUFBakIsRUFBZ0M7QUFDOUIsUUFBSWpCLE9BQUosRUFBYTtBQUFFQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxpREFBWjtBQUFnRTs7QUFDL0UsUUFBSSxDQUFDSyxZQUFZLENBQUNVLGFBQWIsQ0FBMkJDLGtCQUFoQyxFQUFvRDtBQUFFakIsYUFBTyxDQUFDRyxLQUFSLENBQWMsMEVBQWQ7QUFBMkY7O0FBQ2pKLFFBQUksQ0FBQ0csWUFBWSxDQUFDVSxhQUFiLENBQTJCRSxXQUFoQyxFQUE2QztBQUFFbEIsYUFBTyxDQUFDRyxLQUFSLENBQWMsMkRBQWQ7QUFBNEU7O0FBQzNISyxRQUFJLENBQUNmLGdCQUFMLEdBQXdCLENBQUM0QixVQUFELEVBQWFDLFNBQWIsS0FBMkI3QixnQkFBZ0IsQ0FBQ00sT0FBRCxFQUFVb0IsY0FBVixFQUEwQmIsWUFBWSxDQUFDaUIsUUFBdkMsRUFBaURGLFVBQWpELEVBQTZEQyxTQUE3RCxDQUFuRTtBQUNEO0FBRUQ7QUFDRjtBQUNBO0FBQ0E7OztBQUNFLFFBQU1FLFNBQVMsR0FBRyxDQUFDQyxLQUFELEVBQVFILFNBQVIsS0FBc0I7QUFDdEMsVUFBTUksUUFBUSxHQUFHLEVBQWpCO0FBQ0EsVUFBTUMsWUFBWSxHQUFHLEVBQXJCO0FBQ0EsVUFBTUMsUUFBUSxHQUFHLEVBQWpCO0FBRUFwQyxRQUFJLENBQUNxQyxhQUFMLENBQW1CQyxJQUFuQixDQUF3QkwsS0FBeEIsRUFBK0JNLEdBQS9CLENBQW1DQyxHQUFHLElBQUk7QUFDeEMsVUFBSWpDLE9BQUosRUFBYTtBQUNYQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCK0IsR0FBRyxDQUFDQyxLQUFqQzs7QUFDQSxZQUFJRCxHQUFHLENBQUNDLEtBQUosQ0FBVUMsR0FBZCxFQUFtQjtBQUFFUixrQkFBUSxDQUFDUyxJQUFULENBQWMsR0FBZDtBQUFvQjs7QUFDekMsWUFBSUgsR0FBRyxDQUFDQyxLQUFKLENBQVVHLE9BQWQsRUFBdUI7QUFBRVQsc0JBQVksQ0FBQ1EsSUFBYixDQUFrQixHQUFsQjtBQUF3Qjs7QUFDakQsWUFBSUgsR0FBRyxDQUFDQyxLQUFKLENBQVVJLEdBQWQsRUFBbUI7QUFBRVQsa0JBQVEsQ0FBQ08sSUFBVCxDQUFjLEdBQWQ7QUFBb0I7QUFDMUM7O0FBQ0QzQixVQUFJLENBQUNmLGdCQUFMLENBQXNCdUMsR0FBRyxDQUFDQyxLQUFKLENBQVVDLEdBQVYsSUFBaUJGLEdBQUcsQ0FBQ0MsS0FBSixDQUFVRyxPQUEzQixJQUFzQ0osR0FBRyxDQUFDQyxLQUFKLENBQVVJLEdBQXRFLEVBQTJFZixTQUEzRTtBQUNELEtBUkQ7O0FBVUEsUUFBSXZCLE9BQUosRUFBYTtBQUNYQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBeUJxQixTQUFTLENBQUNnQixLQUFuQyxHQUEyQyxPQUEzQyxHQUFxRFosUUFBUSxDQUFDYSxNQUE5RCxHQUF1RSxjQUF2RSxHQUF3RlosWUFBWSxDQUFDWSxNQUFyRyxHQUE4RyxrQkFBMUgsRUFBOElYLFFBQVEsQ0FBQ1csTUFBdkosRUFBK0osV0FBL0osRUFEVyxDQUVYO0FBQ0E7O0FBQ0EsVUFBSSxDQUFDYixRQUFRLENBQUNhLE1BQVYsSUFBb0IsQ0FBQ1osWUFBWSxDQUFDWSxNQUFsQyxJQUE0QyxDQUFDWCxRQUFRLENBQUNXLE1BQTFELEVBQWtFO0FBQ2hFLFlBQUksQ0FBQy9DLElBQUksQ0FBQ3FDLGFBQUwsQ0FBbUJXLE9BQW5CLEVBQUwsRUFBbUM7QUFDakN4QyxpQkFBTyxDQUFDQyxHQUFSLENBQVksdUdBQVo7QUFDRDtBQUNGLE9BSkQsTUFJTyxJQUFJLENBQUN5QixRQUFRLENBQUNhLE1BQWQsRUFBc0I7QUFDM0IsWUFBSSxDQUFDL0MsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQlcsT0FBbkIsQ0FBMkI7QUFBRSx1QkFBYTtBQUFFQyxtQkFBTyxFQUFFO0FBQVg7QUFBZixTQUEzQixDQUFMLEVBQXFFO0FBQ25FekMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLDRGQUFaO0FBQ0Q7QUFDRixPQUpNLE1BSUEsSUFBSSxDQUFDMEIsWUFBWSxDQUFDWSxNQUFsQixFQUEwQjtBQUMvQixZQUFJLENBQUMvQyxJQUFJLENBQUNxQyxhQUFMLENBQW1CVyxPQUFuQixDQUEyQjtBQUFFLDJCQUFpQjtBQUFFQyxtQkFBTyxFQUFFO0FBQVg7QUFBbkIsU0FBM0IsQ0FBTCxFQUF5RTtBQUN2RXpDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWSxpR0FBWjtBQUNEO0FBQ0YsT0FKTSxNQUlBLElBQUksQ0FBQzJCLFFBQVEsQ0FBQ1csTUFBZCxFQUFzQjtBQUMzQixZQUFJLENBQUMvQyxJQUFJLENBQUNxQyxhQUFMLENBQW1CVyxPQUFuQixDQUEyQjtBQUFFLHVCQUFhO0FBQUVDLG1CQUFPLEVBQUU7QUFBWDtBQUFmLFNBQTNCLENBQUwsRUFBcUU7QUFDbkV6QyxpQkFBTyxDQUFDQyxHQUFSLENBQVksNkZBQVo7QUFDRDtBQUNGO0FBQ0Y7O0FBRUQsV0FBTztBQUNMaUMsU0FBRyxFQUFFUixRQURBO0FBRUxkLFNBQUcsRUFBRWUsWUFGQTtBQUdMZSxTQUFHLEVBQUVkO0FBSEEsS0FBUDtBQUtELEdBM0NEO0FBNkNBO0FBQ0Y7QUFDQTtBQUNBOzs7QUFDRXBCLE1BQUksQ0FBQ21DLFVBQUwsR0FBa0JyQixTQUFTLElBQUk7QUFDN0IsUUFBSUcsS0FBSixDQUQ2QixDQUU3QjtBQUNBOztBQUNBLFFBQUlILFNBQVMsQ0FBQ2dCLEtBQVYsS0FBb0IsS0FBS2hCLFNBQVMsQ0FBQ2dCLEtBQXZDLEVBQThDO0FBQUUsWUFBTSxJQUFJN0IsS0FBSixDQUFVLHdDQUFWLENBQU47QUFBMkQ7O0FBQzNHLFFBQUlhLFNBQVMsQ0FBQ3NCLElBQVYsS0FBbUIsS0FBS3RCLFNBQVMsQ0FBQ3NCLElBQXRDLEVBQTRDO0FBQUUsWUFBTSxJQUFJbkMsS0FBSixDQUFVLHVDQUFWLENBQU47QUFBMEQ7O0FBRXhHLFFBQUlhLFNBQVMsQ0FBQ1csS0FBVixJQUFtQlgsU0FBUyxDQUFDdUIsTUFBakMsRUFBeUM7QUFDdkMsWUFBTUMsU0FBUyxHQUFHeEIsU0FBUyxDQUFDVyxLQUFWLEdBQWtCLENBQUNYLFNBQVMsQ0FBQ1csS0FBWCxDQUFsQixHQUFzQ1gsU0FBUyxDQUFDdUIsTUFBbEU7O0FBQ0EsVUFBSTlDLE9BQUosRUFBYTtBQUFFQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBeUJxQixTQUFTLENBQUNnQixLQUFuQyxHQUEyQyxnQkFBdkQsRUFBeUVRLFNBQXpFO0FBQXFGOztBQUNwR3JCLFdBQUssR0FBRztBQUNOUSxhQUFLLEVBQUU7QUFBRWMsYUFBRyxFQUFFRDtBQUFQLFNBREQ7QUFFTkUsZUFBTyxFQUFFO0FBQUVDLGFBQUcsRUFBRTtBQUFQO0FBRkgsT0FBUjtBQUlELEtBUEQsTUFPTyxJQUFJM0IsU0FBUyxDQUFDNEIsT0FBVixJQUFxQjVCLFNBQVMsQ0FBQzZCLFFBQW5DLEVBQTZDO0FBQ2xELFlBQU1DLFlBQVksR0FBRzlCLFNBQVMsQ0FBQzRCLE9BQVYsR0FBb0IsQ0FBQzVCLFNBQVMsQ0FBQzRCLE9BQVgsQ0FBcEIsR0FBMEM1QixTQUFTLENBQUM2QixRQUF6RTs7QUFDQSxVQUFJcEQsT0FBSixFQUFhO0FBQUVDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUF5QnFCLFNBQVMsQ0FBQ2dCLEtBQW5DLEdBQTJDLG1CQUF2RCxFQUE0RWMsWUFBNUU7QUFBMkY7O0FBQzFHM0IsV0FBSyxHQUFHO0FBQ040QixXQUFHLEVBQUU7QUFBRU4sYUFBRyxFQUFFSztBQUFQLFNBREM7QUFFTkosZUFBTyxFQUFFO0FBQUVDLGFBQUcsRUFBRTtBQUFQO0FBRkgsT0FBUjtBQUlBO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0ssS0FoQ00sTUFnQ0EsSUFBSTNCLFNBQVMsQ0FBQ2dDLE1BQVYsSUFBb0JoQyxTQUFTLENBQUNpQyxPQUFsQyxFQUEyQztBQUNoRCxZQUFNQyxXQUFXLEdBQUdsQyxTQUFTLENBQUNnQyxNQUFWLEdBQW1CLENBQUNoQyxTQUFTLENBQUNnQyxNQUFYLENBQW5CLEdBQXdDaEMsU0FBUyxDQUFDaUMsT0FBdEU7O0FBQ0EsVUFBSXhELE9BQUosRUFBYTtBQUFFQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBeUJxQixTQUFTLENBQUNnQixLQUFuQyxHQUEyQyxhQUF2RCxFQUFzRWtCLFdBQXRFO0FBQW9GOztBQUNuRy9CLFdBQUssR0FBRztBQUNONkIsY0FBTSxFQUFFO0FBQUVQLGFBQUcsRUFBRVM7QUFBUCxTQURGO0FBRU5SLGVBQU8sRUFBRTtBQUFFQyxhQUFHLEVBQUU7QUFBUDtBQUZILE9BQVI7QUFJQTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSzs7QUFDRCxRQUFJeEIsS0FBSixFQUFXO0FBQ1QsYUFBT0QsU0FBUyxDQUFDQyxLQUFELEVBQVFILFNBQVIsQ0FBaEI7QUFDRCxLQUZELE1BRU87QUFDTCxVQUFJdkIsT0FBSixFQUFhO0FBQUUsY0FBTSxJQUFJVSxLQUFKLENBQVUsNkVBQVYsQ0FBTjtBQUFnRztBQUNoSDtBQUNGLEdBMUVEOztBQTRFQSxNQUFJZ0QscUJBQXFCLEdBQUcsS0FBNUI7O0FBRUEsTUFBSW5ELFlBQVksQ0FBQ2lCLFFBQWIsSUFBeUJqQixZQUFZLENBQUNpQixRQUFiLENBQXNCbUMsWUFBdEIsS0FBdUMsSUFBcEUsRUFBMEU7QUFDeEUsVUFBTWpFLGdCQUFnQixHQUFHNkIsU0FBUyxJQUFJO0FBQ3BDO0FBQ0EsWUFBTXFDLEdBQUcsR0FBR0MsSUFBSSxDQUFDRCxHQUFMLEVBQVo7QUFDQSxZQUFNRSxTQUFTLEdBQUdGLEdBQUcsR0FBR3JELFlBQVksQ0FBQ2lCLFFBQW5CLElBQStCakIsWUFBWSxDQUFDaUIsUUFBYixDQUFzQnVDLFdBQXZFO0FBQ0EsWUFBTUMsUUFBUSxHQUFHdkUsSUFBSSxDQUFDd0UsYUFBTCxDQUFtQkMsTUFBbkIsQ0FBMEI7QUFDekNaLFdBQUcsRUFBRS9CLFNBQVMsQ0FBQytCLEdBRDBCO0FBRXpDYSxZQUFJLEVBQUUsS0FGbUM7QUFHekNDLGVBQU8sRUFBRTtBQUFFQyxhQUFHLEVBQUVUO0FBQVA7QUFIZ0MsT0FBMUIsRUFJZDtBQUNEVSxZQUFJLEVBQUU7QUFDSkYsaUJBQU8sRUFBRU47QUFETDtBQURMLE9BSmMsQ0FBakIsQ0FKb0MsQ0FjcEM7O0FBQ0EsVUFBSUUsUUFBSixFQUFjO0FBQ1osY0FBTU8sTUFBTSxHQUFHOUQsSUFBSSxDQUFDbUMsVUFBTCxDQUFnQnJCLFNBQWhCLENBQWY7O0FBQ0EsWUFBSSxFQUFFaEIsWUFBWSxDQUFDaUIsUUFBYixJQUF5QmpCLFlBQVksQ0FBQ2lCLFFBQWIsQ0FBc0JnRCxpQkFBakQsQ0FBSixFQUF5RTtBQUN2RS9FLGNBQUksQ0FBQ3dFLGFBQUwsQ0FBbUJRLE1BQW5CLENBQTBCO0FBQUVuQixlQUFHLEVBQUUvQixTQUFTLENBQUMrQjtBQUFqQixXQUExQjtBQUNELFNBRkQsTUFFTztBQUNMN0QsY0FBSSxDQUFDd0UsYUFBTCxDQUFtQkMsTUFBbkIsQ0FBMEI7QUFBRVosZUFBRyxFQUFFL0IsU0FBUyxDQUFDK0I7QUFBakIsV0FBMUIsRUFBa0Q7QUFDaERnQixnQkFBSSxFQUFFO0FBQ0pILGtCQUFJLEVBQUUsSUFERjtBQUVKTyxvQkFBTSxFQUFFYixJQUFJLENBQUNELEdBQUwsRUFGSjtBQUdKZSxtQkFBSyxFQUFFSixNQUhIO0FBSUpILHFCQUFPLEVBQUU7QUFKTDtBQUQwQyxXQUFsRDtBQVFELFNBYlcsQ0FjWjtBQUNBOztBQUNEO0FBQ0YsS0FoQ0Q7O0FBa0NBdkUsY0FBVSxDQUFDLE1BQU07QUFDZixVQUFJNkQscUJBQUosRUFBMkI7QUFBRTtBQUFROztBQUNyQyxVQUFJO0FBQ0ZBLDZCQUFxQixHQUFHLElBQXhCO0FBQ0EsY0FBTWtCLFNBQVMsR0FBSXJFLFlBQVksQ0FBQ2lCLFFBQWIsSUFBeUJqQixZQUFZLENBQUNpQixRQUFiLENBQXNCcUQsYUFBaEQsSUFBa0UsQ0FBcEY7QUFDQSxjQUFNakIsR0FBRyxHQUFHQyxJQUFJLENBQUNELEdBQUwsRUFBWjtBQUNBLGNBQU1rQixvQkFBb0IsR0FBR3JGLElBQUksQ0FBQ3dFLGFBQUwsQ0FBbUJsQyxJQUFuQixDQUF3QjtBQUNuRGdELGNBQUksRUFBRSxDQUNKO0FBQUVaLGdCQUFJLEVBQUU7QUFBUixXQURJLEVBRUo7QUFBRUMsbUJBQU8sRUFBRTtBQUFFQyxpQkFBRyxFQUFFVDtBQUFQO0FBQVgsV0FGSSxFQUdKO0FBQ0VvQixlQUFHLEVBQUUsQ0FDSDtBQUFFQyx3QkFBVSxFQUFFO0FBQUV2Qyx1QkFBTyxFQUFFO0FBQVg7QUFBZCxhQURHLEVBRUg7QUFBRXVDLHdCQUFVLEVBQUU7QUFBRUMsb0JBQUksRUFBRXRCO0FBQVI7QUFBZCxhQUZHO0FBRFAsV0FISTtBQUQ2QyxTQUF4QixFQVcxQjtBQUNEdUIsY0FBSSxFQUFFO0FBQUVDLHFCQUFTLEVBQUU7QUFBYixXQURMO0FBRURDLGVBQUssRUFBRVQ7QUFGTixTQVgwQixDQUE3QjtBQWdCQUUsNEJBQW9CLENBQUM5QyxHQUFyQixDQUF5QlQsU0FBUyxJQUFJO0FBQ3BDLGNBQUk7QUFDRjdCLDRCQUFnQixDQUFDNkIsU0FBRCxDQUFoQjtBQUNELFdBRkQsQ0FFRSxPQUFPbkIsS0FBUCxFQUFjO0FBQ2QsZ0JBQUlKLE9BQUosRUFBYTtBQUNYQyxxQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVosRUFBK0JFLEtBQS9CO0FBQ0FILHFCQUFPLENBQUNDLEdBQVIsQ0FBWSw0Q0FBNENxQixTQUFTLENBQUMrQixHQUF0RCxHQUE0RCxZQUE1RCxHQUEyRWxELEtBQUssQ0FBQ0MsT0FBN0Y7QUFDRDtBQUNGO0FBQ0YsU0FURDtBQVVELE9BOUJELFNBOEJVO0FBQ1JxRCw2QkFBcUIsR0FBRyxLQUF4QjtBQUNEO0FBQ0YsS0FuQ1MsRUFtQ05uRCxZQUFZLENBQUNpQixRQUFiLElBQXlCakIsWUFBWSxDQUFDaUIsUUFBYixDQUFzQm1DLFlBQWhELElBQWlFLEtBbkMxRCxFQW1DaUUzRCxPQW5DakUsQ0FBVjtBQW9DRCxHQXZFRCxNQXVFTztBQUNMLFFBQUlBLE9BQUosRUFBYTtBQUFFQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSwrQkFBWjtBQUE4QztBQUM5RDtBQUNGLENBbk9ELEM7Ozs7Ozs7Ozs7O0FDeEJBLElBQUlvRixLQUFKLEVBQVVDLEtBQVY7QUFBZ0JqRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMrRixPQUFLLENBQUM5RixDQUFELEVBQUc7QUFBQzhGLFNBQUssR0FBQzlGLENBQU47QUFBUSxHQUFsQjs7QUFBbUIrRixPQUFLLENBQUMvRixDQUFELEVBQUc7QUFBQytGLFNBQUssR0FBQy9GLENBQU47QUFBUTs7QUFBcEMsQ0FBM0IsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUF6QixFQUEyQyxDQUEzQztBQUE4QyxJQUFJSCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBTXRKQyxJQUFJLENBQUNxQyxhQUFMLEdBQXFCLElBQUkwRCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsa0JBQXJCLENBQXJCOztBQUNBaEcsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQjRELFlBQW5CLENBQWdDO0FBQUVuQyxRQUFNLEVBQUU7QUFBVixDQUFoQzs7QUFFQSxNQUFNb0MsVUFBVSxHQUFHTCxLQUFLLENBQUNNLEtBQU4sQ0FBWTtBQUFFdEQsS0FBRyxFQUFFdUQ7QUFBUCxDQUFaLEVBQTZCO0FBQUV4RCxTQUFPLEVBQUV3RDtBQUFYLENBQTdCLEVBQWtEO0FBQUUxRCxLQUFHLEVBQUUwRDtBQUFQLENBQWxELEVBQW1FO0FBQUVDLEtBQUcsRUFBRUQ7QUFBUCxDQUFuRSxDQUFuQjtBQUVBeEcsTUFBTSxDQUFDMEcsT0FBUCxDQUFlO0FBQ2IsaUJBQWUsVUFBVUMsT0FBVixFQUFtQjtBQUNoQyxRQUFJdkcsSUFBSSxDQUFDZSxLQUFULEVBQWdCO0FBQUVQLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLGdDQUFaLEVBQThDOEYsT0FBOUM7QUFBd0Q7O0FBRTFFVCxTQUFLLENBQUNTLE9BQUQsRUFBVTtBQUNiQyxRQUFFLEVBQUVYLEtBQUssQ0FBQ1ksUUFBTixDQUFlTCxNQUFmLENBRFM7QUFFYjNELFdBQUssRUFBRXlELFVBRk07QUFHYlEsYUFBTyxFQUFFTixNQUhJO0FBSWJ0QyxZQUFNLEVBQUUrQixLQUFLLENBQUNNLEtBQU4sQ0FBWUMsTUFBWixFQUFvQixJQUFwQixDQUpLO0FBS2JPLGNBQVEsRUFBRWQsS0FBSyxDQUFDWSxRQUFOLENBQWVHLE1BQWY7QUFMRyxLQUFWLENBQUwsQ0FIZ0MsQ0FXaEM7O0FBQ0EsUUFBSUwsT0FBTyxDQUFDekMsTUFBUixJQUFrQnlDLE9BQU8sQ0FBQ3pDLE1BQVIsS0FBbUIsS0FBS0EsTUFBOUMsRUFBc0Q7QUFDcEQsWUFBTSxJQUFJbEUsTUFBTSxDQUFDcUIsS0FBWCxDQUFpQixHQUFqQixFQUFzQixrQkFBdEIsQ0FBTjtBQUNEOztBQUVELFFBQUk0RixHQUFKOztBQUVBLFFBQUlOLE9BQU8sQ0FBQ3pDLE1BQVosRUFBb0I7QUFDbEIrQyxTQUFHLEdBQUc3RyxJQUFJLENBQUNxQyxhQUFMLENBQW1CVyxPQUFuQixDQUEyQjtBQUFFYyxjQUFNLEVBQUV5QyxPQUFPLENBQUN6QztBQUFsQixPQUEzQixDQUFOO0FBQ0QsS0FwQitCLENBc0JoQztBQUNBOzs7QUFDQSxRQUFJLENBQUMrQyxHQUFMLEVBQVU7QUFDUkEsU0FBRyxHQUFHN0csSUFBSSxDQUFDcUMsYUFBTCxDQUFtQlcsT0FBbkIsQ0FBMkI7QUFDL0JzQyxZQUFJLEVBQUUsQ0FDSjtBQUFFN0MsZUFBSyxFQUFFOEQsT0FBTyxDQUFDOUQ7QUFBakIsU0FESSxFQUNzQjtBQUMxQjtBQUFFaUUsaUJBQU8sRUFBRUgsT0FBTyxDQUFDRztBQUFuQixTQUZJLEVBRTBCO0FBQzlCO0FBQUVqRSxlQUFLLEVBQUU7QUFBRVEsbUJBQU8sRUFBRTtBQUFYO0FBQVQsU0FISSxDQUd5QjtBQUh6QjtBQUR5QixPQUEzQixDQUFOO0FBT0QsS0FoQytCLENBa0NoQzs7O0FBQ0EsUUFBSSxDQUFDNEQsR0FBTCxFQUFVO0FBQ1JBLFNBQUcsR0FBRztBQUNKcEUsYUFBSyxFQUFFOEQsT0FBTyxDQUFDOUQsS0FEWDtBQUVKaUUsZUFBTyxFQUFFSCxPQUFPLENBQUNHLE9BRmI7QUFHSjVDLGNBQU0sRUFBRXlDLE9BQU8sQ0FBQ3pDLE1BSFo7QUFJSk4sZUFBTyxFQUFFLElBSkw7QUFLSm1DLGlCQUFTLEVBQUV2QixJQUFJLENBQUNELEdBQUwsRUFMUDtBQU1KMkMsaUJBQVMsRUFBRTFDLElBQUksQ0FBQ0QsR0FBTDtBQU5QLE9BQU47QUFTQTBDLFNBQUcsQ0FBQ2hELEdBQUosR0FBVWtELE1BQU0sQ0FBQ1AsRUFBUCxFQUFWO0FBQ0F4RyxVQUFJLENBQUNxQyxhQUFMLENBQW1CMkUsTUFBbkIsQ0FBMEJILEdBQTFCLEVBQStCLENBQUNJLEdBQUQsRUFBTUMsR0FBTixLQUFjO0FBQzNDLFlBQUlELEdBQUosRUFBUztBQUNQLGNBQUlqSCxJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFBRVAsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG9GQUFaLEVBQWtHd0csR0FBbEc7QUFBd0c7QUFDM0gsU0FGRCxNQUVPO0FBQ0wsY0FBSWpILElBQUksQ0FBQ2UsS0FBVCxFQUFnQjtBQUFFUCxtQkFBTyxDQUFDQyxHQUFSLENBQVksc0ZBQVosRUFBb0d5RyxHQUFwRztBQUEwRztBQUM3SDtBQUNGLE9BTkQ7QUFPRCxLQWxCRCxNQWtCTztBQUNMbEgsVUFBSSxDQUFDcUMsYUFBTCxDQUFtQm9DLE1BQW5CLENBQTBCO0FBQUVaLFdBQUcsRUFBRWdELEdBQUcsQ0FBQ2hEO0FBQVgsT0FBMUIsRUFBNEM7QUFDMUNnQixZQUFJLEVBQUU7QUFDSmlDLG1CQUFTLEVBQUUxQyxJQUFJLENBQUNELEdBQUwsRUFEUDtBQUVKMUIsZUFBSyxFQUFFOEQsT0FBTyxDQUFDOUQ7QUFGWDtBQURvQyxPQUE1QyxFQUtHLENBQUN3RSxHQUFELEVBQU1DLEdBQU4sS0FBYztBQUNmLFlBQUlELEdBQUosRUFBUztBQUNQLGNBQUlqSCxJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFBRVAsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG1GQUFaLEVBQWlHd0csR0FBakc7QUFBdUc7QUFDMUgsU0FGRCxNQUVPO0FBQ0wsY0FBSWpILElBQUksQ0FBQ2UsS0FBVCxFQUFnQjtBQUFFUCxtQkFBTyxDQUFDQyxHQUFSLENBQVksMERBQVosRUFBd0V5RyxHQUF4RTtBQUE4RTtBQUNqRztBQUNGLE9BWEQ7QUFZRDs7QUFFRCxRQUFJQyxPQUFPLEdBQUcsS0FBZDs7QUFDQSxRQUFJTixHQUFKLEVBQVM7QUFDUDdHLFVBQUksQ0FBQ3FDLGFBQUwsQ0FBbUIyQyxNQUFuQixDQUEwQjtBQUN4Qk0sWUFBSSxFQUFFLENBQ0o7QUFBRXpCLGFBQUcsRUFBRTtBQUFFSixlQUFHLEVBQUVvRCxHQUFHLENBQUNoRDtBQUFYO0FBQVAsU0FESSxFQUVKO0FBQUVwQixlQUFLLEVBQUVvRSxHQUFHLENBQUNwRTtBQUFiLFNBRkksRUFHSjtBQUFFaUUsaUJBQU8sRUFBRUcsR0FBRyxDQUFDSDtBQUFmLFNBSEksRUFJSjtBQUFFakUsZUFBSyxFQUFFO0FBQUVRLG1CQUFPLEVBQUU7QUFBWDtBQUFULFNBSkk7QUFEa0IsT0FBMUIsRUFPRyxDQUFDZ0UsR0FBRCxFQUFNQyxHQUFOLEtBQWM7QUFDZixZQUFJRCxHQUFKLEVBQVM7QUFDUHpHLGlCQUFPLENBQUNDLEdBQVIsQ0FBWSxtRkFBWixFQUFpR3dHLEdBQWpHO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsY0FBSWpILElBQUksQ0FBQ2UsS0FBVCxFQUFnQjtBQUNkLGdCQUFJZixJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFBRVAscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFtQnlHLEdBQW5CLEdBQXlCLHFCQUFyQztBQUE2RDs7QUFDL0UsZ0JBQUlBLEdBQUcsR0FBRyxDQUFWLEVBQWE7QUFDWEMscUJBQU8sR0FBRyxJQUFWO0FBQ0Q7QUFDRjtBQUNGO0FBQ0YsT0FsQkQ7QUFtQkQ7O0FBRUQsUUFBSSxDQUFDTixHQUFMLEVBQVU7QUFDUixZQUFNLElBQUlqSCxNQUFNLENBQUNxQixLQUFYLENBQWlCLEdBQWpCLEVBQXNCLHNDQUF0QixDQUFOO0FBQ0QsS0E3RitCLENBOEZoQzs7O0FBQ0EsV0FBTztBQUFFNEYsU0FBRjtBQUFPTTtBQUFQLEtBQVA7QUFDRCxHQWpHWTtBQW1HYixrQkFBZ0IsVUFBVUMsYUFBVixFQUF5QjtBQUN2QyxRQUFJLENBQUNBLGFBQUwsRUFBb0I7QUFDbEIsVUFBSXBILElBQUksQ0FBQ2UsS0FBVCxFQUFnQjtBQUNkUCxlQUFPLENBQUNDLEdBQVIsQ0FBWSx1RkFDVixzR0FEVSxHQUVWLDhDQUZGO0FBR0Q7O0FBQ0Q7QUFDRDs7QUFDRHFGLFNBQUssQ0FBQ3NCLGFBQUQsRUFBZ0JoQixNQUFoQixDQUFMOztBQUNBLFFBQUlwRyxJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFDZFAsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQTRCLEtBQUtxRCxNQUFqQyxHQUEwQyxZQUF0RCxFQUFvRXNELGFBQXBFO0FBQ0Q7O0FBRUQsVUFBTUMsS0FBSyxHQUFHckgsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQm9DLE1BQW5CLENBQTBCO0FBQUVaLFNBQUcsRUFBRXVEO0FBQVAsS0FBMUIsRUFBa0Q7QUFBRXZDLFVBQUksRUFBRTtBQUFFZixjQUFNLEVBQUUsS0FBS0E7QUFBZjtBQUFSLEtBQWxELEVBQXFGLENBQUNtRCxHQUFELEVBQU1DLEdBQU4sS0FBYztBQUMvRyxVQUFJRCxHQUFKLEVBQVM7QUFDUHpHLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLGtGQUFaLEVBQWdHd0csR0FBaEc7QUFDRCxPQUZELE1BRU87QUFDTCxZQUFJakgsSUFBSSxDQUFDZSxLQUFULEVBQWdCO0FBQ2RQLGlCQUFPLENBQUNDLEdBQVIsQ0FBWSwwREFBWixFQUF3RXlHLEdBQXhFO0FBQ0Q7QUFDRjtBQUNGLEtBUmEsQ0FBZDtBQVVBLFdBQU8sQ0FBQyxDQUFDRyxLQUFUO0FBQ0QsR0E1SFk7QUE4SGIsbUJBQWlCLFVBQVVDLElBQVYsRUFBZ0I7QUFDL0J4QixTQUFLLENBQUN3QixJQUFELEVBQU87QUFDVmQsUUFBRSxFQUFFSixNQURNO0FBRVZPLGNBQVEsRUFBRUM7QUFGQSxLQUFQLENBQUwsQ0FEK0IsQ0FNL0I7O0FBQ0EsVUFBTVMsS0FBSyxHQUFHckgsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQm9DLE1BQW5CLENBQTBCO0FBQUVaLFNBQUcsRUFBRXlELElBQUksQ0FBQ2Q7QUFBWixLQUExQixFQUE0QztBQUFFM0IsVUFBSSxFQUFFO0FBQUU4QixnQkFBUSxFQUFFVyxJQUFJLENBQUNYO0FBQWpCO0FBQVIsS0FBNUMsQ0FBZDtBQUVBLFdBQU8sQ0FBQyxDQUFDVSxLQUFUO0FBQ0QsR0F4SVk7QUEwSWIsaUJBQWUsVUFBVUMsSUFBVixFQUFnQjtBQUM3QnhCLFNBQUssQ0FBQ3dCLElBQUQsRUFBTztBQUNWZCxRQUFFLEVBQUVKLE1BRE07QUFFVjVDLGFBQU8sRUFBRStEO0FBRkMsS0FBUCxDQUFMOztBQUtBLFFBQUl2SCxJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFDZFAsYUFBTyxDQUFDQyxHQUFSLENBQVksK0JBQStCNkcsSUFBSSxDQUFDOUQsT0FBcEMsR0FBOEMsWUFBMUQsRUFBd0U4RCxJQUFJLENBQUNkLEVBQTdFO0FBQ0Q7O0FBRUQsVUFBTWEsS0FBSyxHQUFHckgsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQm9DLE1BQW5CLENBQTBCO0FBQUVaLFNBQUcsRUFBRXlELElBQUksQ0FBQ2Q7QUFBWixLQUExQixFQUE0QztBQUFFM0IsVUFBSSxFQUFFO0FBQUVyQixlQUFPLEVBQUU4RCxJQUFJLENBQUM5RDtBQUFoQjtBQUFSLEtBQTVDLENBQWQ7QUFFQSxXQUFPLENBQUMsQ0FBQzZELEtBQVQ7QUFDRCxHQXZKWTtBQXlKYiwyQkFBeUIsVUFBVUMsSUFBVixFQUFnQjtBQUN2Q3hCLFNBQUssQ0FBQ3dCLElBQUQsRUFBTztBQUNWZCxRQUFFLEVBQUVKLE1BRE07QUFFVjVDLGFBQU8sRUFBRStEO0FBRkMsS0FBUCxDQUFMOztBQUtBLFFBQUl2SCxJQUFJLENBQUNlLEtBQVQsRUFBZ0I7QUFDZFAsYUFBTyxDQUFDQyxHQUFSLENBQVksK0JBQStCNkcsSUFBSSxDQUFDOUQsT0FBcEMsR0FBOEMsWUFBMUQsRUFBd0U4RCxJQUFJLENBQUNkLEVBQTdFO0FBQ0Q7O0FBRUQsVUFBTWEsS0FBSyxHQUFHckgsSUFBSSxDQUFDcUMsYUFBTCxDQUFtQlcsT0FBbkIsQ0FBMkI7QUFBRWEsU0FBRyxFQUFFeUQsSUFBSSxDQUFDZCxFQUFaO0FBQWdCaEQsYUFBTyxFQUFFO0FBQUVQLGVBQU8sRUFBRTtBQUFYO0FBQXpCLEtBQTNCLEVBQXlFO0FBQUV1RSxZQUFNLEVBQUU7QUFBRWhFLGVBQU8sRUFBRTtBQUFYO0FBQVYsS0FBekUsQ0FBZDtBQUVBLFdBQU82RCxLQUFLLElBQUlBLEtBQUssQ0FBQzdELE9BQXRCO0FBQ0QsR0F0S1k7QUF3S2Isd0JBQXNCLFVBQVVpRSxXQUFWLEVBQXVCO0FBQzNDM0IsU0FBSyxDQUFDMkIsV0FBRCxFQUFjckIsTUFBZCxDQUFMO0FBQ0EsV0FBT3BHLElBQUksQ0FBQ3FDLGFBQUwsQ0FBbUIyQyxNQUFuQixDQUEwQjtBQUFFbkIsU0FBRyxFQUFFNEQ7QUFBUCxLQUExQixDQUFQO0FBQ0Q7QUEzS1ksQ0FBZixFOzs7Ozs7Ozs7OztBQ1hBLElBQUlDLGFBQUo7O0FBQWtCN0gsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQzZILFNBQU8sQ0FBQzVILENBQUQsRUFBRztBQUFDMkgsaUJBQWEsR0FBQzNILENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCRixNQUFNLENBQUMrSCxNQUFQLENBQWM7QUFBQzVILE1BQUksRUFBQyxNQUFJQTtBQUFWLENBQWQ7QUFBK0IsSUFBSUosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJZ0csS0FBSjtBQUFVbEcsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDaUcsT0FBSyxDQUFDaEcsQ0FBRCxFQUFHO0FBQUNnRyxTQUFLLEdBQUNoRyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUk4RixLQUFKLEVBQVVDLEtBQVY7QUFBZ0JqRyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMrRixPQUFLLENBQUM5RixDQUFELEVBQUc7QUFBQzhGLFNBQUssR0FBQzlGLENBQU47QUFBUSxHQUFsQjs7QUFBbUIrRixPQUFLLENBQUMvRixDQUFELEVBQUc7QUFBQytGLFNBQUssR0FBQy9GLENBQU47QUFBUTs7QUFBcEMsQ0FBM0IsRUFBaUUsQ0FBakU7O0FBSzNLLFNBQVM4SCxVQUFULEdBQXVCLENBQUU7O0FBRXpCLE1BQU03SCxJQUFJLEdBQUcsSUFBSTZILFVBQUosRUFBYjtBQUVBN0gsSUFBSSxDQUFDd0UsYUFBTCxHQUFxQixJQUFJdUIsS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUFyQjs7QUFDQWhHLElBQUksQ0FBQ3dFLGFBQUwsQ0FBbUJ5QixZQUFuQixDQUFnQztBQUFFTixXQUFTLEVBQUU7QUFBYixDQUFoQzs7QUFDQTNGLElBQUksQ0FBQ3dFLGFBQUwsQ0FBbUJ5QixZQUFuQixDQUFnQztBQUFFdkIsTUFBSSxFQUFFO0FBQVIsQ0FBaEM7O0FBQ0ExRSxJQUFJLENBQUN3RSxhQUFMLENBQW1CeUIsWUFBbkIsQ0FBZ0M7QUFBRXRCLFNBQU8sRUFBRTtBQUFYLENBQWhDOztBQUNBM0UsSUFBSSxDQUFDd0UsYUFBTCxDQUFtQnlCLFlBQW5CLENBQWdDO0FBQUVULFlBQVUsRUFBRTtBQUFkLENBQWhDOztBQUNBeEYsSUFBSSxDQUFDd0UsYUFBTCxDQUFtQnlCLFlBQW5CLENBQWdDO0FBQUVuQyxRQUFNLEVBQUU7QUFBVixDQUFoQzs7QUFFQSxNQUFNZ0UsZ0JBQWdCLEdBQUdDLFlBQVksSUFBSTtBQUN2QyxRQUFNN0IsVUFBVSxHQUFHTCxLQUFLLENBQUNNLEtBQU4sQ0FBWTtBQUFFekQsT0FBRyxFQUFFMEQ7QUFBUCxHQUFaLEVBQTZCO0FBQUV4RCxXQUFPLEVBQUV3RDtBQUFYLEdBQTdCLEVBQWtEO0FBQUV2RCxPQUFHLEVBQUV1RDtBQUFQLEdBQWxELENBQW5CO0FBQ0FOLE9BQUssQ0FBQ2lDLFlBQUQsRUFBZTtBQUNsQkMsUUFBSSxFQUFFbkMsS0FBSyxDQUFDWSxRQUFOLENBQWVMLE1BQWYsQ0FEWTtBQUVsQnRELFNBQUssRUFBRXNELE1BRlc7QUFHbEJoRCxRQUFJLEVBQUVnRCxNQUhZO0FBSWxCNkIsWUFBUSxFQUFFcEMsS0FBSyxDQUFDWSxRQUFOLENBQWVMLE1BQWYsQ0FKUTtBQUtsQjhCLFNBQUssRUFBRXJDLEtBQUssQ0FBQ1ksUUFBTixDQUFlWixLQUFLLENBQUNzQyxPQUFyQixDQUxXO0FBTWxCckUsVUFBTSxFQUFFK0IsS0FBSyxDQUFDWSxRQUFOLENBQWVMLE1BQWYsQ0FOVTtBQU9sQnJDLFdBQU8sRUFBRThCLEtBQUssQ0FBQ1ksUUFBTixDQUFlMkIsS0FBZixDQVBTO0FBUWxCM0YsU0FBSyxFQUFFb0QsS0FBSyxDQUFDWSxRQUFOLENBQWVQLFVBQWYsQ0FSVztBQVNsQjdDLFVBQU0sRUFBRXdDLEtBQUssQ0FBQ1ksUUFBTixDQUFlLENBQUNQLFVBQUQsQ0FBZixDQVRVO0FBVWxCeEMsV0FBTyxFQUFFbUMsS0FBSyxDQUFDWSxRQUFOLENBQWVMLE1BQWYsQ0FWUztBQVdsQnpDLFlBQVEsRUFBRWtDLEtBQUssQ0FBQ1ksUUFBTixDQUFlMkIsS0FBZixDQVhRO0FBWWxCQyxTQUFLLEVBQUV4QyxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZixDQVpXO0FBWWE7QUFDL0JrQyxTQUFLLEVBQUV6QyxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZixDQWJXO0FBY2xCbUMsUUFBSSxFQUFFMUMsS0FBSyxDQUFDWSxRQUFOLENBQWVMLE1BQWYsQ0FkWTtBQWVsQm9DLFNBQUssRUFBRTNDLEtBQUssQ0FBQ1ksUUFBTixDQUFlTCxNQUFmLENBZlc7QUFnQmxCcUMsV0FBTyxFQUFFNUMsS0FBSyxDQUFDWSxRQUFOLENBQWVjLE9BQWYsQ0FoQlM7QUFpQmxCbUIsb0JBQWdCLEVBQUU3QyxLQUFLLENBQUNZLFFBQU4sQ0FBZWMsT0FBZixDQWpCQTtBQWtCbEJvQixlQUFXLEVBQUU5QyxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZixDQWxCSztBQW1CbEJ3QyxZQUFRLEVBQUUvQyxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZixDQW5CUTtBQW9CbEJ5QyxZQUFRLEVBQUVoRCxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZixDQXBCUTtBQXFCbEIxQixRQUFJLEVBQUVtQixLQUFLLENBQUNZLFFBQU4sQ0FBZWMsT0FBZixDQXJCWTtBQXNCbEI1QyxXQUFPLEVBQUVrQixLQUFLLENBQUNZLFFBQU4sQ0FBZVosS0FBSyxDQUFDc0MsT0FBckIsQ0F0QlM7QUF1QmxCM0MsY0FBVSxFQUFFSyxLQUFLLENBQUNZLFFBQU4sQ0FBZVosS0FBSyxDQUFDaUQsS0FBTixDQUFZQyxTQUFTLElBQUssSUFBSTNFLElBQUosQ0FBUzJFLFNBQVQsQ0FBRCxDQUFzQkMsT0FBdEIsS0FBa0MsQ0FBM0QsQ0FBZixDQXZCTTtBQXVCeUU7QUFDM0ZDLFNBQUssRUFBRXBELEtBQUssQ0FBQ1ksUUFBTixDQUFlWixLQUFLLENBQUNzQyxPQUFyQixDQXhCVztBQXlCbEJ4QyxhQUFTLEVBQUVFLEtBQUssQ0FBQ2lELEtBQU4sQ0FBWUMsU0FBUyxJQUFLLElBQUkzRSxJQUFKLENBQVMyRSxTQUFULENBQUQsQ0FBc0JDLE9BQXRCLEtBQWtDLENBQTNELENBekJPO0FBeUJ3RDtBQUMxRUUsYUFBUyxFQUFFckQsS0FBSyxDQUFDTSxLQUFOLENBQVlDLE1BQVosRUFBb0IsSUFBcEIsQ0ExQk87QUEyQmxCa0IsUUFBSSxFQUFFekIsS0FBSyxDQUFDWSxRQUFOLENBQWVHLE1BQWYsQ0EzQlk7QUEyQlk7QUFDOUJ1QyxXQUFPLEVBQUV0RCxLQUFLLENBQUNZLFFBQU4sQ0FBZUcsTUFBZixDQTVCUztBQTZCbEJ3QyxlQUFXLEVBQUV2RCxLQUFLLENBQUNZLFFBQU4sQ0FBZUcsTUFBZixDQTdCSztBQTZCbUI7QUFDckN5QyxXQUFPLEVBQUV4RCxLQUFLLENBQUNZLFFBQU4sQ0FBZUcsTUFBZixDQTlCUztBQStCbEIwQyxVQUFNLEVBQUV6RCxLQUFLLENBQUNZLFFBQU4sQ0FBZUwsTUFBZjtBQS9CVSxHQUFmLENBQUwsQ0FGdUMsQ0FvQ3ZDOztBQUNBLE1BQUksQ0FBQzJCLFlBQVksQ0FBQ3RGLEtBQWQsSUFBdUIsQ0FBQ3NGLFlBQVksQ0FBQzFFLE1BQXJDLElBQStDLENBQUMwRSxZQUFZLENBQUNqRSxNQUE3RCxJQUF1RSxDQUFDaUUsWUFBWSxDQUFDaEUsT0FBckYsSUFBZ0csQ0FBQ2dFLFlBQVksQ0FBQ3JFLE9BQTlHLElBQXlILENBQUNxRSxZQUFZLENBQUNwRSxRQUEzSSxFQUFxSjtBQUNuSixVQUFNLElBQUkxQyxLQUFKLENBQVUsaUNBQVYsQ0FBTjtBQUNELEdBdkNzQyxDQXlDdkM7OztBQUNBLE1BQUk4RyxZQUFZLENBQUNoRSxPQUFiLElBQXdCLENBQUNnRSxZQUFZLENBQUNoRSxPQUFiLENBQXFCaEIsTUFBbEQsRUFBMEQ7QUFDeEQsVUFBTSxJQUFJOUIsS0FBSixDQUFVLG9CQUFWLENBQU47QUFDRCxHQTVDc0MsQ0E4Q3ZDOzs7QUFDQSxNQUFJOEcsWUFBWSxDQUFDMUUsTUFBYixJQUF1QixDQUFDMEUsWUFBWSxDQUFDMUUsTUFBYixDQUFvQk4sTUFBaEQsRUFBd0Q7QUFDdEQsVUFBTSxJQUFJOUIsS0FBSixDQUFVLG9CQUFWLENBQU47QUFDRDtBQUNGLENBbEREOztBQW9EQWpCLElBQUksQ0FBQ3VKLElBQUwsR0FBWUMsT0FBTyxJQUFJO0FBQ3JCLFFBQU1DLFdBQVcsR0FBSTdKLE1BQU0sQ0FBQzhKLFFBQVAsSUFBbUI5SixNQUFNLENBQUNrRSxNQUFQLEVBQXBCLElBQXlDbEUsTUFBTSxDQUFDK0osUUFBUCxLQUFvQkgsT0FBTyxDQUFDTixTQUFSLElBQXFCLFVBQXpDLENBQXpDLElBQWtHLElBQXRIOztBQUVBLFFBQU1uQixZQUFZO0FBQ2hCcEMsYUFBUyxFQUFFdkIsSUFBSSxDQUFDRCxHQUFMLEVBREs7QUFFaEIrRSxhQUFTLEVBQUVPLFdBRks7QUFHaEIvRSxRQUFJLEVBQUUsS0FIVTtBQUloQkMsV0FBTyxFQUFFO0FBSk8sS0FLYjZFLE9BTGEsQ0FBbEI7O0FBUUExQixrQkFBZ0IsQ0FBQ0MsWUFBRCxDQUFoQjtBQUVBLFNBQU8vSCxJQUFJLENBQUN3RSxhQUFMLENBQW1Cd0MsTUFBbkIsQ0FBMEJlLFlBQTFCLENBQVA7QUFDRCxDQWREOztBQWdCQS9ILElBQUksQ0FBQzRKLEtBQUwsR0FBYUMsS0FBSyxJQUFJO0FBQ3BCLE1BQUlBLEtBQUssQ0FBQ04sSUFBVixFQUFnQjtBQUNkdkosUUFBSSxDQUFDd0UsYUFBTCxDQUFtQm9GLEtBQW5CLENBQXlCO0FBQ3ZCNUMsWUFBTSxFQUFFLFVBQVVsRCxNQUFWLEVBQWtCaUUsWUFBbEIsRUFBZ0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0EsZUFBTzhCLEtBQUssQ0FBQ04sSUFBTixDQUFXTyxLQUFYLENBQWlCLElBQWpCLEVBQXVCLENBQUNoRyxNQUFELEVBQVNpRSxZQUFULENBQXZCLENBQVA7QUFDRDtBQU5zQixLQUF6QjtBQVFEO0FBQ0YsQ0FYRDs7QUFhQS9ILElBQUksQ0FBQytKLElBQUwsR0FBWUYsS0FBSyxJQUFJO0FBQ25CLE1BQUlBLEtBQUssQ0FBQ04sSUFBVixFQUFnQjtBQUNkdkosUUFBSSxDQUFDd0UsYUFBTCxDQUFtQnVGLElBQW5CLENBQXdCO0FBQ3RCL0MsWUFBTSxFQUFFLFVBQVVsRCxNQUFWLEVBQWtCaUUsWUFBbEIsRUFBZ0M7QUFDdEM7QUFDQTtBQUNBO0FBQ0EsZUFBTzhCLEtBQUssQ0FBQ04sSUFBTixDQUFXTyxLQUFYLENBQWlCLElBQWpCLEVBQXVCLENBQUNoRyxNQUFELEVBQVNpRSxZQUFULENBQXZCLENBQVA7QUFDRDtBQU5xQixLQUF4QjtBQVFEO0FBQ0YsQ0FYRCxDOzs7Ozs7Ozs7OztBQ2pHQSxJQUFJTCxhQUFKOztBQUFrQjdILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaLEVBQW1EO0FBQUM2SCxTQUFPLENBQUM1SCxDQUFELEVBQUc7QUFBQzJILGlCQUFhLEdBQUMzSCxDQUFkO0FBQWdCOztBQUE1QixDQUFuRCxFQUFpRixDQUFqRjtBQUFsQkYsTUFBTSxDQUFDK0gsTUFBUCxDQUFjO0FBQUMzSCxrQkFBZ0IsRUFBQyxNQUFJQTtBQUF0QixDQUFkOztBQUFBLE1BQU1BLGdCQUFnQixHQUFHLENBQUNNLE9BQUQsRUFBVW9CLGNBQVYsRUFBMEJJLFFBQTFCLEVBQW9DaUksU0FBcEMsRUFBK0NsSSxTQUEvQyxLQUE2RDtBQUNwRjs7QUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRSxRQUFNbUksZUFBZSxHQUFHbkksU0FBUyxDQUFDc0gsV0FBVixJQUF5QixFQUFqRDtBQUNBLFFBQU1jLFdBQVcsR0FBR3BJLFNBQVMsQ0FBQ3FILE9BQVYsSUFBcUIsRUFBekM7QUFDQSxRQUFNZ0IsV0FBVyxHQUFHckksU0FBUyxDQUFDdUgsT0FBVixJQUFxQixFQUF6QztBQUNBLFFBQU1lLFVBQVUsR0FBR3RJLFNBQVMsQ0FBQ3dGLElBQVYsSUFBa0IsRUFBckM7QUFFQSxRQUFNK0MsSUFBSSxHQUFHO0FBQ1h6SCxXQUFPLEVBQUU7QUFDUDtBQUNBO0FBQ0EwSCxjQUFRLEVBQUV2SSxRQUFRLENBQUN1SSxRQUhaO0FBSVA7QUFDQWhELFVBQUk7QUFDRnhFLGFBQUssRUFBRWhCLFNBQVMsQ0FBQ2dCLEtBRGY7QUFFRk0sWUFBSSxFQUFFdEIsU0FBUyxDQUFDc0IsSUFGZDtBQUdGbUYsWUFBSSxFQUFFekcsU0FBUyxDQUFDeUcsSUFBVixJQUFrQnhHLFFBQVEsQ0FBQ3dHLElBSC9CO0FBSUZDLGFBQUssRUFBRTFHLFNBQVMsQ0FBQzBHLEtBQVYsSUFBbUJ6RyxRQUFRLENBQUN5RyxLQUpqQztBQUtGRixhQUFLLEVBQUV4RyxTQUFTLENBQUN3RyxLQUFWLElBQW1CdkcsUUFBUSxDQUFDdUcsS0FMakM7QUFNRmlDLFdBQUcsWUFBS3pJLFNBQVMsQ0FBQ21ILEtBQWYsQ0FORDtBQU9GO0FBQ0F1QixrQkFBVSxFQUFFMUksU0FBUyxDQUFDMkksU0FBVixJQUF1QjFJLFFBQVEsQ0FBQzBJLFNBQWhDLElBQTZDMUksUUFBUSxDQUFDc0csS0FSaEU7QUFTRnFDLDZCQUFxQixFQUFFNUksU0FBUyxDQUFDNkksb0JBQVYsSUFBa0M1SSxRQUFRLENBQUM0SSxvQkFUaEU7QUFVRkMsa0JBQVUsRUFBRTlJLFNBQVMsQ0FBQzhJLFVBQVYsSUFBd0I3SSxRQUFRLENBQUM2SSxVQVYzQztBQVdGO0FBQ0FDLGFBQUssRUFBRS9JLFNBQVMsQ0FBQ21HLFFBQVYsSUFBc0JsRyxRQUFRLENBQUNrRztBQVpwQyxTQWFDbUMsVUFiRCxHQWNDSCxlQWRELENBTEc7QUFxQlBhLGlCQUFXLEVBQUU7QUFDWEMsdUJBQWUsRUFBRWpKLFNBQVMsQ0FBQ2tKLGNBQVYsSUFBNEJqSixRQUFRLENBQUNpSjtBQUQzQztBQXJCTixLQURFO0FBMEJYQyxRQUFJLEVBQUU7QUFDSkMsYUFBTyxFQUFFO0FBQ1AseUJBQWlCbkosUUFBUSxDQUFDb0o7QUFEbkIsT0FETDtBQUlKQyxhQUFPLEVBQUU7QUFDUEMsV0FBRyxFQUFFO0FBQ0hDLGVBQUssRUFBRTtBQUNMeEksaUJBQUssRUFBRWhCLFNBQVMsQ0FBQ2dCLEtBRFo7QUFFTE0sZ0JBQUksRUFBRXRCLFNBQVMsQ0FBQ3NCLElBRlg7QUFHTCw0QkFBZ0J0QixTQUFTLENBQUM2RyxXQUFWLElBQXlCNUcsUUFBUSxDQUFDNEc7QUFIN0MsV0FESjtBQU1IVCxlQUFLLEVBQUVwRyxTQUFTLENBQUNvRyxLQUFWLElBQW1CbkcsUUFBUSxDQUFDbUcsS0FOaEM7QUFPSEksZUFBSyxFQUFFeEcsU0FBUyxDQUFDd0csS0FBVixhQUFxQnhHLFNBQVMsQ0FBQ3dHLEtBQS9CLFlBQTZDdkcsUUFBUSxDQUFDdUcsS0FBVCxhQUFvQnZHLFFBQVEsQ0FBQ3VHLEtBQTdCLFlBQTJDLEVBUDVGO0FBUUg7QUFDQWhCLGNBQUksOERBQ0N2RixRQUFRLENBQUN1RixJQURWLEdBRUN2RixRQUFRLENBQUNvSCxPQUZWLEdBR0NpQixVQUhELEdBSUNGLFdBSkQ7QUFURDtBQURFLE9BSkw7QUFzQkpZLGlCQUFXLEVBQUU7QUFDWEMsdUJBQWUsRUFBRWpKLFNBQVMsQ0FBQ2tKLGNBQVYsSUFBNEJqSixRQUFRLENBQUNpSixjQUQzQztBQUVYSCxhQUFLLEVBQUUvSSxTQUFTLENBQUNtRyxRQUFWLElBQXNCbEcsUUFBUSxDQUFDa0c7QUFGM0I7QUF0QlQsS0ExQks7QUFxRFhzRCxXQUFPLEVBQUU7QUFDUEwsYUFBTyxFQUFFO0FBQ1BNLGVBQU8sRUFBRSxNQURGO0FBRVBDLFdBQUcsRUFBRTFKLFFBQVEsQ0FBQzJKLE1BRlAsQ0FFYzs7QUFGZCxPQURGO0FBS1BwRSxVQUFJLDhEQUNDdkYsUUFBUSxDQUFDdUYsSUFEVixHQUVDdkYsUUFBUSxDQUFDc0gsT0FGVixHQUdDZSxVQUhELEdBSUNELFdBSkQsQ0FMRztBQVdQcEMsa0JBQVksRUFBRTtBQUNaakYsYUFBSyxFQUFFaEIsU0FBUyxDQUFDZ0IsS0FETDtBQUVaTSxZQUFJLEVBQUV0QixTQUFTLENBQUNzQixJQUZKO0FBR1ptRixZQUFJLEVBQUV6RyxTQUFTLENBQUM2SixPQUFWLElBQXFCNUosUUFBUSxDQUFDNEosT0FIeEI7QUFJWmQsYUFBSyxFQUFFL0ksU0FBUyxDQUFDbUcsUUFBVixJQUFzQmxHLFFBQVEsQ0FBQ2tHO0FBQ3RDO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVhvQixPQVhQO0FBdUJKO0FBQ0g2QyxpQkFBVyxFQUFFO0FBQ1hoTCxZQUFJLEVBQUVnQyxTQUFTLENBQUN3SCxNQUFWLElBQW9CdkgsUUFBUSxDQUFDdUg7QUFEeEI7QUF4Qk47QUFyREUsR0FBYjs7QUFtRkEsTUFBSVUsU0FBSixFQUFlO0FBQ2JLLFFBQUksQ0FBQzVILEtBQUwsR0FBYXVILFNBQWI7QUFDRCxHQUZELE1BRU8sSUFBSUssSUFBSSxDQUFDaEMsS0FBVCxFQUFnQjtBQUNyQmdDLFFBQUksQ0FBQ2hDLEtBQUwsR0FBYXZHLFNBQVMsQ0FBQ3VHLEtBQXZCO0FBQ0QsR0FGTSxNQUVBO0FBQ0wsUUFBSTlILE9BQUosRUFBYTtBQUFFQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSw2Q0FBWjtBQUE0RDs7QUFDM0U7QUFDRDs7QUFFRCxNQUFJRixPQUFKLEVBQWE7QUFBRUMsV0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosRUFBMERtTCxJQUFJLENBQUNDLFNBQUwsQ0FBZXhCLElBQWYsRUFBcUIsSUFBckIsRUFBMkIsQ0FBM0IsQ0FBMUQ7QUFBMEY7O0FBRXpHMUksZ0JBQWMsQ0FBQzRILElBQWYsQ0FBb0JjLElBQXBCLEVBQ0d5QixJQURILENBQ1FDLFFBQVEsSUFBSTtBQUNoQixRQUFJeEwsT0FBSixFQUFhO0FBQUVDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDc0wsUUFBMUM7QUFBcUQ7QUFDckUsR0FISCxFQUlHQyxLQUpILENBSVNyTCxLQUFLLElBQUk7QUFDZCxRQUFJSixPQUFKLEVBQWE7QUFBRUMsYUFBTyxDQUFDQyxHQUFSLENBQVkscUJBQVosRUFBbUNtTCxJQUFJLENBQUNDLFNBQUwsQ0FBZWxMLEtBQWYsRUFBc0IsSUFBdEIsRUFBNEIsQ0FBNUIsQ0FBbkM7QUFBb0U7QUFDcEYsR0FOSDtBQU9ELENBbEhELEMiLCJmaWxlIjoiL3BhY2thZ2VzL2FjdGl2aXRyZWVfcHVzaC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBQdXNoIH0gZnJvbSAnLi9wdXNoVG9EQidcbmltcG9ydCB7IHNlbmROb3RpZmljYXRpb24gfSBmcm9tICcuL25vdGlmaWNhdGlvbidcblxuUHVzaC5zZXRCYWRnZSA9IGZ1bmN0aW9uICgvKiBpZCwgY291bnQgKi8pIHsgLyogdGhyb3cgbmV3IEVycm9yKCdQdXNoLnNldEJhZGdlIG5vdCBpbXBsZW1lbnRlZCBvbiB0aGUgc2VydmVyJyAqLyB9XG5cbmxldCBpc0NvbmZpZ3VyZWQgPSBmYWxzZVxuXG5jb25zdCBzZW5kV29ya2VyID0gKHRhc2ssIGludGVydmFsLCBpc0RlYnVnKSA9PiB7XG4gIGlmIChpc0RlYnVnKSB7XG4gICAgY29uc29sZS5sb2coJ1B1c2g6IFNlbmQgd29ya2VyIHN0YXJ0ZWQsIHVzaW5nIGludGVydmFsOiAnICsgaW50ZXJ2YWwpXG4gIH1cblxuICByZXR1cm4gTWV0ZW9yLnNldEludGVydmFsKCgpID0+IHtcbiAgICB0cnkge1xuICAgICAgdGFzaygpXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChpc0RlYnVnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdQdXNoOiBFcnJvciB3aGlsZSBzZW5kaW5nOicsIGVycm9yLm1lc3NhZ2UpXG4gICAgICB9XG4gICAgfVxuICB9LCBpbnRlcnZhbClcbn1cblxuUHVzaC5Db25maWd1cmUgPSBzZXJ2ZXJDb25maWcgPT4ge1xuICBjb25zdCBpc0RlYnVnID0gUHVzaC5kZWJ1Z1xuICBjb25zdCBzZWxmID0gdGhpc1xuICBpZiAoaXNDb25maWd1cmVkKSB7IHRocm93IG5ldyBFcnJvcignUHVzaC5Db25maWd1cmUgc2hvdWxkIG5vdCBiZSBjYWxsZWQgbW9yZSB0aGFuIG9uY2UhJykgfVxuICBpc0NvbmZpZ3VyZWQgPSB0cnVlXG4gIGlmIChpc0RlYnVnKSB7IGNvbnNvbGUubG9nKCdQdXNoLkNvbmZpZ3VyZScsIHNlcnZlckNvbmZpZykgfVxuXG4gIC8vIFJpZyBGQ00gY29ubmVjdGlvblxuICBjb25zdCBhZG1pbiA9IHJlcXVpcmUoJ2ZpcmViYXNlLWFkbWluJylcbiAgY29uc3QgZmNtID0gYWRtaW4uaW5pdGlhbGl6ZUFwcCh7XG4gICAgY3JlZGVudGlhbDogYWRtaW4uY3JlZGVudGlhbC5jZXJ0KHNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluICYmIHNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluLnNlcnZpY2VBY2NvdW50RGF0YSksXG4gICAgZGF0YWJhc2VVUkw6IHNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluICYmIHNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluLmRhdGFiYXNlVVJMXG4gIH0pXG5cbiAgY29uc3QgZmNtQ29ubmVjdGlvbnMgPSBmY20ubWVzc2FnaW5nKCkgLy8gRkNNIHdpdGggRmlyZWJhc2UgQWRtaW5cbiAgaWYgKHNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluKSB7XG4gICAgaWYgKGlzRGVidWcpIHsgY29uc29sZS5sb2coJ0ZpcmViYXNlIEFkbWluIGZvciBBbmRyb2lkIE1lc3NhZ2luZyBjb25maWd1cmVkJykgfVxuICAgIGlmICghc2VydmVyQ29uZmlnLmZpcmViYXNlQWRtaW4uc2VydmljZUFjY291bnREYXRhKSB7IGNvbnNvbGUuZXJyb3IoJ0VSUk9SOiBQdXNoIHNlcnZlciBjb3VsZCBub3QgZmluZCBBbmRyb2lkIHNlcnZpY2VBY2NvdW50RGF0YSBpbmZvcm1hdGlvbicpIH1cbiAgICBpZiAoIXNlcnZlckNvbmZpZy5maXJlYmFzZUFkbWluLmRhdGFiYXNlVVJMKSB7IGNvbnNvbGUuZXJyb3IoJ0VSUk9SOiBQdXNoIHNlcnZlciBjb3VsZCBub3QgZmluZCBkYXRhYmFzZVVSTCBpbmZvcm1hdGlvbicpIH1cbiAgICBzZWxmLnNlbmROb3RpZmljYXRpb24gPSAodXNlclRva2VucywgbW9uZ29Ob3RlKSA9PiBzZW5kTm90aWZpY2F0aW9uKGlzRGVidWcsIGZjbUNvbm5lY3Rpb25zLCBzZXJ2ZXJDb25maWcuZGVmYXVsdHMsIHVzZXJUb2tlbnMsIG1vbmdvTm90ZSlcbiAgfVxuXG4gIC8qKlxuICAgKiAncXVlcnlTZW5kJyBmdW5jdGlvbnMgZGlzdHJpYnV0ZXMgdGhlIG5vdGlmaWNhdGlvbnMgdG8gYmUgc2VuZCB3aXRoIHRoZSByaWdodFxuICAgKiBwcm92aWRlcnMgYmFzZWQgb24gdGhlIHRva2VucyB0aGV5IGFyZSBzZW5kIHRvXG4gICAqL1xuICBjb25zdCBxdWVyeVNlbmQgPSAocXVlcnksIG1vbmdvTm90ZSkgPT4ge1xuICAgIGNvbnN0IGNvdW50QXBuID0gW11cbiAgICBjb25zdCBjb3VudEFuZHJvaWQgPSBbXVxuICAgIGNvbnN0IGNvdW50V2ViID0gW11cblxuICAgIFB1c2guYXBwQ29sbGVjdGlvbi5maW5kKHF1ZXJ5KS5tYXAoYXBwID0+IHtcbiAgICAgIGlmIChpc0RlYnVnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdTZW5kIHRvIHRva2VuJywgYXBwLnRva2VuKVxuICAgICAgICBpZiAoYXBwLnRva2VuLmFwbikgeyBjb3VudEFwbi5wdXNoKCd4JykgfVxuICAgICAgICBpZiAoYXBwLnRva2VuLmFuZHJvaWQpIHsgY291bnRBbmRyb2lkLnB1c2goJ3gnKSB9XG4gICAgICAgIGlmIChhcHAudG9rZW4ud2ViKSB7IGNvdW50V2ViLnB1c2goJ3gnKSB9XG4gICAgICB9XG4gICAgICBzZWxmLnNlbmROb3RpZmljYXRpb24oYXBwLnRva2VuLmFwbiB8fCBhcHAudG9rZW4uYW5kcm9pZCB8fCBhcHAudG9rZW4ud2ViLCBtb25nb05vdGUpXG4gICAgfSlcblxuICAgIGlmIChpc0RlYnVnKSB7XG4gICAgICBjb25zb2xlLmxvZygnUHVzaDogU2VudCBtZXNzYWdlIFwiJyArIG1vbmdvTm90ZS50aXRsZSArICdcIiB0byAnICsgY291bnRBcG4ubGVuZ3RoICsgJyBpb3MgYXBwcyB8ICcgKyBjb3VudEFuZHJvaWQubGVuZ3RoICsgJyBhbmRyb2lkIGFwcHMgfCAnLCBjb3VudFdlYi5sZW5ndGgsICcgd2ViIGFwcHMnKVxuICAgICAgLy8gQWRkIHNvbWUgdmVyYm9zaXR5IGFib3V0IHRoZSBzZW5kIHJlc3VsdCwgbWFraW5nIHN1cmUgdGhlIGRldmVsb3BlclxuICAgICAgLy8gdW5kZXJzdGFuZHMgd2hhdCBqdXN0IGhhcHBlbmVkLlxuICAgICAgaWYgKCFjb3VudEFwbi5sZW5ndGggJiYgIWNvdW50QW5kcm9pZC5sZW5ndGggJiYgIWNvdW50V2ViLmxlbmd0aCkge1xuICAgICAgICBpZiAoIVB1c2guYXBwQ29sbGVjdGlvbi5maW5kT25lKCkpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygnUHVzaCwgR1VJREU6IFRoZSBcIlB1c2guYXBwQ29sbGVjdGlvblwiIG1pZ2h0IGJlIGVtcHR5LiBObyBjbGllbnRzIGhhdmUgcmVnaXN0ZXJlZCBvbiB0aGUgc2VydmVyIHlldC4uLicpXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoIWNvdW50QXBuLmxlbmd0aCkge1xuICAgICAgICBpZiAoIVB1c2guYXBwQ29sbGVjdGlvbi5maW5kT25lKHsgJ3Rva2VuLmFwbic6IHsgJGV4aXN0czogdHJ1ZSB9IH0pKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coJ1B1c2gsIEdVSURFOiBUaGUgXCJQdXNoLmFwcENvbGxlY3Rpb25cIiAtIE5vIEFQTiBjbGllbnRzIGhhdmUgcmVnaXN0cmVkIG9uIHRoZSBzZXJ2ZXIgeWV0Li4uJylcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghY291bnRBbmRyb2lkLmxlbmd0aCkge1xuICAgICAgICBpZiAoIVB1c2guYXBwQ29sbGVjdGlvbi5maW5kT25lKHsgJ3Rva2VuLmFuZHJvaWQnOiB7ICRleGlzdHM6IHRydWUgfSB9KSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKCdQdXNoLCBHVUlERTogVGhlIFwiUHVzaC5hcHBDb2xsZWN0aW9uXCIgLSBObyBBTkRST0lEIGNsaWVudHMgaGF2ZSByZWdpc3RlcmVkIG9uIHRoZSBzZXJ2ZXIgeWV0Li4uJylcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghY291bnRXZWIubGVuZ3RoKSB7XG4gICAgICAgIGlmICghUHVzaC5hcHBDb2xsZWN0aW9uLmZpbmRPbmUoeyAndG9rZW4ud2ViJzogeyAkZXhpc3RzOiB0cnVlIH0gfSkpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygnUHVzaCwgR1VJREU6IFRoZSBcIlB1c2guYXBwQ29sbGVjdGlvblwiIC0gTm8gV2ViIGNsaWVudHMgaGF2ZSByZWdpc3RlcmVkIG9uIHRoZSBzZXJ2ZXIgeWV0Li4uJylcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBhcG46IGNvdW50QXBuLFxuICAgICAgZmNtOiBjb3VudEFuZHJvaWQsXG4gICAgICB3ZW46IGNvdW50V2ViXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqQ29uc3RydWN0cyBhIHF1ZXJ5IGFuZCBwYXNzZWQgaXQgYXMgcGFyYW1ldGVyIG9uICdxdWVyeVNlbmQnIGZ1bmN0aW9uXG4gICAqIG1vbmdvTm90ZSA9IHRoZSBncm9zcyBub3RpZmljYXRpb24gc2F2ZWQgaW50byBNb25nbywgYmVmb3JlIHNlcmlhbGl6YXRpb24gZm9yIHRoZSB0d28gUHJvdmlkZXJzLCBBUE4gYW5kIEFuZHJvaWRcbiAgICovXG4gIHNlbGYuc2VydmVyU2VuZCA9IG1vbmdvTm90ZSA9PiB7XG4gICAgbGV0IHF1ZXJ5XG4gICAgLy8gc2V0IHNvbWUgbWluaW11bSByZXF1aXJlbWVudHMgZm9yIGEgbm90aWZpY2F0aW9uIHRvIGJlIGVsaWdpYmxlIGZvciBzZW5kaW5nLlxuICAgIC8vIFRPRE8gaW1wbGVtZW50IHNvbWUgY2hlY2tpbmcgZm9yIGRhdGEuIFBlcmhhcHMgbm90IHJpZ2h0IGhlcmUgYnV0IG9uY2UgaW1wbGVtZW50ZWQgcmVtb3ZlIHRoZSBuZXh0IDIgbGluZXNcbiAgICBpZiAobW9uZ29Ob3RlLnRpdGxlICE9PSAnJyArIG1vbmdvTm90ZS50aXRsZSkgeyB0aHJvdyBuZXcgRXJyb3IoJ1B1c2guc2VuZDogb3B0aW9uIFwidGl0bGVcIiBub3QgYSBzdHJpbmcnKSB9XG4gICAgaWYgKG1vbmdvTm90ZS5ib2R5ICE9PSAnJyArIG1vbmdvTm90ZS5ib2R5KSB7IHRocm93IG5ldyBFcnJvcignUHVzaC5zZW5kOiBvcHRpb24gXCJ0ZXh0XCIgbm90IGEgc3RyaW5nJykgfVxuXG4gICAgaWYgKG1vbmdvTm90ZS50b2tlbiB8fCBtb25nb05vdGUudG9rZW5zKSB7XG4gICAgICBjb25zdCB0b2tlbkxpc3QgPSBtb25nb05vdGUudG9rZW4gPyBbbW9uZ29Ob3RlLnRva2VuXSA6IG1vbmdvTm90ZS50b2tlbnNcbiAgICAgIGlmIChpc0RlYnVnKSB7IGNvbnNvbGUubG9nKCdQdXNoOiBTZW5kIG1lc3NhZ2UgXCInICsgbW9uZ29Ob3RlLnRpdGxlICsgJ1wiIHZpYSB0b2tlbihzKScsIHRva2VuTGlzdCkgfVxuICAgICAgcXVlcnkgPSB7XG4gICAgICAgIHRva2VuOiB7ICRpbjogdG9rZW5MaXN0IH0sXG4gICAgICAgIGVuYWJsZWQ6IHsgJG5lOiBmYWxzZSB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChtb25nb05vdGUudG9rZW5JZCB8fCBtb25nb05vdGUudG9rZW5JZHMpIHtcbiAgICAgIGNvbnN0IHRva2VuSWRzTGlzdCA9IG1vbmdvTm90ZS50b2tlbklkID8gW21vbmdvTm90ZS50b2tlbklkXSA6IG1vbmdvTm90ZS50b2tlbklkc1xuICAgICAgaWYgKGlzRGVidWcpIHsgY29uc29sZS5sb2coJ1B1c2g6IFNlbmQgbWVzc2FnZSBcIicgKyBtb25nb05vdGUudGl0bGUgKyAnXCIgdmlhIHRva2VuIElkKHMpJywgdG9rZW5JZHNMaXN0KSB9XG4gICAgICBxdWVyeSA9IHtcbiAgICAgICAgX2lkOiB7ICRpbjogdG9rZW5JZHNMaXN0IH0sXG4gICAgICAgIGVuYWJsZWQ6IHsgJG5lOiBmYWxzZSB9XG4gICAgICB9XG4gICAgICAvKlxuICAgICAgcXVlcnkgPSB7XG4gICAgICAgICRvcjogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgICRhbmQ6IFtcbiAgICAgICAgICAgICAgeyB0b2tlbjogeyAkaW46IHRva2VuTGlzdCB9IH0sXG4gICAgICAgICAgICAgIHsgZW5hYmxlZDogeyAkbmU6IGZhbHNlIH0gfVxuICAgICAgICAgICAgXVxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgJGFuZDogW1xuICAgICAgICAgICAgICB7IF9pZDogeyAkaW46IHRva2VuTGlzdCB9IH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgICAgIHsgJ3Rva2VuLmFwbic6IHsgJGV4aXN0czogdHJ1ZSB9IH0sXG4gICAgICAgICAgICAgICAgICB7ICd0b2tlbi5hbmRyb2lkJzogeyAkZXhpc3RzOiB0cnVlIH0gfSxcbiAgICAgICAgICAgICAgICAgIHsgJ3Rva2VuLndlYic6IHsgJGV4aXN0czogdHJ1ZSB9IH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHsgZW5hYmxlZDogeyAkbmU6IGZhbHNlIH0gfVxuICAgICAgICAgICAgXVxuICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgICAgICovXG4gICAgfSBlbHNlIGlmIChtb25nb05vdGUudXNlcklkIHx8IG1vbmdvTm90ZS51c2VySWRzKSB7XG4gICAgICBjb25zdCB1c2VySWRzTGlzdCA9IG1vbmdvTm90ZS51c2VySWQgPyBbbW9uZ29Ob3RlLnVzZXJJZF0gOiBtb25nb05vdGUudXNlcklkc1xuICAgICAgaWYgKGlzRGVidWcpIHsgY29uc29sZS5sb2coJ1B1c2g6IFNlbmQgbWVzc2FnZSBcIicgKyBtb25nb05vdGUudGl0bGUgKyAnXCIgdG8gdXNlcjogJywgdXNlcklkc0xpc3QpIH1cbiAgICAgIHF1ZXJ5ID0ge1xuICAgICAgICB1c2VySWQ6IHsgJGluOiB1c2VySWRzTGlzdCB9LFxuICAgICAgICBlbmFibGVkOiB7ICRuZTogZmFsc2UgfVxuICAgICAgfVxuICAgICAgLypcbiAgICAgIHF1ZXJ5ID0ge1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgeyB1c2VySWQ6IG1vbmdvTm90ZS51c2VySWQgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgeyAndG9rZW4uYXBuJzogeyAkZXhpc3RzOiB0cnVlIH0gfSxcbiAgICAgICAgICAgICAgeyAndG9rZW4uYW5kcm9pZCc6IHsgJGV4aXN0czogdHJ1ZSB9IH0sXG4gICAgICAgICAgICAgIHsgJ3Rva2VuLndlYic6IHsgJGV4aXN0czogdHJ1ZSB9IH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHsgZW5hYmxlZDogeyAkbmU6IGZhbHNlIH0gfVxuICAgICAgICBdXG4gICAgICB9XG4gICAgICAgKi9cbiAgICB9XG4gICAgaWYgKHF1ZXJ5KSB7XG4gICAgICByZXR1cm4gcXVlcnlTZW5kKHF1ZXJ5LCBtb25nb05vdGUpXG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChpc0RlYnVnKSB7IHRocm93IG5ldyBFcnJvcignUHVzaC5zZW5kOiBwbGVhc2Ugc2V0IG9wdGlvbiB0b2tlbi90b2tlbnMsIHRva2VuSWQvdG9rZW5JZHMsIHVzZXJJZC91c2VySWRzJykgfVxuICAgIH1cbiAgfVxuXG4gIGxldCBpc1NlbmRpbmdOb3RpZmljYXRpb24gPSBmYWxzZVxuXG4gIGlmIChzZXJ2ZXJDb25maWcuZGVmYXVsdHMgJiYgc2VydmVyQ29uZmlnLmRlZmF1bHRzLnNlbmRJbnRlcnZhbCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IHNlbmROb3RpZmljYXRpb24gPSBtb25nb05vdGUgPT4ge1xuICAgICAgLy8gUmVzZXJ2ZSBub3RpZmljYXRpb25cbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KClcbiAgICAgIGNvbnN0IHRpbWVvdXRBdCA9IG5vdyArIHNlcnZlckNvbmZpZy5kZWZhdWx0cyAmJiBzZXJ2ZXJDb25maWcuZGVmYXVsdHMuc2VuZFRpbWVvdXRcbiAgICAgIGNvbnN0IHJlc2VydmVkID0gUHVzaC5ub3RpZmljYXRpb25zLnVwZGF0ZSh7XG4gICAgICAgIF9pZDogbW9uZ29Ob3RlLl9pZCxcbiAgICAgICAgc2VudDogZmFsc2UsXG4gICAgICAgIHNlbmRpbmc6IHsgJGx0OiBub3cgfVxuICAgICAgfSwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgc2VuZGluZzogdGltZW91dEF0XG4gICAgICAgIH1cbiAgICAgIH0pXG5cbiAgICAgIC8vIE1ha2Ugc3VyZSB3ZSBvbmx5IGhhbmRsZSBub3RpZmljYXRpb25zIHJlc2VydmVkIGJ5IHRoaXMgaW5zdGFuY2VcbiAgICAgIGlmIChyZXNlcnZlZCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBzZWxmLnNlcnZlclNlbmQobW9uZ29Ob3RlKVxuICAgICAgICBpZiAoIShzZXJ2ZXJDb25maWcuZGVmYXVsdHMgJiYgc2VydmVyQ29uZmlnLmRlZmF1bHRzLmtlZXBOb3RpZmljYXRpb25zKSkge1xuICAgICAgICAgIFB1c2gubm90aWZpY2F0aW9ucy5yZW1vdmUoeyBfaWQ6IG1vbmdvTm90ZS5faWQgfSlcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBQdXNoLm5vdGlmaWNhdGlvbnMudXBkYXRlKHsgX2lkOiBtb25nb05vdGUuX2lkIH0sIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgc2VudDogdHJ1ZSxcbiAgICAgICAgICAgICAgc2VudEF0OiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgICBjb3VudDogcmVzdWx0LFxuICAgICAgICAgICAgICBzZW5kaW5nOiAwXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgICAvLyBOb3Qgc3VyZSB3aGF0IGlzIHRoaXMgbmV4dCBvbmUgZm9yLiBJbiBteSBlbnZpcm9ubWVudCBzZWxmLmVtaXQgLi4uIGlzIG5vdCBhIGZ1bmN0aW9uLlxuICAgICAgICAvLyBzZWxmLmVtaXQoJ3NlbmQnLCB7IG5vdGlmaWNhdGlvbjogbm90aWZpY2F0aW9uLl9pZCwgcmVzdWx0OiByZXN1bHQgfSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzZW5kV29ya2VyKCgpID0+IHtcbiAgICAgIGlmIChpc1NlbmRpbmdOb3RpZmljYXRpb24pIHsgcmV0dXJuIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGlzU2VuZGluZ05vdGlmaWNhdGlvbiA9IHRydWVcbiAgICAgICAgY29uc3QgYmF0Y2hTaXplID0gKHNlcnZlckNvbmZpZy5kZWZhdWx0cyAmJiBzZXJ2ZXJDb25maWcuZGVmYXVsdHMuc2VuZEJhdGNoU2l6ZSkgfHwgMVxuICAgICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpXG4gICAgICAgIGNvbnN0IHBlbmRpbmdOb3RpZmljYXRpb25zID0gUHVzaC5ub3RpZmljYXRpb25zLmZpbmQoe1xuICAgICAgICAgICRhbmQ6IFtcbiAgICAgICAgICAgIHsgc2VudDogZmFsc2UgfSxcbiAgICAgICAgICAgIHsgc2VuZGluZzogeyAkbHQ6IG5vdyB9IH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICRvcjogW1xuICAgICAgICAgICAgICAgIHsgZGVsYXlVbnRpbDogeyAkZXhpc3RzOiBmYWxzZSB9IH0sXG4gICAgICAgICAgICAgICAgeyBkZWxheVVudGlsOiB7ICRsdGU6IG5vdyB9IH1cbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF1cbiAgICAgICAgfSwge1xuICAgICAgICAgIHNvcnQ6IHsgY3JlYXRlZEF0OiAxIH0sXG4gICAgICAgICAgbGltaXQ6IGJhdGNoU2l6ZVxuICAgICAgICB9KVxuXG4gICAgICAgIHBlbmRpbmdOb3RpZmljYXRpb25zLm1hcChtb25nb05vdGUgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBzZW5kTm90aWZpY2F0aW9uKG1vbmdvTm90ZSlcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKGlzRGVidWcpIHtcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1Nob3cgRnVsbCBlcnJvcicsIGVycm9yKVxuICAgICAgICAgICAgICBjb25zb2xlLmxvZygnUHVzaDogQ291bGQgbm90IHNlbmQgbm90aWZpY2F0aW9uIGlkOiBcIicgKyBtb25nb05vdGUuX2lkICsgJ1wiLCBFcnJvcjogJyArIGVycm9yLm1lc3NhZ2UpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgaXNTZW5kaW5nTm90aWZpY2F0aW9uID0gZmFsc2VcbiAgICAgIH1cbiAgICB9LCAoc2VydmVyQ29uZmlnLmRlZmF1bHRzICYmIHNlcnZlckNvbmZpZy5kZWZhdWx0cy5zZW5kSW50ZXJ2YWwpIHx8IDE1MDAwLCBpc0RlYnVnKVxuICB9IGVsc2Uge1xuICAgIGlmIChpc0RlYnVnKSB7IGNvbnNvbGUubG9nKCdQdXNoOiBTZW5kIHNlcnZlciBpcyBkaXNhYmxlZCcpIH1cbiAgfVxufVxuIiwiLyogZ2xvYmFscyBNb25nbywgUmFuZG9tICovXG5cbmltcG9ydCB7IE1hdGNoLCBjaGVjayB9IGZyb20gJ21ldGVvci9jaGVjaydcbmltcG9ydCB7IFB1c2ggfSBmcm9tICcuL3B1c2hUb0RCJ1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcblxuUHVzaC5hcHBDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ19wdXNoX2FwcF90b2tlbnMnKVxuUHVzaC5hcHBDb2xsZWN0aW9uLl9lbnN1cmVJbmRleCh7IHVzZXJJZDogMSB9KVxuXG5jb25zdCBtYXRjaFRva2VuID0gTWF0Y2guT25lT2YoeyB3ZWI6IFN0cmluZyB9LCB7IGFuZHJvaWQ6IFN0cmluZyB9LCB7IGFwbjogU3RyaW5nIH0sIHsgaW9zOiBTdHJpbmcgfSlcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAncHVzaC11cGRhdGUnOiBmdW5jdGlvbiAob3B0aW9ucykge1xuICAgIGlmIChQdXNoLmRlYnVnKSB7IGNvbnNvbGUubG9nKCdQdXNoOiBHb3QgcHVzaCB0b2tlbiBmcm9tIGFwcDonLCBvcHRpb25zKSB9XG5cbiAgICBjaGVjayhvcHRpb25zLCB7XG4gICAgICBpZDogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICAgIHRva2VuOiBtYXRjaFRva2VuLFxuICAgICAgYXBwTmFtZTogU3RyaW5nLFxuICAgICAgdXNlcklkOiBNYXRjaC5PbmVPZihTdHJpbmcsIG51bGwpLFxuICAgICAgbWV0YWRhdGE6IE1hdGNoLk9wdGlvbmFsKE9iamVjdClcbiAgICB9KVxuXG4gICAgLy8gVGhlIGlmIHVzZXIgaWQgaXMgc2V0IHRoZW4gdXNlciBpZCBzaG91bGQgbWF0Y2ggb24gY2xpZW50IGFuZCBjb25uZWN0aW9uXG4gICAgaWYgKG9wdGlvbnMudXNlcklkICYmIG9wdGlvbnMudXNlcklkICE9PSB0aGlzLnVzZXJJZCkge1xuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcig0MDMsICdGb3JiaWRkZW4gYWNjZXNzJylcbiAgICB9XG5cbiAgICBsZXQgZG9jXG5cbiAgICBpZiAob3B0aW9ucy51c2VySWQpIHtcbiAgICAgIGRvYyA9IFB1c2guYXBwQ29sbGVjdGlvbi5maW5kT25lKHsgdXNlcklkOiBvcHRpb25zLnVzZXJJZCB9KVxuICAgIH1cblxuICAgIC8vIE5vIGRvYyB3YXMgZm91bmQgLSB3ZSBjaGVjayB0aGUgZGF0YWJhc2UgdG8gc2VlIGlmXG4gICAgLy8gd2UgY2FuIGZpbmQgYSBtYXRjaCBmb3IgdGhlIGFwcCB2aWEgdG9rZW4gYW5kIGFwcE5hbWVcbiAgICBpZiAoIWRvYykge1xuICAgICAgZG9jID0gUHVzaC5hcHBDb2xsZWN0aW9uLmZpbmRPbmUoe1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgeyB0b2tlbjogb3B0aW9ucy50b2tlbiB9LCAvLyBNYXRjaCB0b2tlblxuICAgICAgICAgIHsgYXBwTmFtZTogb3B0aW9ucy5hcHBOYW1lIH0sIC8vIE1hdGNoIGFwcE5hbWVcbiAgICAgICAgICB7IHRva2VuOiB7ICRleGlzdHM6IHRydWUgfSB9IC8vIE1ha2Ugc3VyZSB0b2tlbiBleGlzdHNcbiAgICAgICAgXVxuICAgICAgfSlcbiAgICB9XG5cbiAgICAvLyBpZiB3ZSBjb3VsZCBub3QgZmluZCB0aGUgaWQgb3IgdG9rZW4gdGhlbiBjcmVhdGUgaXRcbiAgICBpZiAoIWRvYykge1xuICAgICAgZG9jID0ge1xuICAgICAgICB0b2tlbjogb3B0aW9ucy50b2tlbixcbiAgICAgICAgYXBwTmFtZTogb3B0aW9ucy5hcHBOYW1lLFxuICAgICAgICB1c2VySWQ6IG9wdGlvbnMudXNlcklkLFxuICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICBjcmVhdGVkQXQ6IERhdGUubm93KCksXG4gICAgICAgIHVwZGF0ZWRBdDogRGF0ZS5ub3coKVxuICAgICAgfVxuXG4gICAgICBkb2MuX2lkID0gUmFuZG9tLmlkKClcbiAgICAgIFB1c2guYXBwQ29sbGVjdGlvbi5pbnNlcnQoZG9jLCAoZXJyLCByZXMpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIGlmIChQdXNoLmRlYnVnKSB7IGNvbnNvbGUubG9nKCdJIGhhdmUgYW4gZXJyb3Igd2hlbiBpbnNlcnRpbmcgc29tZXRoaW5nIGludCBoZSBhcHBDb2xsZWN0aW9uLCBzZXJ2ZXIuanMsIGxpbmUgNjA6JywgZXJyKSB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKFB1c2guZGVidWcpIHsgY29uc29sZS5sb2coJ1N1Y2Nlc3NmdWxseSBpbnNlcnRlZCBzb21ldGhpbmcgaW4gdGhlIFB1c2guYXBwQ29sbGVjdGlvbiBhbmQgc2F2ZWQgdG8gbG9jYWwgc3RvcmFnZScsIHJlcykgfVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBQdXNoLmFwcENvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiBkb2MuX2lkIH0sIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgICAgICB0b2tlbjogb3B0aW9ucy50b2tlblxuICAgICAgICB9XG4gICAgICB9LCAoZXJyLCByZXMpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIGlmIChQdXNoLmRlYnVnKSB7IGNvbnNvbGUubG9nKCdJIGhhdmUgYW4gZXJyb3Igd2hlbiB1cGRhdGluZyBzb21ldGhpbmcgaW50IGhlIGFwcENvbGxlY3Rpb24sIHNlcnZlci5qcywgbGluZSA3MzonLCBlcnIpIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoUHVzaC5kZWJ1ZykgeyBjb25zb2xlLmxvZygnU3VjY2Vzc2Z1bGx5IHVwZGF0ZWQgc29tZXRoaW5nIGluIHRoZSBQdXNoLmFwcENvbGxlY3Rpb24nLCByZXMpIH1cbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICBsZXQgcmVtb3ZlZCA9IGZhbHNlXG4gICAgaWYgKGRvYykge1xuICAgICAgUHVzaC5hcHBDb2xsZWN0aW9uLnJlbW92ZSh7XG4gICAgICAgICRhbmQ6IFtcbiAgICAgICAgICB7IF9pZDogeyAkbmU6IGRvYy5faWQgfSB9LFxuICAgICAgICAgIHsgdG9rZW46IGRvYy50b2tlbiB9LFxuICAgICAgICAgIHsgYXBwTmFtZTogZG9jLmFwcE5hbWUgfSxcbiAgICAgICAgICB7IHRva2VuOiB7ICRleGlzdHM6IHRydWUgfSB9XG4gICAgICAgIF1cbiAgICAgIH0sIChlcnIsIHJlcykgPT4ge1xuICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coJ0kgaGF2ZSBhbiBlcnJvciB3aGVuIGRlbGV0aW5nIHNvbWV0aGluZyBpbnQgaGUgYXBwQ29sbGVjdGlvbiwgc2VydmVyLmpzLCBsaW5lIDkwOicsIGVycilcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoUHVzaC5kZWJ1Zykge1xuICAgICAgICAgICAgaWYgKFB1c2guZGVidWcpIHsgY29uc29sZS5sb2coJ1B1c2g6IFJlbW92ZWQgJyArIHJlcyArICcgZXhpc3RpbmcgYXBwIGl0ZW1zJykgfVxuICAgICAgICAgICAgaWYgKHJlcyA+IDApIHtcbiAgICAgICAgICAgICAgcmVtb3ZlZCA9IHRydWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuXG4gICAgaWYgKCFkb2MpIHtcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoNTAwLCAnc2V0UHVzaFRva2VuIGNvdWxkIG5vdCBjcmVhdGUgcmVjb3JkJylcbiAgICB9XG4gICAgLy8gUmV0dXJuIHRoZSBkb2Mgd2Ugd2FudCB0byB1c2VcbiAgICByZXR1cm4geyBkb2MsIHJlbW92ZWQgfVxuICB9LFxuXG4gICdwdXNoLXNldHVzZXInOiBmdW5jdGlvbiAocHVzaFRva2VuREJJZCkge1xuICAgIGlmICghcHVzaFRva2VuREJJZCkge1xuICAgICAgaWYgKFB1c2guZGVidWcpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1B1c2g6IEkgYW0gcHJvYmFibHkgYWZ0ZXIgYW4gQXBwIHVwZGF0ZSB3aGVyZSBJIGluc3RhbGxlZCBhIG5ldyB2ZXJzaW9uIG9mIHRoZSBBcHAnICtcbiAgICAgICAgICAnYW5kIEkgY2xlYXJlZCB0aGUgbG9jYWwgc3RvcmUgYnV0IEkgYW0gc3RpbGwgbG9nZ2VkIHdoZW4gSSBzdGFydCB0aGUgbmV3IHZlcnNpb24gZm9yIHRoZSBmaXJzdCB0aW1lLicgK1xuICAgICAgICAgICdJIHdpbGwgc2tpcCBhIHVzZXIgdXBkYXRlIGluIHRoaXMgc2l0dWF0aW9uLicpXG4gICAgICB9XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgY2hlY2socHVzaFRva2VuREJJZCwgU3RyaW5nKVxuICAgIGlmIChQdXNoLmRlYnVnKSB7XG4gICAgICBjb25zb2xlLmxvZygnUHVzaDogU2V0dGluZ3MgdXNlcklkIFwiJyArIHRoaXMudXNlcklkICsgJ1wiIGZvciBhcHA6JywgcHVzaFRva2VuREJJZClcbiAgICB9XG5cbiAgICBjb25zdCBmb3VuZCA9IFB1c2guYXBwQ29sbGVjdGlvbi51cGRhdGUoeyBfaWQ6IHB1c2hUb2tlbkRCSWQgfSwgeyAkc2V0OiB7IHVzZXJJZDogdGhpcy51c2VySWQgfSB9LCAoZXJyLCByZXMpID0+IHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0kgaGF2ZSBhbiBlcnJvciB3aGVuIHVwZGF0aW5nIHRoZSBGT1VORCAgdGhlIGFwcENvbGxlY3Rpb24sIHNlcnZlci5qcywgbGluZSAxMjA6JywgZXJyKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKFB1c2guZGVidWcpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZygnU3VjY2Vzc2Z1bGx5IHVwZGF0ZWQgdGhlIEZPVU5EIGluIHRoZSBQdXNoLmFwcENvbGxlY3Rpb24nLCByZXMpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgcmV0dXJuICEhZm91bmRcbiAgfSxcblxuICAncHVzaC1tZXRhZGF0YSc6IGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgY2hlY2soZGF0YSwge1xuICAgICAgaWQ6IFN0cmluZyxcbiAgICAgIG1ldGFkYXRhOiBPYmplY3RcbiAgICB9KVxuXG4gICAgLy8gU2V0IHRoZSBtZXRhZGF0YVxuICAgIGNvbnN0IGZvdW5kID0gUHVzaC5hcHBDb2xsZWN0aW9uLnVwZGF0ZSh7IF9pZDogZGF0YS5pZCB9LCB7ICRzZXQ6IHsgbWV0YWRhdGE6IGRhdGEubWV0YWRhdGEgfSB9KVxuXG4gICAgcmV0dXJuICEhZm91bmRcbiAgfSxcblxuICAncHVzaC1lbmFibGUnOiBmdW5jdGlvbiAoZGF0YSkge1xuICAgIGNoZWNrKGRhdGEsIHtcbiAgICAgIGlkOiBTdHJpbmcsXG4gICAgICBlbmFibGVkOiBCb29sZWFuXG4gICAgfSlcblxuICAgIGlmIChQdXNoLmRlYnVnKSB7XG4gICAgICBjb25zb2xlLmxvZygnUHVzaDogU2V0dGluZyBlbmFibGVkIHRvIFwiJyArIGRhdGEuZW5hYmxlZCArICdcIiBmb3IgYXBwOicsIGRhdGEuaWQpXG4gICAgfVxuXG4gICAgY29uc3QgZm91bmQgPSBQdXNoLmFwcENvbGxlY3Rpb24udXBkYXRlKHsgX2lkOiBkYXRhLmlkIH0sIHsgJHNldDogeyBlbmFibGVkOiBkYXRhLmVuYWJsZWQgfSB9KVxuXG4gICAgcmV0dXJuICEhZm91bmRcbiAgfSxcblxuICAncHVzaC1jaGVjay1pcy1lbmFibGVkJzogZnVuY3Rpb24gKGRhdGEpIHtcbiAgICBjaGVjayhkYXRhLCB7XG4gICAgICBpZDogU3RyaW5nLFxuICAgICAgZW5hYmxlZDogQm9vbGVhblxuICAgIH0pXG5cbiAgICBpZiAoUHVzaC5kZWJ1Zykge1xuICAgICAgY29uc29sZS5sb2coJ1B1c2g6IFNldHRpbmcgZW5hYmxlZCB0byBcIicgKyBkYXRhLmVuYWJsZWQgKyAnXCIgZm9yIGFwcDonLCBkYXRhLmlkKVxuICAgIH1cblxuICAgIGNvbnN0IGZvdW5kID0gUHVzaC5hcHBDb2xsZWN0aW9uLmZpbmRPbmUoeyBfaWQ6IGRhdGEuaWQsIGVuYWJsZWQ6IHsgJGV4aXN0czogdHJ1ZSB9IH0sIHsgZmllbGRzOiB7IGVuYWJsZWQ6IDEgfSB9KVxuXG4gICAgcmV0dXJuIGZvdW5kICYmIGZvdW5kLmVuYWJsZWRcbiAgfSxcblxuICAncHVzaC11bnN1Yi13ZWJwdXNoJzogZnVuY3Rpb24gKHB1c2hUb2tlbklkKSB7XG4gICAgY2hlY2socHVzaFRva2VuSWQsIFN0cmluZylcbiAgICByZXR1cm4gUHVzaC5hcHBDb2xsZWN0aW9uLnJlbW92ZSh7IF9pZDogcHVzaFRva2VuSWQgfSlcbiAgfVxufSlcbiIsIi8vIFRoaXMgaXMgdGhlIG1hdGNoIHBhdHRlcm4gZm9yIHRva2Vuc1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xuaW1wb3J0IHsgTWF0Y2gsIGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuXG5mdW5jdGlvbiBFdmVudFN0YXRlICgpIHt9XG5cbmNvbnN0IFB1c2ggPSBuZXcgRXZlbnRTdGF0ZSgpXG5cblB1c2gubm90aWZpY2F0aW9ucyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdfcHVzaF9ub3RpZmljYXRpb25zJylcblB1c2gubm90aWZpY2F0aW9ucy5fZW5zdXJlSW5kZXgoeyBjcmVhdGVkQXQ6IDEgfSlcblB1c2gubm90aWZpY2F0aW9ucy5fZW5zdXJlSW5kZXgoeyBzZW50OiAxIH0pXG5QdXNoLm5vdGlmaWNhdGlvbnMuX2Vuc3VyZUluZGV4KHsgc2VuZGluZzogMSB9KVxuUHVzaC5ub3RpZmljYXRpb25zLl9lbnN1cmVJbmRleCh7IGRlbGF5VW50aWw6IDEgfSlcblB1c2gubm90aWZpY2F0aW9ucy5fZW5zdXJlSW5kZXgoeyB1c2VySWQ6IDEgfSlcblxuY29uc3QgdmFsaWRhdGVEb2N1bWVudCA9IG5vdGlmaWNhdGlvbiA9PiB7XG4gIGNvbnN0IG1hdGNoVG9rZW4gPSBNYXRjaC5PbmVPZih7IGFwbjogU3RyaW5nIH0sIHsgYW5kcm9pZDogU3RyaW5nIH0sIHsgd2ViOiBTdHJpbmcgfSlcbiAgY2hlY2sobm90aWZpY2F0aW9uLCB7XG4gICAgZnJvbTogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICB0aXRsZTogU3RyaW5nLFxuICAgIGJvZHk6IFN0cmluZyxcbiAgICBpbWFnZVVybDogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICBiYWRnZTogTWF0Y2guT3B0aW9uYWwoTWF0Y2guSW50ZWdlciksXG4gICAgdXNlcklkOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIHVzZXJJZHM6IE1hdGNoLk9wdGlvbmFsKEFycmF5KSxcbiAgICB0b2tlbjogTWF0Y2guT3B0aW9uYWwobWF0Y2hUb2tlbiksXG4gICAgdG9rZW5zOiBNYXRjaC5PcHRpb25hbChbbWF0Y2hUb2tlbl0pLFxuICAgIHRva2VuSWQ6IE1hdGNoLk9wdGlvbmFsKFN0cmluZyksXG4gICAgdG9rZW5JZHM6IE1hdGNoLk9wdGlvbmFsKEFycmF5KSxcbiAgICB0b3BpYzogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSwgLy8gbWFuZGF0b3J5IGZvciBJT1MgKHZpYSBpbml0aWFsaXphdGlvbiksIG9wdGlvbmFsIGZvciBBbmRyb2lkIChjYW4gc2VuZCB0byBhIHRvcGljIGluc3RlYWQgb2YgdG9rZW4ocylcbiAgICBzb3VuZDogTWF0Y2guT3B0aW9uYWwoU3RyaW5nKSxcbiAgICBpY29uOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIGNvbG9yOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIHZpYnJhdGU6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgIGNvbnRlbnRBdmFpbGFibGU6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgIGxhdW5jaEltYWdlOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIGNhdGVnb3J5OiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIHRocmVhZElkOiBNYXRjaC5PcHRpb25hbChTdHJpbmcpLFxuICAgIHNlbnQ6IE1hdGNoLk9wdGlvbmFsKEJvb2xlYW4pLFxuICAgIHNlbmRpbmc6IE1hdGNoLk9wdGlvbmFsKE1hdGNoLkludGVnZXIpLFxuICAgIGRlbGF5VW50aWw6IE1hdGNoLk9wdGlvbmFsKE1hdGNoLldoZXJlKHRpbWVzdGFtcCA9PiAobmV3IERhdGUodGltZXN0YW1wKSkuZ2V0VGltZSgpID4gMCkpLCAvLyBsaWtlIERhdGUubm93KClcbiAgICBub3RJZDogTWF0Y2guT3B0aW9uYWwoTWF0Y2guSW50ZWdlciksXG4gICAgY3JlYXRlZEF0OiBNYXRjaC5XaGVyZSh0aW1lc3RhbXAgPT4gKG5ldyBEYXRlKHRpbWVzdGFtcCkpLmdldFRpbWUoKSA+IDApLCAvLyBsaWtlIERhdGUubm93KClcbiAgICBjcmVhdGVkQnk6IE1hdGNoLk9uZU9mKFN0cmluZywgbnVsbCksXG4gICAgZGF0YTogTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSwgLy8gTWFrZSBzdXJlIHRoaXMgb2JqZWN0IG9ubHkgY29udGFpbnMgc3RyaW5nIGtleXMuXG4gICAgaW9zRGF0YTogTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSxcbiAgICBhbmRyb2lkRGF0YTogTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSwgLy8gQW5kcm9pZCBkYXRhIGNhIG9ubHkgdGFrZSBzdHJpbmcgdmFsdWVzIGRvIGZ1cnRoZXIgdmFsaWRhdGlvbiBoZXJlXG4gICAgd2ViRGF0YTogTWF0Y2guT3B0aW9uYWwoT2JqZWN0KSxcbiAgICBhY3Rpb246IE1hdGNoLk9wdGlvbmFsKFN0cmluZylcbiAgfSlcblxuICAvLyBNYWtlIHN1cmUgYSB0b2tlbiBzZWxlY3RvciBvciBxdWVyeSBoYXZlIGJlZW4gc2V0XG4gIGlmICghbm90aWZpY2F0aW9uLnRva2VuICYmICFub3RpZmljYXRpb24udG9rZW5zICYmICFub3RpZmljYXRpb24udXNlcklkICYmICFub3RpZmljYXRpb24udXNlcklkcyAmJiAhbm90aWZpY2F0aW9uLnRva2VuSWQgJiYgIW5vdGlmaWNhdGlvbi50b2tlbklkcykge1xuICAgIHRocm93IG5ldyBFcnJvcignTm8gdG9rZW4gc2VsZWN0b3Igb3IgdXNlciBmb3VuZCcpXG4gIH1cblxuICAvLyBJZiB0b2tlbnMgYXJyYXkgaXMgc2V0IGl0IHNob3VsZCBub3QgYmUgZW1wdHlcbiAgaWYgKG5vdGlmaWNhdGlvbi51c2VySWRzICYmICFub3RpZmljYXRpb24udXNlcklkcy5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHRva2VucyBpbiBhcnJheScpXG4gIH1cblxuICAvLyBJZiB0b2tlbnMgYXJyYXkgaXMgc2V0IGl0IHNob3VsZCBub3QgYmUgZW1wdHlcbiAgaWYgKG5vdGlmaWNhdGlvbi50b2tlbnMgJiYgIW5vdGlmaWNhdGlvbi50b2tlbnMubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdObyB0b2tlbnMgaW4gYXJyYXknKVxuICB9XG59XG5cblB1c2guc2VuZCA9IGNvbnRlbnQgPT4ge1xuICBjb25zdCBjdXJyZW50VXNlciA9IChNZXRlb3IuaXNDbGllbnQgJiYgTWV0ZW9yLnVzZXJJZCgpKSB8fCAoTWV0ZW9yLmlzU2VydmVyICYmIChjb250ZW50LmNyZWF0ZWRCeSB8fCAnPFNFUlZFUj4nKSkgfHwgbnVsbFxuXG4gIGNvbnN0IG5vdGlmaWNhdGlvbiA9IHtcbiAgICBjcmVhdGVkQXQ6IERhdGUubm93KCksXG4gICAgY3JlYXRlZEJ5OiBjdXJyZW50VXNlcixcbiAgICBzZW50OiBmYWxzZSxcbiAgICBzZW5kaW5nOiAwLFxuICAgIC4uLmNvbnRlbnRcbiAgfVxuXG4gIHZhbGlkYXRlRG9jdW1lbnQobm90aWZpY2F0aW9uKVxuXG4gIHJldHVybiBQdXNoLm5vdGlmaWNhdGlvbnMuaW5zZXJ0KG5vdGlmaWNhdGlvbilcbn1cblxuUHVzaC5hbGxvdyA9IHJ1bGVzID0+IHtcbiAgaWYgKHJ1bGVzLnNlbmQpIHtcbiAgICBQdXNoLm5vdGlmaWNhdGlvbnMuYWxsb3coe1xuICAgICAgaW5zZXJ0OiBmdW5jdGlvbiAodXNlcklkLCBub3RpZmljYXRpb24pIHtcbiAgICAgICAgLy8gVmFsaWRhdGUgdGhlIG5vdGlmaWNhdGlvblxuICAgICAgICAvLyB2YWxpZGF0ZURvY3VtZW50KG5vdGlmaWNhdGlvbilcbiAgICAgICAgLy8gU2V0IHRoZSB1c2VyIGRlZmluZWQgXCJzZW5kXCIgcnVsZXNcbiAgICAgICAgcmV0dXJuIHJ1bGVzLnNlbmQuYXBwbHkodGhpcywgW3VzZXJJZCwgbm90aWZpY2F0aW9uXSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG59XG5cblB1c2guZGVueSA9IHJ1bGVzID0+IHtcbiAgaWYgKHJ1bGVzLnNlbmQpIHtcbiAgICBQdXNoLm5vdGlmaWNhdGlvbnMuZGVueSh7XG4gICAgICBpbnNlcnQ6IGZ1bmN0aW9uICh1c2VySWQsIG5vdGlmaWNhdGlvbikge1xuICAgICAgICAvLyBWYWxpZGF0ZSB0aGUgbm90aWZpY2F0aW9uXG4gICAgICAgIC8vIHZhbGlkYXRlRG9jdW1lbnQobm90aWZpY2F0aW9uKVxuICAgICAgICAvLyBTZXQgdGhlIHVzZXIgZGVmaW5lZCBcInNlbmRcIiBydWxlc1xuICAgICAgICByZXR1cm4gcnVsZXMuc2VuZC5hcHBseSh0aGlzLCBbdXNlcklkLCBub3RpZmljYXRpb25dKVxuICAgICAgfVxuICAgIH0pXG4gIH1cbn1cblxuZXhwb3J0IHsgUHVzaCB9XG4iLCJjb25zdCBzZW5kTm90aWZpY2F0aW9uID0gKGlzRGVidWcsIGZjbUNvbm5lY3Rpb25zLCBkZWZhdWx0cywgdXNlclRva2VuLCBtb25nb05vdGUpID0+IHtcbiAgLy8gaHR0cHM6Ly9maXJlYmFzZS5nb29nbGUuY29tL2RvY3MvcmVmZXJlbmNlL2ZjbS9yZXN0L3YxL3Byb2plY3RzLm1lc3NhZ2VzXG4gIC8qKlxuICAgKiBGb3IgQW5kcm9pZCwgdGhlIGVudGlyZSBub3RpZmljYXRpb24gZ29lcyBpbnRvICdkYXRhJyBhcyBwZXIgdGhlIGJlc3QgcHJhY3RpY2VzIG9mIGNvcmRvdmEtcHVzaC1wbHVnaW5cbiAgICogQWxsIGNvbW1lbnRlZCBmaWVsZHMgYXJlIHBhcnQgb2YgdGhlIEZpcmViYXNlLUFkbWluIGJ1dCBhcmUgbm90IG5lY2Vzc2FyeSBmb3IgdGhlIHByZXNlbnQgc2V0dXAuIEZvciBleGFtcGxlLCBhbGwga2V5cyBvZiB0aGVcbiAgICogJ2RhdGEnIG9iamVjdCBtdXN0IGJlIHN0cmluZ3Mgd2hpbGUgaW4gRmlyZWJhc2UtQWRtaW4gc29tZSBrZXlzIHdoaWNoIHdvdWxkIG5vcm1hbGx5IGdvIHVuZGVyICdub3RpZmljYXRpb24nLCBhcmUgYm9vbGVhbi5cbiAgICogSSBrZWVwIHRoZSBjb21tZW50ZWQgZmllbGRzIGp1c3QgYXMgcXVpY2sgcmVmZXJlbmNlIGZvciB0aGUgc3RhbmRhcmQuXG4gICAqL1xuICBjb25zdCBub3RlQW5kcm9pZERhdGEgPSBtb25nb05vdGUuYW5kcm9pZERhdGEgfHwge31cbiAgY29uc3Qgbm90ZUlvc0RhdGEgPSBtb25nb05vdGUuaW9zRGF0YSB8fCB7fVxuICBjb25zdCBub3RlV2ViRGF0YSA9IG1vbmdvTm90ZS53ZWJEYXRhIHx8IHt9XG4gIGNvbnN0IGdsb2JhbERhdGEgPSBtb25nb05vdGUuZGF0YSB8fCB7fVxuXG4gIGNvbnN0IG5vdGUgPSB7XG4gICAgYW5kcm9pZDoge1xuICAgICAgLy8gdHRsOiAnODY0MDBzJywgLy8gdXNlIGRlZmF1bHQgbWF4IG9mIDQgd2Vla3NcbiAgICAgIC8vIGNvbGxhcHNlX2tleTogc3RyaW5nLFxuICAgICAgcHJpb3JpdHk6IGRlZmF1bHRzLnByaW9yaXR5LFxuICAgICAgLy8gcmVzdHJpY3RlZF9wYWNrYWdlX25hbWU6IHN0cmluZyxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgdGl0bGU6IG1vbmdvTm90ZS50aXRsZSxcbiAgICAgICAgYm9keTogbW9uZ29Ob3RlLmJvZHksXG4gICAgICAgIGljb246IG1vbmdvTm90ZS5pY29uIHx8IGRlZmF1bHRzLmljb24sXG4gICAgICAgIGNvbG9yOiBtb25nb05vdGUuY29sb3IgfHwgZGVmYXVsdHMuY29sb3IsXG4gICAgICAgIHNvdW5kOiBtb25nb05vdGUuc291bmQgfHwgZGVmYXVsdHMuc291bmQsXG4gICAgICAgIHRhZzogYCR7bW9uZ29Ob3RlLm5vdElkfWAsXG4gICAgICAgIC8vIGNsaWNrX2FjdGlvbjogbW9uZ29Ob3RlLmFjdGlvblxuICAgICAgICBjaGFubmVsX2lkOiBtb25nb05vdGUuY2hhbm5lbElkIHx8IGRlZmF1bHRzLmNoYW5uZWxJZCB8fCBkZWZhdWx0cy50b3BpYyxcbiAgICAgICAgbm90aWZpY2F0aW9uX3ByaW9yaXR5OiBtb25nb05vdGUubm90aWZpY2F0aW9uUHJpb3JpdHkgfHwgZGVmYXVsdHMubm90aWZpY2F0aW9uUHJpb3JpdHksXG4gICAgICAgIHZpc2liaWxpdHk6IG1vbmdvTm90ZS52aXNpYmlsaXR5IHx8IGRlZmF1bHRzLnZpc2liaWxpdHksXG4gICAgICAgIC8vIG5vdGlmaWNhdGlvbl9jb3VudDogbW9uZ29Ob3RlLmJhZGdlIHx8IGRlZmF1bHRzLmJhZGdlLCAvLyB0aGlzIGlzIHN1cHBvc2VkIHRvIGJlIGEgbnVtYmVyLCBjYW4ndCBzZW5kIGl0IGJlY2F1c2UgSSBuZWVkIGl0IHRvIGJlIGEgc3RyaW5nLlxuICAgICAgICBpbWFnZTogbW9uZ29Ob3RlLmltYWdlVXJsIHx8IGRlZmF1bHRzLmltYWdlVXJsLFxuICAgICAgICAuLi5nbG9iYWxEYXRhLFxuICAgICAgICAuLi5ub3RlQW5kcm9pZERhdGFcbiAgICAgIH0sXG4gICAgICBmY21fb3B0aW9uczoge1xuICAgICAgICBhbmFseXRpY3NfbGFiZWw6IG1vbmdvTm90ZS5hbmFseXRpY3NMYWJlbCB8fCBkZWZhdWx0cy5hbmFseXRpY3NMYWJlbFxuICAgICAgfVxuICAgIH0sXG4gICAgYXBuczoge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnYXBucy1wcmlvcml0eSc6IGRlZmF1bHRzLmFwbnNQcmlvcml0eVxuICAgICAgfSxcbiAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgYXBzOiB7XG4gICAgICAgICAgYWxlcnQ6IHtcbiAgICAgICAgICAgIHRpdGxlOiBtb25nb05vdGUudGl0bGUsXG4gICAgICAgICAgICBib2R5OiBtb25nb05vdGUuYm9keSxcbiAgICAgICAgICAgICdsYXVuY2gtaW1hZ2UnOiBtb25nb05vdGUubGF1bmNoSW1hZ2UgfHwgZGVmYXVsdHMubGF1bmNoSW1hZ2VcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJhZGdlOiBtb25nb05vdGUuYmFkZ2UgfHwgZGVmYXVsdHMuYmFkZ2UsXG4gICAgICAgICAgc291bmQ6IG1vbmdvTm90ZS5zb3VuZCA/IGAke21vbmdvTm90ZS5zb3VuZH0uY2FmYCA6IGRlZmF1bHRzLnNvdW5kID8gYCR7ZGVmYXVsdHMuc291bmR9LmNhZmAgOiAnJyxcbiAgICAgICAgICAvLyAnY2xpY2stYWN0aW9uJyAvLyBUT0RPIGNoZWNrIG9uIHRoaXMsXG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgLi4uZGVmYXVsdHMuZGF0YSxcbiAgICAgICAgICAgIC4uLmRlZmF1bHRzLmlvc0RhdGEsXG4gICAgICAgICAgICAuLi5nbG9iYWxEYXRhLFxuICAgICAgICAgICAgLi4ubm90ZUlvc0RhdGFcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBmY21fb3B0aW9uczoge1xuICAgICAgICBhbmFseXRpY3NfbGFiZWw6IG1vbmdvTm90ZS5hbmFseXRpY3NMYWJlbCB8fCBkZWZhdWx0cy5hbmFseXRpY3NMYWJlbCxcbiAgICAgICAgaW1hZ2U6IG1vbmdvTm90ZS5pbWFnZVVybCB8fCBkZWZhdWx0cy5pbWFnZVVybFxuICAgICAgfVxuICAgIH0sXG4gICAgd2VicHVzaDoge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICBVcmdlbmN5OiAnaGlnaCcsXG4gICAgICAgIFRUTDogZGVmYXVsdHMud2ViVFRMIC8vIG1hbmRhdG9yeSwgaW4gc2Vjb25kc1xuICAgICAgfSxcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgLi4uZGVmYXVsdHMuZGF0YSxcbiAgICAgICAgLi4uZGVmYXVsdHMud2ViRGF0YSxcbiAgICAgICAgLi4uZ2xvYmFsRGF0YSxcbiAgICAgICAgLi4ubm90ZVdlYkRhdGFcbiAgICAgIH0sXG4gICAgICBub3RpZmljYXRpb246IHtcbiAgICAgICAgdGl0bGU6IG1vbmdvTm90ZS50aXRsZSxcbiAgICAgICAgYm9keTogbW9uZ29Ob3RlLmJvZHksXG4gICAgICAgIGljb246IG1vbmdvTm90ZS53ZWJJY29uIHx8IGRlZmF1bHRzLndlYkljb24sXG4gICAgICAgIGltYWdlOiBtb25nb05vdGUuaW1hZ2VVcmwgfHwgZGVmYXVsdHMuaW1hZ2VVcmxcbiAgICAgICAgLypcbiAgICAgICAgYWN0aW9uczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGFjdGlvbjogbW9uZ29Ob3RlLmFjdGlvbiB8fCBkZWZhdWx0cy5hY3Rpb24sXG4gICAgICAgICAgICB0aXRsZTogJ0Jvb2sgQXBwb2ludG1lbnQnXG4gICAgICAgICAgfVxuICAgICAgICBdICovXG4gICAgICB9LCAvLyBDYW4gdGFrZSB2YWx1ZWQgZnJvbSBoZXJlOiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvTm90aWZpY2F0aW9uLlxuICAgICAgZmNtX29wdGlvbnM6IHtcbiAgICAgICAgbGluazogbW9uZ29Ob3RlLmFjdGlvbiB8fCBkZWZhdWx0cy5hY3Rpb25cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpZiAodXNlclRva2VuKSB7XG4gICAgbm90ZS50b2tlbiA9IHVzZXJUb2tlblxuICB9IGVsc2UgaWYgKG5vdGUudG9waWMpIHtcbiAgICBub3RlLnRvcGljID0gbW9uZ29Ob3RlLnRvcGljXG4gIH0gZWxzZSB7XG4gICAgaWYgKGlzRGVidWcpIHsgY29uc29sZS5sb2coJ01pc3Npbmcgc2NvcGUsIG5vIHRva2VuIG9yIHRvcGljIHRvIHNlbmQgdG8nKSB9XG4gICAgcmV0dXJuXG4gIH1cblxuICBpZiAoaXNEZWJ1ZykgeyBjb25zb2xlLmxvZygnRmluYWwgbm90aWZpY2F0aW9uIHJpZ2h0IGJlZm9yZSBzaG9vdCBvdXQ6JywgSlNPTi5zdHJpbmdpZnkobm90ZSwgbnVsbCwgNikpIH1cblxuICBmY21Db25uZWN0aW9ucy5zZW5kKG5vdGUpXG4gICAgLnRoZW4ocmVzcG9uc2UgPT4ge1xuICAgICAgaWYgKGlzRGVidWcpIHsgY29uc29sZS5sb2coJ1N1Y2Nlc3NmdWxseSBzZW50IG1lc3NhZ2U6JywgcmVzcG9uc2UpIH1cbiAgICB9KVxuICAgIC5jYXRjaChlcnJvciA9PiB7XG4gICAgICBpZiAoaXNEZWJ1ZykgeyBjb25zb2xlLmxvZygnRkNNIFNlbmRpbmcgRXJyb3I6ICcsIEpTT04uc3RyaW5naWZ5KGVycm9yLCBudWxsLCA0KSkgfVxuICAgIH0pXG59XG5cbmV4cG9ydCB7IHNlbmROb3RpZmljYXRpb24gfVxuIl19
