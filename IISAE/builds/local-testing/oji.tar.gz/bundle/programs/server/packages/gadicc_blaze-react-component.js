(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var _ = Package.underscore._;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var blazeToReact, BlazeReactComponent;

var require = meteorInstall({"node_modules":{"meteor":{"gadicc:blaze-react-component":{"blaze-react-component-server.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////
//                                                                                       //
// packages/gadicc_blaze-react-component/blaze-react-component-server.js                 //
//                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////
                                                                                         //
let _extends;

module.link("@babel/runtime/helpers/extends", {
  default(v) {
    _extends = v;
  }

}, 0);
module.export({
  blazeToReact: () => blazeToReact
});
let React, Component;
module.link("react", {
  default(v) {
    React = v;
  },

  Component(v) {
    Component = v;
  }

}, 0);
let ReactDOM;
module.link("react-dom", {
  default(v) {
    ReactDOM = v;
  }

}, 1);
let Blaze;
module.link("meteor/blaze", {
  Blaze(v) {
    Blaze = v;
  }

}, 2);
let ReactiveVar;
module.link("meteor/reactive-var", {
  ReactiveVar(v) {
    ReactiveVar = v;
  }

}, 3);

const BlazeComponent = props => {
  const html = {
    __html: Blaze.toHTMLWithData(props.template, _.omit(props, 'template'))
  };
  return /*#__PURE__*/React.createElement("span", {
    dangerouslySetInnerHTML: html
  });
};

module.runSetters(blazeToReact = function (template) {
  return props => /*#__PURE__*/React.createElement(BlazeComponent, _extends({}, props, {
    template: template
  }));
});
module.exportDefault(BlazeComponent);
///////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/gadicc:blaze-react-component/blaze-react-component-server.js");

/* Exports */
Package._define("gadicc:blaze-react-component", exports, {
  BlazeReactComponent: BlazeReactComponent,
  blazeToReact: blazeToReact
});

})();

//# sourceURL=meteor://💻app/packages/gadicc_blaze-react-component.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZ2FkaWNjOmJsYXplLXJlYWN0LWNvbXBvbmVudC9ibGF6ZS1yZWFjdC1jb21wb25lbnQtc2VydmVyLmpzIl0sIm5hbWVzIjpbIl9leHRlbmRzIiwibW9kdWxlIiwibGluayIsImRlZmF1bHQiLCJ2IiwiZXhwb3J0IiwiYmxhemVUb1JlYWN0IiwiUmVhY3QiLCJDb21wb25lbnQiLCJSZWFjdERPTSIsIkJsYXplIiwiUmVhY3RpdmVWYXIiLCJCbGF6ZUNvbXBvbmVudCIsInByb3BzIiwiaHRtbCIsIl9faHRtbCIsInRvSFRNTFdpdGhEYXRhIiwidGVtcGxhdGUiLCJfIiwib21pdCIsImV4cG9ydERlZmF1bHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsUUFBSjs7QUFBYUMsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0osWUFBUSxHQUFDSSxDQUFUO0FBQVc7O0FBQXZCLENBQTdDLEVBQXNFLENBQXRFO0FBQWJILE1BQU0sQ0FBQ0ksTUFBUCxDQUFjO0FBQUNDLGNBQVksRUFBQyxNQUFJQTtBQUFsQixDQUFkO0FBQStDLElBQUlDLEtBQUosRUFBVUMsU0FBVjtBQUFvQlAsTUFBTSxDQUFDQyxJQUFQLENBQVksT0FBWixFQUFvQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDRyxTQUFLLEdBQUNILENBQU47QUFBUSxHQUFwQjs7QUFBcUJJLFdBQVMsQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLGFBQVMsR0FBQ0osQ0FBVjtBQUFZOztBQUE5QyxDQUFwQixFQUFvRSxDQUFwRTtBQUF1RSxJQUFJSyxRQUFKO0FBQWFSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0ssWUFBUSxHQUFDTCxDQUFUO0FBQVc7O0FBQXZCLENBQXhCLEVBQWlELENBQWpEO0FBQW9ELElBQUlNLEtBQUo7QUFBVVQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxPQUFLLENBQUNOLENBQUQsRUFBRztBQUFDTSxTQUFLLEdBQUNOLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSU8sV0FBSjtBQUFnQlYsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ1MsYUFBVyxDQUFDUCxDQUFELEVBQUc7QUFBQ08sZUFBVyxHQUFDUCxDQUFaO0FBQWM7O0FBQTlCLENBQWxDLEVBQWtFLENBQWxFOztBQUt2UixNQUFNUSxjQUFjLEdBQUlDLEtBQUQsSUFBVztBQUNoQyxRQUFNQyxJQUFJLEdBQUc7QUFDWEMsVUFBTSxFQUFFTCxLQUFLLENBQUNNLGNBQU4sQ0FDTkgsS0FBSyxDQUFDSSxRQURBLEVBRU5DLENBQUMsQ0FBQ0MsSUFBRixDQUFPTixLQUFQLEVBQWMsVUFBZCxDQUZNO0FBREcsR0FBYjtBQU9BLHNCQUFTO0FBQU0sMkJBQXVCLEVBQUVDO0FBQS9CLElBQVQ7QUFDRCxDQVREOztBQVdBLGtCQUFBUixZQUFZLEdBQUcsVUFBU1csUUFBVCxFQUFtQjtBQUNoQyxTQUFRSixLQUFELGlCQUFXLG9CQUFDLGNBQUQsZUFBb0JBLEtBQXBCO0FBQTJCLFlBQVEsRUFBRUk7QUFBckMsS0FBbEI7QUFDRCxDQUZEO0FBaEJBaEIsTUFBTSxDQUFDbUIsYUFBUCxDQXFCZVIsY0FyQmYsRSIsImZpbGUiOiIvcGFja2FnZXMvZ2FkaWNjX2JsYXplLXJlYWN0LWNvbXBvbmVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEJsYXplIH0gZnJvbSAnbWV0ZW9yL2JsYXplJztcbmltcG9ydCB7IFJlYWN0aXZlVmFyIH0gZnJvbSAnbWV0ZW9yL3JlYWN0aXZlLXZhcic7XG5cbmNvbnN0IEJsYXplQ29tcG9uZW50ID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IGh0bWwgPSB7XG4gICAgX19odG1sOiBCbGF6ZS50b0hUTUxXaXRoRGF0YShcbiAgICAgIHByb3BzLnRlbXBsYXRlLFxuICAgICAgXy5vbWl0KHByb3BzLCAndGVtcGxhdGUnKVxuICAgKVxuICB9O1xuXG4gIHJldHVybiAoIDxzcGFuIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXtodG1sfSAvPiApO1xufVxuXG5ibGF6ZVRvUmVhY3QgPSBmdW5jdGlvbih0ZW1wbGF0ZSkge1xuICByZXR1cm4gKHByb3BzKSA9PiA8QmxhemVDb21wb25lbnQgey4uLnByb3BzfSB0ZW1wbGF0ZT17dGVtcGxhdGV9IC8+O1xufVxuXG5leHBvcnQgeyBibGF6ZVRvUmVhY3QgfTtcbmV4cG9ydCBkZWZhdWx0IEJsYXplQ29tcG9uZW50O1xuIl19
