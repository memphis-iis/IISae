(function () {



/* Exports */
Package._define("react-template-helper");

})();
