var require = meteorInstall({"common":{"collections.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// common/collections.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
//Define Collections
Orgs = new Mongo.Collection('organizations');
Assessments = new Mongo.Collection('assessments');
Trials = new Mongo.Collection('trials');
Modules = new Mongo.Collection('modules');
ModuleResults = new Mongo.Collection('modresults');
Events = new Mongo.Collection('events');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"subscaleCalculations.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/subscaleCalculations.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  calculateScores: () => calculateScores
});
let subscaleScores = {
  "con": {
    "min": 7.5,
    "male": [43, 45, 48, 51, 54, 57, 59, 62, 65, 68, 70, 73, 76, 79, 81, 84, 87, 90, 92, 95, 98, 101, 103, 106, 109],
    "female": [39, 41, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89]
  },
  "def": {
    "min": 7.5,
    "male": [19, 22, 24, 26, 29, 31, 33, 36, 38, 40, 43, 45, 48, 50, 52, 54, 57, 59, 61, 64, 66, 68, 71, 73, 76],
    "female": [29, 32, 34, 36, 38, 40, 42, 45, 47, 49, 51, 53, 55, 58, 60, 62, 64, 66, 68, 70, 73, 75, 77, 79, 81]
  },
  "moll": {
    "min": 7.5,
    "male": [38, 40, 43, 45, 48, 50, 53, 55, 58, 60, 63, 65, 68, 70, 73, 75, 78, 80, 83, 85, 88, 90, 93, 95, 98],
    "female": [37, 39, 42, 44, 46, 48, 50, 53, 55, 57, 60, 62, 64, 66, 68, 71, 73, 75, 77, 80, 82, 84, 86, 89, 91]
  },
  "cut": {
    "min": 7.5,
    "male": [40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88],
    "female": [33, 34, 36, 38, 40, 42, 44, 46, 47, 49, 51, 53, 55, 56, 58, 60, 62, 64, 66, 68, 69, 71, 73, 75, 77]
  },
  "ent": {
    "min": 7.5,
    "male": [38, 41, 43, 46, 48, 51, 54, 56, 59, 61, 64, 66, 69, 72, 74, 77, 79, 82, 84, 87, 90, 92, 95, 97, 100],
    "female": [34, 37, 39, 42, 44, 47, 49, 52, 54, 57, 59, 62, 64, 67, 69, 72, 74, 77, 79, 82, 84, 87, 89, 92, 94]
  },
  "po": {
    "min": 7.5,
    "male": [39, 42, 44, 47, 50, 52, 55, 57, 60, 62, 65, 67, 70, 72, 75, 77, 80, 82, 85, 87, 90, 92, 95, 97, 100],
    "female": [37, 39, 41, 43, 45, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 81, 83, 85, 87]
  },
  "sent": {
    "min": 7.5,
    "male": [26, 29, 31, 34, 36, 39, 42, 44, 47, 49, 52, 55, 57, 60, 62, 65, 68, 70, 73, 75, 78, 81, 83, 86, 88],
    "female": [24, 27, 29, 32, 34, 37, 39, 42, 44, 46, 49, 51, 54, 56, 59, 61, 64, 66, 69, 71, 73, 76, 78, 81, 83]
  },
  "so": {
    "min": 7.5,
    "male": [34, 37, 39, 42, 44, 47, 49, 52, 54, 56, 59, 61, 64, 66, 69, 71, 74, 76, 79, 81, 84, 86, 88, 91, 93],
    "female": [31, 34, 36, 38, 40, 42, 44, 46, 48, 51, 53, 55, 57, 59, 61, 63, 65, 68, 70, 72, 74, 76, 78, 80, 82]
  },
  "ci": {
    "min": 7.5,
    "male": [36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84],
    "female": [31, 33, 35, 37, 39, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 67, 69, 71, 73, 75, 77]
  },
  "disc": {
    "min": 7.5,
    "male": [38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86],
    "female": [32, 34, 36, 38, 39, 41, 43, 45, 46, 48, 50, 52, 54, 55, 57, 59, 61, 62, 64, 66, 68, 70, 71, 73, 75]
  },
  "foc": {
    "min": 7.5,
    "male": [36, 38, 41, 43, 45, 47, 49, 51, 54, 56, 58, 60, 62, 64, 67, 69, 71, 73, 75, 78, 80, 82, 84, 86, 88],
    "female": [36, 37, 39, 41, 43, 45, 47, 49, 50, 52, 54, 56, 58, 60, 61, 63, 65, 67, 69, 71, 73, 74, 76, 78, 80]
  },
  "cur": {
    "min": 12.5,
    "male": [39, 40, 42, 43, 44, 45, 46, 48, 49, 50, 51, 52, 54, 55, 56, 57, 59, 60, 61, 62, 63, 65, 66, 67, 68, 70, 71, 72, 73, 74, 76, 77, 78, 79, 80, 82, 83, 84, 85, 87],
    "female": [33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 72, 73, 74, 75, 76]
  },
  "hist": {
    "min": 11.5,
    "male": [39, 40, 41, 43, 44, 46, 47, 48, 50, 51, 53, 54, 55, 57, 58, 60, 61, 62, 64, 65, 67, 68, 70, 71, 72, 74, 75, 76, 78, 79, 81, 82, 83, 85, 86, 88, 89],
    "female": [33, 34, 36, 37, 38, 39, 41, 42, 43, 45, 46, 47, 48, 50, 51, 52, 54, 55, 56, 57, 59, 60, 61, 62, 64, 65, 66, 68, 69, 70, 72, 73, 74, 75, 77, 78, 79]
  },
  "prob": {
    "min": 9.5,
    "male": [40, 41, 43, 44, 46, 47, 49, 50, 52, 53, 55, 56, 58, 59, 61, 62, 64, 65, 67, 68, 70, 71, 73, 74, 75, 77, 79, 80, 82, 84, 85],
    "female": [34, 35, 36, 38, 39, 40, 42, 43, 44, 46, 47, 48, 50, 51, 52, 54, 55, 56, 58, 59, 61, 62, 63, 65, 66, 67, 69, 70, 71, 73, 74]
  },
  "inthost": {
    "min": 9.5,
    "male": [42, 45, 48, 51, 54, 57, 60, 64, 67, 70, 73, 76, 79, 82, 85, 88, 92, 95, 98, 101, 104, 107, 110, 114, 117, 120, 123, 126, 129, 132, 135],
    "female": [42, 44, 46, 49, 51, 53, 55, 57, 60, 62, 64, 66, 69, 71, 73, 75, 78, 80, 82, 84, 86, 89, 91, 93, 96, 98, 100, 102, 104, 107, 109]
  },
  "assert": {
    "min": 9.5,
    "male": [40, 42, 44, 45, 47, 49, 50, 52, 54, 55, 57, 58, 60, 62, 63, 65, 67, 68, 70, 72, 73, 75, 77, 78, 80, 82, 83, 85, 87, 88, 90],
    "female": [35, 37, 38, 40, 41, 43, 44, 46, 48, 49, 51, 52, 54, 55, 57, 59, 60, 62, 63, 65, 66, 68, 70, 71, 73, 74, 76, 77, 79, 81, 82]
  },
  "dnt": {
    "min": 9.5,
    "male": [25, 27, 29, 30, 32, 34, 36, 38, 40, 42, 44, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 64, 66, 68, 70, 72, 74, 76, 78, 80, 81],
    "female": [22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79, 81]
  },
  "pct": {
    "min": 31.5,
    "male": [35, 36, 36, 37, 38, 39, 39, 40, 41, 42, 42, 43, 44, 45, 45, 46, 47, 48, 48, 49, 50, 51, 51, 52, 53, 54, 54, 55, 56, 57, 57, 58, 59, 60, 60, 61, 62, 63, 63, 64, 65, 66, 66, 67, 68, 69, 69, 70, 71, 72, 72, 73, 74, 75, 76, 76, 77, 78, 78, 79, 80, 81, 82, 82, 83, 84, 84, 85, 86, 87, 88, 88, 89, 90, 91, 91, 92, 93, 94, 94, 95, 96, 97, 97, 98, 98, 100, 100, 101, 102, 103, 103, 104, 105, 106, 106, 107],
    "female": [36, 36, 37, 38, 38, 39, 40, 40, 41, 42, 42, 43, 44, 44, 45, 46, 46, 47, 48, 48, 49, 49, 50, 51, 52, 52, 53, 54, 54, 55, 56, 56, 57, 58, 58, 59, 60, 60, 61, 62, 63, 63, 64, 65, 65, 66, 67, 67, 68, 69, 69, 70, 71, 71, 72, 72, 73, 74, 75, 76, 76, 77, 78, 78, 79, 80, 80, 81, 82, 82, 83, 84, 84, 85, 86, 86, 87, 88, 88, 89, 90, 90, 91, 92, 92, 93, 94, 94, 95, 96, 96, 97, 98, 99, 99, 100, 101]
  },
  "rct": {
    "min": 23.5,
    "male": [37, 37, 38, 39, 40, 40, 41, 42, 43, 43, 44, 45, 46, 46, 47, 48, 48, 49, 50, 51, 51, 52, 53, 54, 54, 55, 56, 57, 57, 58, 59, 60, 60, 61, 62, 63, 63, 64, 65, 66, 66, 67, 68, 68, 69, 70, 71, 72, 72, 73, 74, 74, 75, 76, 77, 78, 78, 79, 80, 80, 81, 82, 83, 83, 84, 85, 86, 86, 87, 88, 89, 89, 90],
    "female": [27, 27, 28, 29, 29, 30, 31, 31, 32, 33, 33, 34, 35, 35, 36, 37, 37, 38, 39, 39, 40, 41, 41, 42, 43, 43, 44, 45, 45, 46, 47, 47, 48, 49, 49, 50, 51, 51, 52, 53, 53, 54, 55, 55, 56, 57, 57, 58, 59, 59, 60, 61, 61, 62, 63, 63, 64, 65, 65, 66, 67, 67, 68, 69, 69, 70, 71, 71, 72, 73, 73, 74, 75]
  },
  "gct": {
    "min": 55.5,
    "male": [34, 35, 35, 36, 36, 36, 37, 37, 38, 38, 38, 39, 39, 40, 40, 40, 41, 41, 42, 42, 43, 43, 43, 44, 44, 45, 45, 46, 46, 46, 47, 47, 48, 48, 48, 49, 49, 50, 50, 50, 51, 51, 52, 52, 52, 53, 53, 54, 54, 54, 55, 55, 56, 56, 56, 57, 57, 58, 58, 58, 59, 59, 60, 60, 60, 61, 61, 62, 62, 63, 63, 63, 64, 64, 65, 65, 66, 66, 66, 67, 67, 68, 68, 68, 69, 69, 70, 70, 70, 71, 71, 72, 72, 72, 73, 73, 74, 74, 74, 75, 75, 76, 76, 76, 77, 77, 78, 78, 79, 79, 79, 80, 80, 81, 81, 81, 82, 82, 83, 83, 84, 84, 84, 85, 85, 86, 86, 86, 87, 87, 88, 88, 88, 89, 89, 90, 90, 90, 91, 91, 92, 92, 92, 93, 93, 94, 94, 95, 95, 95, 96, 96, 97, 97, 97, 98, 98, 99, 99, 100, 100, 100, 101, 101, 102, 102, 102, 103, 103],
    "female": [29, 30, 30, 30, 31, 31, 31, 32, 32, 32, 33, 33, 34, 34, 34, 35, 35, 35, 36, 36, 36, 37, 37, 38, 38, 38, 39, 39, 40, 40, 40, 41, 41, 41, 42, 42, 42, 43, 43, 44, 44, 44, 45, 45, 45, 46, 46, 47, 47, 47, 48, 48, 48, 49, 49, 50, 50, 50, 51, 51, 51, 52, 52, 52, 53, 53, 54, 54, 54, 55, 55, 55, 56, 56, 56, 57, 57, 58, 58, 58, 59, 59, 60, 60, 60, 61, 61, 61, 62, 62, 62, 63, 63, 64, 64, 64, 65, 65, 65, 66, 66, 66, 67, 67, 68, 68, 68, 69, 69, 70, 70, 70, 71, 71, 71, 72, 72, 72, 73, 73, 74, 74, 74, 75, 75, 75, 76, 76, 76, 77, 77, 78, 78, 78, 79, 79, 80, 80, 80, 81, 81, 81, 82, 82, 82, 83, 83, 84, 84, 84, 85, 85, 85, 86, 86, 87, 87, 87, 88, 88, 88, 89, 89, 90, 90, 90, 91, 91, 91]
  }
};

function getScoreForPICTSSubscale(scores, sex) {
  let calculatedScores = {
    "GCT": 0,
    "PCT": scores["MOLL"] + scores['ENT'] + scores["PO"] + scores["SO"],
    "RCT": scores["CUT"] + scores['CI'] + scores["DISC"]
  };
  calculatedScores['GCT'] = calculatedScores["RCT"] + calculatedScores["PCT"];

  for (let subscale of Object.keys(calculatedScores)) {
    const scale = subscaleScores[subscale.toLowerCase()];
    calculatedScores[subscale] = scale[sex][Math.floor(calculatedScores[subscale] - scale.min)];
  }

  const subscales = Object.keys(scores);

  for (let subscale of subscales) {
    const scale = subscaleScores[subscale.toLowerCase()];
    calculatedScores[subscale] = scale[sex][Math.floor(scores[subscale] - scale.min)];
  }

  return calculatedScores;
}

function getScoreForDHSSubscale(scores) {
  let calculatedScores = {};

  for (let subscale of Object.keys(scores)) {
    let score = scores[subscale];

    if (subscale == 'DEPRESSION') {
      calculatedScores[subscale] = score / 17;
    } else if (subscale == 'HOPELESSNESS') {
      calculatedScores[subscale] = score / 10;
    } else if (subscale == 'CSI') {
      calculatedScores[subscale] = score / 2;
    } else if (subscale == 'HIST') {
      calculatedScores[subscale] = score / 5;
    } else if (subscale == 'CUR') {
      calculatedScores[subscale] = score / 3;
    }
  }

  return calculatedScores;
}

function calculateScores(subscale, scores, sex) {
  switch (subscale.toUpperCase()) {
    case 'PICTS':
      return getScoreForPICTSSubscale(scores, sex);
    // case 'DHS':
    //     return getScoreForDHSSubscale(scores, sex);

    default:
      // no extra calculation needed. return
      return false;
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
!function (module1) {
  let Meteor;
  module1.link("meteor/meteor", {
    Meteor(v) {
      Meteor = v;
    }

  }, 0);
  let Accounts;
  module1.link("meteor/accounts-base", {
    Accounts(v) {
      Accounts = v;
    }

  }, 1);
  let Roles;
  module1.link("meteor/alanning:roles", {
    Roles(v) {
      Roles = v;
    }

  }, 2);
  let calculateScores;
  module1.link("./subscaleCalculations.js", {
    calculateScores(v) {
      calculateScores = v;
    }

  }, 3);
  let Push;
  module1.link("meteor/activitree:push", {
    Push(v) {
      Push = v;
    }

  }, 4);
  const SEED_ADMIN = {
    username: 'testAdmin',
    password: 'password',
    email: 'testAdmin@memphis.edu',
    firstName: 'Johnny',
    lastName: 'Test',
    org: "",
    supervisorID: "0",
    role: 'admin',
    supervisorInviteCode: "12345",
    sex: 'female',
    assigned: [],
    nextModule: -1
  };
  const SEED_SUPERVISOR = {
    username: 'testSupervisor',
    password: 'password',
    email: 'testSupervisor@memphis.edu',
    firstName: 'Supervisor',
    lastName: 'Test',
    org: "",
    supervisorID: "0",
    role: 'supervisor',
    supervisorInviteCode: "12345",
    sex: 'male',
    assigned: [],
    nextModule: -1
  };
  const SEED_USER = {
    username: 'testUser',
    password: 'password',
    email: 'testUser@memphis.edu',
    firstName: 'User',
    lastName: 'Test',
    org: "",
    supervisorID: "0",
    role: 'user',
    supervisorInviteCode: null,
    sex: 'female',
    assigned: [],
    hasCompletedFirstAssessment: false,
    nextModule: 0
  };
  const SEED_USER2 = {
    username: 'testUserNotInIIS',
    password: 'password',
    email: 'testUserNotInIIS@memphis.edu',
    firstName: 'User',
    lastName: 'Test',
    org: "alksdjhfaslkd",
    supervisorID: "0",
    role: 'user',
    supervisorInviteCode: null,
    sex: 'male',
    assigned: [],
    hasCompletedFirstAssessment: false,
    nextModule: 0
  };
  const SEED_USERS = [SEED_ADMIN, SEED_SUPERVISOR, SEED_USER, SEED_USER2];
  const SEED_ROLES = ['user', 'supervisor', 'admin']; //Configure Push Notifications

  serviceAccountData = null;
  Push.Configure({
    appName: 'Oji',
    firebaseAdmin: {
      serviceAccountData,
      databaseURL: '____firebase_database_url____'
    },
    defaults: {
      // ******** Meteor Push Messaging Processor *******
      sendBatchSize: 5,
      // Configurable number of notifications to send per batch
      sendInterval: 3000,
      keepNotifications: false,
      // the following keeps the notifications in the DB
      delayUntil: null,
      // Date
      sendTimeout: 60000,
      // miliseconds 60 x 1000 = 1 min
      // ******** Global Message *******
      appName: 'Oji',
      // Serve it as a 'from' default for IOS notifications
      sound: 'note',
      // String (file has to exist in app/src/res/... or default on the mobile will be used). For Android no extension, for IOS add '.caf'
      data: null,
      // Global Data object - applies to all vendors if specific vendor data object does not exist.
      imageUrl: 'https://a_default_image_url.jpg',
      badge: 1,
      // Integer
      vibrate: 1,
      // Boolean // TODO see if I really use this.
      requireInteraction: false,
      // TODO Implement this and move it to where it belongs
      analyticsLabel: 'activitreeOji',
      // Android, IOS: Label associated with the message's analytics data.
      // ******* IOS Specifics ******
      apnsPriority: '10',
      topic: 'com.activitree',
      // String = the IOS App id
      launchImage: '',
      // IOS: String
      iosData: null,
      // Data object targeted to the IOS notification
      // ******* Android Specificas *******
      icon: 'statusbaricon',
      // String (name of icon for Android has to exist in app/src/res/....)
      color: '#337FAE',
      // String e.g 3 rrggbb
      ttl: '86400s',
      // if not set, use default max of 4 weeks
      priority: 'HIGH',
      // Android: one of NORMAL or HIGH
      notificationPriority: 'PRIORITY_DEFAULT',
      // Android: one of none, or PRIORITY_MIN, PRIORITY_LOW, PRIORITY_DEFAULT, PRIORITY_HIGH, PRIORITY_MAX
      collapseKey: 1,
      // String/ Integer??, Android:  A maximum of 4 different collapse keys is allowed at any given time.
      androidData: null,
      // Data object targeted to the Android notiffication
      visibility: 'PRIVATE',
      // Android: One of 'PRIVATE', 'PUBLIC', 'SECRET'. Default is 'PRIVATE',
      // ******* Web Specifics *******
      webIcon: 'https://link_to_your_logo.jpg',
      webData: null,
      // Data object targeted to the Web notification
      webTTL: "".concat(3600 * 1000) // Number of seconds as a string

    }
  });
  Meteor.startup(() => {
    //Iron Router Api
    Router.route('/api', {
      where: "server",
      action: function () {
        this.response.writeHead(200, {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        });
        console.log(this.request.headers);
        username = this.request.headers['x-user-id'];
        loginToken = this.request.headers['x-auth-token'];
        user = Meteor.users.findOne({
          username: username
        });
        isTokenExpired = true;
        keys = user.api;
        now = new Date();
        expDate = keys.expires;
        expDate.setDate(expDate.getDate());
        console.log('date', now, expDate, keys.expires);

        if (now < expDate) {
          isTokenExpired = false;
        }

        if (!user || user.api.token != loginToken || isTokenExpired == true) {
          this.response.end("{sucess: false, message: 'incorrect username or expired token'}");
        } else {
          organization = Orgs.findOne({
            orgOwnerId: user._id
          });
          userlist = Meteor.users.find({
            organization: organization._id
          }, {
            fields: {
              firstname: 0,
              lastname: 0,
              emails: 0,
              username: 0,
              role: 0,
              supervisorInviteCode: 0,
              services: 0,
              organization: 0,
              api: 0
            }
          }).fetch();
          userListResponse = [];

          for (i = 0; i < userlist.length; i++) {
            userTrials = Trials.find({
              userId: userlist[i]._id
            }).fetch();
            userModules = Modules.find({
              userId: userlist[i]._id
            }).fetch();
            curUser = userlist[i];
            curUser.trials = JSON.parse(JSON.stringify(userTrials));
            curUser.modules = JSON.parse(JSON.stringify(userModules));
            userListResponse.push(curUser);
          }

          organization.users = userListResponse;
          this.response.end(JSON.stringify(organization));
        }
      }
    }); //load default JSON assessment into mongo collection

    if (Assessments.find().count() === 0) {
      console.log('Importing Default Assessments into Mongo.');
      var data = JSON.parse(Assets.getText('defaultAssessments.json'));

      for (var i = 0; i < data['assessments'].length; i++) {
        assessment = data['assessments'][i]['assessment'];
        Assessments.insert(assessment);
      }

      ;
    } //load default JSON modules into mongo collection


    if (Modules.find().count() === 0) {
      console.log('Importing Default Modules into Mongo.');
      var data = JSON.parse(Assets.getText('defaultModules.json'));

      for (var i = 0; i < data['modules'].length; i++) {
        newModule = data['modules'][i]['module'];
        Modules.insert(newModule);
      }

      ;
    } //create seed roles


    for (let role of SEED_ROLES) {
      if (!Meteor.roles.findOne({
        '_id': role
      })) {
        Roles.createRole(role);
      }
    }

    let newOrgId; //create seed user

    for (let user of SEED_USERS) {
      if (!Accounts.findUserByUsername(user.username)) {
        const uid = Accounts.createUser({
          username: user.username,
          password: user.password,
          email: user.email
        });
        addUserToRoles(uid, user.role);

        if (user.role == "admin") {
          Orgs.insert({
            orgName: "IIS",
            orgOwnerId: uid,
            orgDesc: "Testing",
            newUserAssignments: []
          });
          newOrgId = Orgs.findOne({
            orgOwnerId: uid
          })._id;
          const d = new Date();
          let month = d.getMonth();
          let day = d.getDate();
          let year = d.getFullYear();
          let title = "test event";
          Events.insert({
            type: "org",
            org: newOrgId,
            month: month,
            day: day,
            year: year,
            title: title,
            createdBy: uid
          });
          Meteor.call('generateInvite', uid);
        }

        let supervisorID = '';

        if (user.username == 'testUser') {
          supervisorID = Accounts.findUserByUsername(SEED_SUPERVISOR.username)._id;
        }

        Meteor.users.update({
          _id: uid
        }, {
          $set: {
            sex: user.sex,
            firstname: user.firstName,
            lastname: user.lastName,
            supervisor: supervisorID,
            organization: user.org ? user.org : newOrgId,
            sex: user.sex,
            assigned: user.assigned,
            hasCompletedFirstAssessment: user.hasCompletedFirstAssessment,
            nextModule: 0
          }
        });
      }
    }
  }); //Global Methods

  Meteor.methods({
    getInviteInfo,
    createNewUser: function (user, pass, emailAddr, firstName, lastName, sex, gender) {
      let linkId = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : "";

      if (linkId) {
        var {
          targetOrgId,
          targetOrgName,
          targetSupervisorId,
          targetSupervisorName
        } = getInviteInfo(linkId);
        var organization = Orgs.findOne({
          _id: targetOrgId
        });
      } else {
        var targetOrgId = null;
        var targetSupervisorId = null;
        var organization = {
          newUserAssignments: []
        };
      }

      if (!Accounts.findUserByUsername(user)) {
        if (!Accounts.findUserByEmail(emailAddr)) {
          const uid = Accounts.createUser({
            username: user,
            password: pass,
            email: emailAddr
          });
          Meteor.users.update({
            _id: uid
          }, {
            $set: {
              sex: sex,
              firstname: firstName,
              lastname: lastName,
              organization: targetOrgId,
              supervisor: targetSupervisorId,
              supervisorInviteCode: null,
              hasCompletedFirstAssessment: false,
              gender: gender,
              assigned: organization.newUserAssignments || [],
              nextModule: 0
            }
          });

          if (linkId != "") {
            addUserToRoles(uid, 'user');
          } else {
            addUserToRoles(uid, 'admin');
          }
        } else {
          throw new Meteor.Error('user-already-exists', "Email ".concat(emailAddr, " already in use"));
        }
      } else {
        throw new Meteor.Error('user-already-exists', "User ".concat(user, " already exists"));
      }
    },
    createOrganization: function (newOrgName, newOrgOwner, newOrgDesc) {
      allAssessments = Assessments.find().fetch();
      newUserAssignments = [];

      for (i = 0; i < allAssessments.length; i++) {
        newUserAssignments.push(allAssessments[i]._id);
      }

      Orgs.insert({
        orgName: newOrgName,
        orgOwnerId: newOrgOwner,
        orgDesc: newOrgDesc,
        newUserAssignments: newUserAssignments
      });
      newOrgId = Orgs.findOne({
        orgOwnerId: newOrgOwner
      })._id;
      Meteor.users.update({
        _id: newOrgOwner
      }, {
        $set: {
          organization: newOrgId
        }
      });
      return true;
    },
    generateInvite: function (supervisorId) {
      var link = '';
      var length = 16;
      var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;
      var unique = false;

      while (unique == false) {
        ;

        for (var i = 0; i < length; i++) {
          link += characters.charAt(Math.floor(Math.random() * charactersLength));
        }

        linkFound = Meteor.users.find({
          supervisorInviteCode: link
        }).fetch().length;

        if (linkFound == 0) {
          unique = true;
        } else {
          link = "";
        }
      }

      Meteor.users.update({
        _id: supervisorId
      }, {
        $set: {
          supervisorInviteCode: link
        }
      });
      return link;
    },
    destroyUser: function (userID) {
      if (Roles.userIsInRole(this.userId, ['admin'])) {
        Meteor.users.remove(userID);
      }
    },
    removeSupervisor: function (userId) {
      //removes a user from supervisors list if added by mistake. 
      if (Roles.userIsInRole(this.userId, 'admin')) {
        addUserToRoles(userId, 'user');
        removeUserFromRoles(userId, 'supervisor');
      }
    },
    editSupervisor: function (supervisorID) {
      if (Roles.userIsInRole(this.userId, ['admin'])) {}
    },
    addSupervisor: function (userId) {
      //elevate user with user role to supervisor
      if (Roles.userIsInRole(this.userId, 'admin')) {
        addUserToRoles(userId, 'supervisor');
        removeUserFromRoles(userId, 'user');
      }
    },
    changeAssignmentToNewUsers: function (assignment) {
      Orgs.upsert({
        _id: Meteor.user().organization
      }, {
        $set: {
          newUserAssignments: assignment
        }
      });
    },
    assignToAllUsers: function (assignment) {
      org = Meteor.user().organization;
      allUsers = Meteor.users.find({
        organization: org,
        role: 'user'
      }).fetch();

      for (i = 0; i < allUsers.length; i++) {
        curAssignments = allUsers[i].assigned;

        if (!curAssignments.includes(assignment)) {
          curAssignments.push(assignment);
        }

        Meteor.users.upsert({
          _id: allUsers[i]._id
        }, {
          $set: {
            assigned: curAssignments
          }
        });
      }
    },
    changeAssignmentOneUser: function (input) {
      userId = input[0];
      assignment = input[1];
      Meteor.users.upsert({
        _id: userId
      }, {
        $set: {
          assigned: assignment
        }
      });
    },
    //assessment data collection
    saveAssessmentData: function (newData) {
      trialId = newData.trialId;
      assessmentId = newData.assessmentId;
      assessmentName = newData.assessmentName;
      userId = Meteor.userId();
      questionId = newData.questionId;
      oldResults = Trials.findOne({
        _id: trialId
      });
      let identifier;

      if (typeof oldResults === "undefined") {
        data = [];
        subscaleTotals = {};
        identifier = newData.identifier;
      } else {
        data = oldResults.data;
        subscaleTotals = oldResults.subscaleTotals;
        identifier = oldResults.identifier;
      }

      data[newData.questionId] = {
        response: newData.response,
        responseValue: newData.responseValue,
        subscales: newData.subscales
      }; //sum the response values by subscale for data reporting

      if (!newData.subscales) {
        //current assessment doesnt use subscales, just tally the totalls
        if (subscaleTotals['default']) {
          subscaleTotals['default'] += newData.responseValue;
        } else {
          subscaleTotals['default'] = newData.responseValue;
        }
      }

      for (let subscale of newData.subscales) {
        if (subscaleTotals[subscale]) {
          subscaleTotals[subscale] += newData.responseValue;
        } else {
          subscaleTotals[subscale] = newData.responseValue;
        }
      }

      var output = Trials.upsert({
        _id: trialId
      }, {
        $set: {
          userId: userId,
          assessmentId: assessmentId,
          assessmentName: assessmentName,
          lastAccessed: new Date(),
          identifier: identifier,
          data: data,
          subscaleTotals: subscaleTotals
        }
      });

      if (typeof output.insertedId === "undefined") {
        Meteor.users.update(userId, {
          $set: {
            curTrial: {
              trialId: trialId,
              questionId: questionId + 1
            }
          }
        });
        return trialId;
      } else {
        Meteor.users.update(userId, {
          $set: {
            curTrial: {
              trialId: output.insertedId,
              questionId: 1
            }
          }
        });
        return output.insertedId;
      }
    },
    endAssessment: function (trialId) {
      let trial = Trials.findOne({
        '_id': trialId
      });
      const adjustedScores = calculateScores(trial.identifier, trial.subscaleTotals, Meteor.user().sex);
      if (adjustedScores) Trials.upsert({
        _id: trialId
      }, {
        $set: {
          subscaleTotals: adjustedScores
        }
      });
    },
    clearAssessmentProgress: function () {
      userId = Meteor.userId();
      Meteor.users.update(userId, {
        $set: {
          curTrial: {
            trialId: 0,
            questionId: 0
          }
        }
      });
    },
    createNewModuleTrial: function (data) {
      const results = ModuleResults.insert(data);
      Meteor.users.update(Meteor.userId(), {
        $set: {
          curModule: {
            moduleId: results,
            pageId: 0,
            questionId: 0
          }
        }
      });
      return results;
    },
    saveModuleData: function (moduleData) {
      ModuleResults.upsert({
        _id: moduleData._id
      }, {
        $set: moduleData
      });
      nextModule = Meteor.users.findOne({
        _id: Meteor.userId()
      }).nextModule;

      if (moduleData.pageId == 'completed') {
        nextModule++;
      }

      Meteor.users.upsert(Meteor.userId(), {
        $set: {
          curModule: {
            moduleId: Meteor.user().curModule.moduleId,
            pageId: moduleData.nextPage,
            questionId: moduleData.nextQuestion
          },
          nextModule: nextModule
        }
      });
    },
    getPrivateImage: function (fileName) {
      result = Assets.absoluteFilePath(fileName);
      return result;
    },
    generateApiToken: function (userId) {
      var newToken = "";
      var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;

      for (var i = 0; i < 16; i++) {
        newToken += characters.charAt(Math.floor(Math.random() * charactersLength));
      }

      var future = new Date();
      future.setDate(future.getDate() + 30);
      Meteor.users.update(userId, {
        $set: {
          api: {
            token: newToken,
            expires: future
          }
        }
      });
    },
    calcOrgStats: function () {
      users = Meteor.users.find({
        organization: Meteor.user().organization
      }).fetch();
      subscales = [];
      subscaleList = [];
      data = {};
      data.userCount = users.length;
      data.assessmentCount = 0;
      data.moduleCount = 0;
      subscaleData = [];

      for (i = 0; i < users.length; i++) {
        trials = Trials.find({
          "userId": users[i]._id
        }).fetch();

        for (j = 0; j < trials.length; j++) {
          data.assessmentCount++;

          for (k = 0; k < Object.getOwnPropertyNames(trials[j].subscaleTotals).length; k++) {
            subscale = Object.getOwnPropertyNames(trials[j].subscaleTotals)[k];
            subscaleIndex = subscaleList.indexOf(subscale);

            if (subscaleIndex === -1) {
              subscaleList.push(subscale);
              subscaleIndex = subscaleList.indexOf(subscale);
              subscaleData[subscaleIndex] = {
                name: subscale,
                all: [trials[j].subscaleTotals[subscale]],
                count: 1,
                sum: trials[j].subscaleTotals[subscale],
                avg: trials[j].subscaleTotals[subscale],
                median: trials[j].subscaleTotals[subscale]
              };
            } else {
              subscaleData[subscaleIndex].all.push(trials[j].subscaleTotals[subscale]);
              subscaleData[subscaleIndex].count++;
              subscaleData[subscaleIndex].sum += trials[j].subscaleTotals[subscale];
              subscaleData[subscaleIndex].avg = subscaleData[subscaleIndex].sum / subscaleData[subscaleIndex].count;
              const sorted = subscaleData[subscaleIndex].all.slice().sort((a, b) => a - b);
              const middle = Math.floor(sorted.length / 2);

              if (sorted.length % 2 === 0) {
                median = (sorted[middle - 1] + sorted[middle]) / 2;
              } else {
                median = sorted[middle];
              }

              subscaleData[subscaleIndex].median = median;
            }
          }
        }
      }

      data.subscaleData = subscaleData;
      Orgs.upsert({
        _id: Meteor.user().organization
      }, {
        $set: {
          orgStats: data
        }
      });
    },
    createEvent: function (type, month, day, year, time, title, importance) {
      Events.insert({
        type: type,
        org: Meteor.user().organization,
        month: month,
        day: day,
        year: year,
        title: title,
        time: time,
        importance: importance,
        createdBy: this.userId
      });
    },
    deleteEvent: function (eventId) {
      Events.remove({
        _id: eventId
      });
    }
  }); //Server Methods

  function addUserToRoles(uid, roles) {
    Roles.addUsersToRoles(uid, roles);
    Meteor.users.update({
      _id: uid
    }, {
      $set: {
        role: Roles.getRolesForUser(uid)[0]
      }
    });
  }

  function removeUserFromRoles(uid, roles) {
    Roles.removeUsersFromRoles(uid, roles);
    Meteor.users.update({
      _id: uid
    }, {
      $set: {
        role: Roles.getRolesForUser(uid)[0]
      }
    });
  }

  function serverConsole() {
    const disp = [new Date().toString()];

    for (let i = 0; i < arguments.length; ++i) {
      disp.push(i < 0 || arguments.length <= i ? undefined : arguments[i]);
    } // eslint-disable-next-line no-invalid-this


    console.log.apply(this, disp);
  }

  function getInviteInfo(inviteCode) {
    supervisor = Meteor.users.findOne({
      supervisorInviteCode: inviteCode
    });
    targetSupervisorId = supervisor._id;
    organization = Orgs.findOne({
      _id: supervisor.organization
    });
    targetSupervisorName = supervisor.firstname + " " + supervisor.lastname;
    targetOrgId = supervisor.organization;
    targetOrgName = organization.orgName;
    console.log(targetOrgId, targetOrgName, targetSupervisorId, targetSupervisorName);
    return {
      targetOrgId,
      targetOrgName,
      targetSupervisorId,
      targetSupervisorName
    };
  } //Publications and Mongo Access Control


  Meteor.users.deny({
    update() {
      return true;
    }

  });
  Meteor.users.allow({}); //Show current user data for current user

  Meteor.publish(null, function () {
    return Meteor.users.find({
      _id: this.userId
    });
  }); //Publish current assessment information

  Meteor.publish('curAssessment', function (id) {
    return Assessments.find({
      _id: id
    });
  }); //allow admins to see all users of org, Can only see emails of users. Can See full data of supervisors

  Meteor.publish('getUsersInOrg', function () {
    if (Roles.userIsInRole(this.userId, 'admin')) {
      return Meteor.users.find({
        organization: Meteor.user().organization,
        role: 'user'
      });
    } else if (Roles.userIsInRole(this.userId, 'supervisor')) {
      return Meteor.users.find({
        organization: Meteor.user().organization,
        role: 'user',
        supervisor: this.userId
      });
    }
  });
  Meteor.publish('getSupervisorsInOrg', function () {
    if (Roles.userIsInRole(this.userId, 'admin')) {
      return Meteor.users.find({
        organization: Meteor.user().organization,
        role: 'supervisor'
      });
    }
  }); //Allow users access to Org information

  Meteor.publish(null, function () {
    if (Meteor.user()) {
      return Orgs.find({
        _id: Meteor.user().organization
      });
    }
  }); //allow the use of Roles.userIsInRole() accorss client

  Meteor.publish(null, function () {
    if (this.userId) {
      return Meteor.roleAssignment.find({
        'user._id': this.userId
      });
    } else {
      this.ready();
    }
  }); //allow assessments to be published

  Meteor.publish('assessments', function () {
    return Assessments.find({});
  }); //allow current users trial data to be published

  Meteor.publish('usertrials', function () {
    if (Roles.userIsInRole(this.userId, ['admin', 'supervisor'])) return Trials.find();
    return Trials.find({
      'userId': this.userId
    });
  }); //allow cur
  //allow current module pages to be published

  Meteor.publish('curModule', function (id) {
    return Modules.find({
      _id: id
    });
  }); //allow all modules to be seen

  Meteor.publish('modules', function () {
    return Modules.find({});
  }); //get module results

  Meteor.publish('getUserModuleResults', function (id) {
    return ModuleResults.find({});
  });
  Meteor.publish('getModuleResultsByTrialId', function (id) {
    return ModuleResults.find({
      _id: id
    });
  }); //get my events

  Meteor.publish(null, function () {
    return Events.find({
      createdBy: this.userId
    });
  }); //get all organization events

  Meteor.publish('events', function () {
    console.log(Meteor.user().organization, this.userId);

    if (Meteor.user()) {
      return Events.find({
        $or: [{
          $and: [{
            org: Meteor.user().organization
          }, {
            createdBy: this.userId
          }]
        }, {
          $and: [{
            createdBy: Meteor.user().supervisor
          }, {
            type: "Supervisor Group"
          }]
        }, {
          $and: [{
            org: Meteor.user().organization
          }, {
            type: "All Organization"
          }]
        }, {
          type: this.userId
        }]
      }, {
        sort: {
          year: 1,
          month: 1,
          day: 1,
          time: 1
        }
      });
    }
  });
}.call(this, module);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts"
  ]
});

require("/common/collections.js");
require("/server/subscaleCalculations.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvY29tbW9uL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvc3Vic2NhbGVDYWxjdWxhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1vbmdvIiwibW9kdWxlIiwibGluayIsInYiLCJNZXRlb3IiLCJPcmdzIiwiQ29sbGVjdGlvbiIsIkFzc2Vzc21lbnRzIiwiVHJpYWxzIiwiTW9kdWxlcyIsIk1vZHVsZVJlc3VsdHMiLCJFdmVudHMiLCJleHBvcnQiLCJjYWxjdWxhdGVTY29yZXMiLCJzdWJzY2FsZVNjb3JlcyIsImdldFNjb3JlRm9yUElDVFNTdWJzY2FsZSIsInNjb3JlcyIsInNleCIsImNhbGN1bGF0ZWRTY29yZXMiLCJzdWJzY2FsZSIsIk9iamVjdCIsImtleXMiLCJzY2FsZSIsInRvTG93ZXJDYXNlIiwiTWF0aCIsImZsb29yIiwibWluIiwic3Vic2NhbGVzIiwiZ2V0U2NvcmVGb3JESFNTdWJzY2FsZSIsInNjb3JlIiwidG9VcHBlckNhc2UiLCJtb2R1bGUxIiwiQWNjb3VudHMiLCJSb2xlcyIsIlB1c2giLCJTRUVEX0FETUlOIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsImVtYWlsIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJvcmciLCJzdXBlcnZpc29ySUQiLCJyb2xlIiwic3VwZXJ2aXNvckludml0ZUNvZGUiLCJhc3NpZ25lZCIsIm5leHRNb2R1bGUiLCJTRUVEX1NVUEVSVklTT1IiLCJTRUVEX1VTRVIiLCJoYXNDb21wbGV0ZWRGaXJzdEFzc2Vzc21lbnQiLCJTRUVEX1VTRVIyIiwiU0VFRF9VU0VSUyIsIlNFRURfUk9MRVMiLCJzZXJ2aWNlQWNjb3VudERhdGEiLCJDb25maWd1cmUiLCJhcHBOYW1lIiwiZmlyZWJhc2VBZG1pbiIsImRhdGFiYXNlVVJMIiwiZGVmYXVsdHMiLCJzZW5kQmF0Y2hTaXplIiwic2VuZEludGVydmFsIiwia2VlcE5vdGlmaWNhdGlvbnMiLCJkZWxheVVudGlsIiwic2VuZFRpbWVvdXQiLCJzb3VuZCIsImRhdGEiLCJpbWFnZVVybCIsImJhZGdlIiwidmlicmF0ZSIsInJlcXVpcmVJbnRlcmFjdGlvbiIsImFuYWx5dGljc0xhYmVsIiwiYXBuc1ByaW9yaXR5IiwidG9waWMiLCJsYXVuY2hJbWFnZSIsImlvc0RhdGEiLCJpY29uIiwiY29sb3IiLCJ0dGwiLCJwcmlvcml0eSIsIm5vdGlmaWNhdGlvblByaW9yaXR5IiwiY29sbGFwc2VLZXkiLCJhbmRyb2lkRGF0YSIsInZpc2liaWxpdHkiLCJ3ZWJJY29uIiwid2ViRGF0YSIsIndlYlRUTCIsInN0YXJ0dXAiLCJSb3V0ZXIiLCJyb3V0ZSIsIndoZXJlIiwiYWN0aW9uIiwicmVzcG9uc2UiLCJ3cml0ZUhlYWQiLCJjb25zb2xlIiwibG9nIiwicmVxdWVzdCIsImhlYWRlcnMiLCJsb2dpblRva2VuIiwidXNlciIsInVzZXJzIiwiZmluZE9uZSIsImlzVG9rZW5FeHBpcmVkIiwiYXBpIiwibm93IiwiRGF0ZSIsImV4cERhdGUiLCJleHBpcmVzIiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b2tlbiIsImVuZCIsIm9yZ2FuaXphdGlvbiIsIm9yZ093bmVySWQiLCJfaWQiLCJ1c2VybGlzdCIsImZpbmQiLCJmaWVsZHMiLCJmaXJzdG5hbWUiLCJsYXN0bmFtZSIsImVtYWlscyIsInNlcnZpY2VzIiwiZmV0Y2giLCJ1c2VyTGlzdFJlc3BvbnNlIiwiaSIsImxlbmd0aCIsInVzZXJUcmlhbHMiLCJ1c2VySWQiLCJ1c2VyTW9kdWxlcyIsImN1clVzZXIiLCJ0cmlhbHMiLCJKU09OIiwicGFyc2UiLCJzdHJpbmdpZnkiLCJtb2R1bGVzIiwicHVzaCIsImNvdW50IiwiQXNzZXRzIiwiZ2V0VGV4dCIsImFzc2Vzc21lbnQiLCJpbnNlcnQiLCJuZXdNb2R1bGUiLCJyb2xlcyIsImNyZWF0ZVJvbGUiLCJuZXdPcmdJZCIsImZpbmRVc2VyQnlVc2VybmFtZSIsInVpZCIsImNyZWF0ZVVzZXIiLCJhZGRVc2VyVG9Sb2xlcyIsIm9yZ05hbWUiLCJvcmdEZXNjIiwibmV3VXNlckFzc2lnbm1lbnRzIiwiZCIsIm1vbnRoIiwiZ2V0TW9udGgiLCJkYXkiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJ0aXRsZSIsInR5cGUiLCJjcmVhdGVkQnkiLCJjYWxsIiwidXBkYXRlIiwiJHNldCIsInN1cGVydmlzb3IiLCJtZXRob2RzIiwiZ2V0SW52aXRlSW5mbyIsImNyZWF0ZU5ld1VzZXIiLCJwYXNzIiwiZW1haWxBZGRyIiwiZ2VuZGVyIiwibGlua0lkIiwidGFyZ2V0T3JnSWQiLCJ0YXJnZXRPcmdOYW1lIiwidGFyZ2V0U3VwZXJ2aXNvcklkIiwidGFyZ2V0U3VwZXJ2aXNvck5hbWUiLCJmaW5kVXNlckJ5RW1haWwiLCJFcnJvciIsImNyZWF0ZU9yZ2FuaXphdGlvbiIsIm5ld09yZ05hbWUiLCJuZXdPcmdPd25lciIsIm5ld09yZ0Rlc2MiLCJhbGxBc3Nlc3NtZW50cyIsImdlbmVyYXRlSW52aXRlIiwic3VwZXJ2aXNvcklkIiwiY2hhcmFjdGVycyIsImNoYXJhY3RlcnNMZW5ndGgiLCJ1bmlxdWUiLCJjaGFyQXQiLCJyYW5kb20iLCJsaW5rRm91bmQiLCJkZXN0cm95VXNlciIsInVzZXJJRCIsInVzZXJJc0luUm9sZSIsInJlbW92ZSIsInJlbW92ZVN1cGVydmlzb3IiLCJyZW1vdmVVc2VyRnJvbVJvbGVzIiwiZWRpdFN1cGVydmlzb3IiLCJhZGRTdXBlcnZpc29yIiwiY2hhbmdlQXNzaWdubWVudFRvTmV3VXNlcnMiLCJhc3NpZ25tZW50IiwidXBzZXJ0IiwiYXNzaWduVG9BbGxVc2VycyIsImFsbFVzZXJzIiwiY3VyQXNzaWdubWVudHMiLCJpbmNsdWRlcyIsImNoYW5nZUFzc2lnbm1lbnRPbmVVc2VyIiwiaW5wdXQiLCJzYXZlQXNzZXNzbWVudERhdGEiLCJuZXdEYXRhIiwidHJpYWxJZCIsImFzc2Vzc21lbnRJZCIsImFzc2Vzc21lbnROYW1lIiwicXVlc3Rpb25JZCIsIm9sZFJlc3VsdHMiLCJpZGVudGlmaWVyIiwic3Vic2NhbGVUb3RhbHMiLCJyZXNwb25zZVZhbHVlIiwib3V0cHV0IiwibGFzdEFjY2Vzc2VkIiwiaW5zZXJ0ZWRJZCIsImN1clRyaWFsIiwiZW5kQXNzZXNzbWVudCIsInRyaWFsIiwiYWRqdXN0ZWRTY29yZXMiLCJjbGVhckFzc2Vzc21lbnRQcm9ncmVzcyIsImNyZWF0ZU5ld01vZHVsZVRyaWFsIiwicmVzdWx0cyIsImN1ck1vZHVsZSIsIm1vZHVsZUlkIiwicGFnZUlkIiwic2F2ZU1vZHVsZURhdGEiLCJtb2R1bGVEYXRhIiwibmV4dFBhZ2UiLCJuZXh0UXVlc3Rpb24iLCJnZXRQcml2YXRlSW1hZ2UiLCJmaWxlTmFtZSIsInJlc3VsdCIsImFic29sdXRlRmlsZVBhdGgiLCJnZW5lcmF0ZUFwaVRva2VuIiwibmV3VG9rZW4iLCJmdXR1cmUiLCJjYWxjT3JnU3RhdHMiLCJzdWJzY2FsZUxpc3QiLCJ1c2VyQ291bnQiLCJhc3Nlc3NtZW50Q291bnQiLCJtb2R1bGVDb3VudCIsInN1YnNjYWxlRGF0YSIsImoiLCJrIiwiZ2V0T3duUHJvcGVydHlOYW1lcyIsInN1YnNjYWxlSW5kZXgiLCJpbmRleE9mIiwibmFtZSIsImFsbCIsInN1bSIsImF2ZyIsIm1lZGlhbiIsInNvcnRlZCIsInNsaWNlIiwic29ydCIsImEiLCJiIiwibWlkZGxlIiwib3JnU3RhdHMiLCJjcmVhdGVFdmVudCIsInRpbWUiLCJpbXBvcnRhbmNlIiwiZGVsZXRlRXZlbnQiLCJldmVudElkIiwiYWRkVXNlcnNUb1JvbGVzIiwiZ2V0Um9sZXNGb3JVc2VyIiwicmVtb3ZlVXNlcnNGcm9tUm9sZXMiLCJzZXJ2ZXJDb25zb2xlIiwiZGlzcCIsInRvU3RyaW5nIiwiYXBwbHkiLCJpbnZpdGVDb2RlIiwiZGVueSIsImFsbG93IiwicHVibGlzaCIsImlkIiwicm9sZUFzc2lnbm1lbnQiLCJyZWFkeSIsIiRvciIsIiRhbmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsS0FBSjtBQUFVQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNGLE9BQUssQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFNBQUssR0FBQ0csQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJQyxNQUFKO0FBQVdILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0UsUUFBTSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsVUFBTSxHQUFDRCxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBR3ZFO0FBQ0FFLElBQUksR0FBRyxJQUFJTCxLQUFLLENBQUNNLFVBQVYsQ0FBcUIsZUFBckIsQ0FBUDtBQUNBQyxXQUFXLEdBQUksSUFBSVAsS0FBSyxDQUFDTSxVQUFWLENBQXFCLGFBQXJCLENBQWY7QUFDQUUsTUFBTSxHQUFHLElBQUlSLEtBQUssQ0FBQ00sVUFBVixDQUFxQixRQUFyQixDQUFUO0FBQ0FHLE9BQU8sR0FBRyxJQUFJVCxLQUFLLENBQUNNLFVBQVYsQ0FBcUIsU0FBckIsQ0FBVjtBQUNBSSxhQUFhLEdBQUcsSUFBSVYsS0FBSyxDQUFDTSxVQUFWLENBQXFCLFlBQXJCLENBQWhCO0FBQ0FLLE1BQU0sR0FBRyxJQUFJWCxLQUFLLENBQUNNLFVBQVYsQ0FBcUIsUUFBckIsQ0FBVCxDOzs7Ozs7Ozs7OztBQ1RBTCxNQUFNLENBQUNXLE1BQVAsQ0FBYztBQUFDQyxpQkFBZSxFQUFDLE1BQUlBO0FBQXJCLENBQWQ7QUFDQSxJQUFJQyxjQUFjLEdBQ2xCO0FBQ0ksU0FBTztBQUNILFdBQU8sR0FESjtBQUVILFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEdBQXRGLEVBQTJGLEdBQTNGLEVBQWdHLEdBQWhHLEVBQXFHLEdBQXJHLENBRkw7QUFHSCxjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRztBQUhQLEdBRFg7QUFNSSxTQUFPO0FBQ0gsV0FBTyxHQURKO0FBRUgsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsQ0FGTDtBQUdILGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHO0FBSFAsR0FOWDtBQVdJLFVBQVE7QUFDSixXQUFPLEdBREg7QUFFSixZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxDQUZKO0FBR0osY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEc7QUFITixHQVhaO0FBZ0JJLFNBQU87QUFDSCxXQUFPLEdBREo7QUFFSCxZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxDQUZMO0FBR0gsY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEc7QUFIUCxHQWhCWDtBQXFCSSxTQUFPO0FBQ0gsV0FBTyxHQURKO0FBRUgsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csR0FBbEcsQ0FGTDtBQUdILGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHO0FBSFAsR0FyQlg7QUEwQkksUUFBTTtBQUNGLFdBQU8sR0FETDtBQUVGLFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEdBQWxHLENBRk47QUFHRixjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRztBQUhSLEdBMUJWO0FBK0JJLFVBQVE7QUFDSixXQUFPLEdBREg7QUFFSixZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxDQUZKO0FBR0osY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEc7QUFITixHQS9CWjtBQW9DSSxRQUFNO0FBQ0YsV0FBTyxHQURMO0FBRUYsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsQ0FGTjtBQUdGLGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHO0FBSFIsR0FwQ1Y7QUF5Q0ksUUFBTTtBQUNGLFdBQU8sR0FETDtBQUVGLFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHLENBRk47QUFHRixjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRztBQUhSLEdBekNWO0FBOENJLFVBQVE7QUFDSixXQUFPLEdBREg7QUFFSixZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxDQUZKO0FBR0osY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEc7QUFITixHQTlDWjtBQW1ESSxTQUFPO0FBQ0gsV0FBTyxHQURKO0FBRUgsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsQ0FGTDtBQUdILGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHO0FBSFAsR0FuRFg7QUF3REksU0FBTztBQUNILFdBQU8sSUFESjtBQUVILFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHLEVBQXNHLEVBQXRHLEVBQTBHLEVBQTFHLEVBQThHLEVBQTlHLEVBQWtILEVBQWxILEVBQXNILEVBQXRILEVBQTBILEVBQTFILEVBQThILEVBQTlILEVBQWtJLEVBQWxJLEVBQXNJLEVBQXRJLEVBQTBJLEVBQTFJLEVBQThJLEVBQTlJLEVBQWtKLEVBQWxKLEVBQXNKLEVBQXRKLEVBQTBKLEVBQTFKLEVBQThKLEVBQTlKLENBRkw7QUFHSCxjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxFQUE4SCxFQUE5SCxFQUFrSSxFQUFsSSxFQUFzSSxFQUF0SSxFQUEwSSxFQUExSSxFQUE4SSxFQUE5SSxFQUFrSixFQUFsSixFQUFzSixFQUF0SixFQUEwSixFQUExSixFQUE4SixFQUE5SjtBQUhQLEdBeERYO0FBNkRJLFVBQVE7QUFDSixXQUFPLElBREg7QUFFSixZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxFQUE4SCxFQUE5SCxFQUFrSSxFQUFsSSxFQUFzSSxFQUF0SSxFQUEwSSxFQUExSSxFQUE4SSxFQUE5SSxFQUFrSixFQUFsSixDQUZKO0FBR0osY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUgsRUFBOEgsRUFBOUgsRUFBa0ksRUFBbEksRUFBc0ksRUFBdEksRUFBMEksRUFBMUksRUFBOEksRUFBOUksRUFBa0osRUFBbEo7QUFITixHQTdEWjtBQWtFSSxVQUFRO0FBQ0osV0FBTyxHQURIO0FBRUosWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUgsQ0FGSjtBQUdKLGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHLEVBQXNHLEVBQXRHLEVBQTBHLEVBQTFHLEVBQThHLEVBQTlHLEVBQWtILEVBQWxILEVBQXNILEVBQXRILEVBQTBILEVBQTFIO0FBSE4sR0FsRVo7QUF1RUksYUFBVztBQUNQLFdBQU8sR0FEQTtBQUVQLFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEdBQTlFLEVBQW1GLEdBQW5GLEVBQXdGLEdBQXhGLEVBQTZGLEdBQTdGLEVBQWtHLEdBQWxHLEVBQXVHLEdBQXZHLEVBQTRHLEdBQTVHLEVBQWlILEdBQWpILEVBQXNILEdBQXRILEVBQTJILEdBQTNILEVBQWdJLEdBQWhJLEVBQXFJLEdBQXJJLENBRkQ7QUFHUCxjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxHQUExRyxFQUErRyxHQUEvRyxFQUFvSCxHQUFwSCxFQUF5SCxHQUF6SCxFQUE4SCxHQUE5SDtBQUhILEdBdkVmO0FBNEVJLFlBQVU7QUFDTixXQUFPLEdBREQ7QUFFTixZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxDQUZGO0FBR04sY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUg7QUFISixHQTVFZDtBQWlGSSxTQUFPO0FBQ0gsV0FBTyxHQURKO0FBRUgsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUgsQ0FGTDtBQUdILGNBQVUsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHLEVBQXNHLEVBQXRHLEVBQTBHLEVBQTFHLEVBQThHLEVBQTlHLEVBQWtILEVBQWxILEVBQXNILEVBQXRILEVBQTBILEVBQTFIO0FBSFAsR0FqRlg7QUFzRkksU0FBTztBQUNILFdBQU8sSUFESjtBQUVILFlBQVEsQ0FBRSxFQUFGLEVBQU0sRUFBTixFQUFVLEVBQVYsRUFBYyxFQUFkLEVBQWtCLEVBQWxCLEVBQXNCLEVBQXRCLEVBQTBCLEVBQTFCLEVBQThCLEVBQTlCLEVBQWtDLEVBQWxDLEVBQXNDLEVBQXRDLEVBQTBDLEVBQTFDLEVBQThDLEVBQTlDLEVBQWtELEVBQWxELEVBQXNELEVBQXRELEVBQTBELEVBQTFELEVBQThELEVBQTlELEVBQWtFLEVBQWxFLEVBQXNFLEVBQXRFLEVBQTBFLEVBQTFFLEVBQThFLEVBQTlFLEVBQWtGLEVBQWxGLEVBQXNGLEVBQXRGLEVBQTBGLEVBQTFGLEVBQThGLEVBQTlGLEVBQWtHLEVBQWxHLEVBQXNHLEVBQXRHLEVBQTBHLEVBQTFHLEVBQThHLEVBQTlHLEVBQWtILEVBQWxILEVBQXNILEVBQXRILEVBQTBILEVBQTFILEVBQThILEVBQTlILEVBQWtJLEVBQWxJLEVBQXNJLEVBQXRJLEVBQTBJLEVBQTFJLEVBQThJLEVBQTlJLEVBQWtKLEVBQWxKLEVBQXNKLEVBQXRKLEVBQTBKLEVBQTFKLEVBQThKLEVBQTlKLEVBQWtLLEVBQWxLLEVBQXNLLEVBQXRLLEVBQTBLLEVBQTFLLEVBQThLLEVBQTlLLEVBQWtMLEVBQWxMLEVBQXNMLEVBQXRMLEVBQTBMLEVBQTFMLEVBQThMLEVBQTlMLEVBQWtNLEVBQWxNLEVBQXNNLEVBQXRNLEVBQTBNLEVBQTFNLEVBQThNLEVBQTlNLEVBQWtOLEVBQWxOLEVBQXNOLEVBQXROLEVBQTBOLEVBQTFOLEVBQThOLEVBQTlOLEVBQWtPLEVBQWxPLEVBQXNPLEVBQXRPLEVBQTBPLEVBQTFPLEVBQThPLEVBQTlPLEVBQWtQLEVBQWxQLEVBQXNQLEVBQXRQLEVBQTBQLEVBQTFQLEVBQThQLEVBQTlQLEVBQWtRLEVBQWxRLEVBQXNRLEVBQXRRLEVBQTBRLEVBQTFRLEVBQThRLEVBQTlRLEVBQWtSLEVBQWxSLEVBQXNSLEVBQXRSLEVBQTBSLEVBQTFSLEVBQThSLEVBQTlSLEVBQWtTLEVBQWxTLEVBQXNTLEVBQXRTLEVBQTBTLEVBQTFTLEVBQThTLEVBQTlTLEVBQWtULEVBQWxULEVBQXNULEVBQXRULEVBQTBULEVBQTFULEVBQThULEVBQTlULEVBQWtVLEVBQWxVLEVBQXNVLEVBQXRVLEVBQTBVLEVBQTFVLEVBQThVLEVBQTlVLEVBQWtWLEVBQWxWLEVBQXNWLEVBQXRWLEVBQTBWLEdBQTFWLEVBQStWLEdBQS9WLEVBQW9XLEdBQXBXLEVBQXlXLEdBQXpXLEVBQThXLEdBQTlXLEVBQW1YLEdBQW5YLEVBQXdYLEdBQXhYLEVBQTZYLEdBQTdYLEVBQWtZLEdBQWxZLEVBQXVZLEdBQXZZLEVBQTRZLEdBQTVZLENBRkw7QUFHSCxjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxFQUE4SCxFQUE5SCxFQUFrSSxFQUFsSSxFQUFzSSxFQUF0SSxFQUEwSSxFQUExSSxFQUE4SSxFQUE5SSxFQUFrSixFQUFsSixFQUFzSixFQUF0SixFQUEwSixFQUExSixFQUE4SixFQUE5SixFQUFrSyxFQUFsSyxFQUFzSyxFQUF0SyxFQUEwSyxFQUExSyxFQUE4SyxFQUE5SyxFQUFrTCxFQUFsTCxFQUFzTCxFQUF0TCxFQUEwTCxFQUExTCxFQUE4TCxFQUE5TCxFQUFrTSxFQUFsTSxFQUFzTSxFQUF0TSxFQUEwTSxFQUExTSxFQUE4TSxFQUE5TSxFQUFrTixFQUFsTixFQUFzTixFQUF0TixFQUEwTixFQUExTixFQUE4TixFQUE5TixFQUFrTyxFQUFsTyxFQUFzTyxFQUF0TyxFQUEwTyxFQUExTyxFQUE4TyxFQUE5TyxFQUFrUCxFQUFsUCxFQUFzUCxFQUF0UCxFQUEwUCxFQUExUCxFQUE4UCxFQUE5UCxFQUFrUSxFQUFsUSxFQUFzUSxFQUF0USxFQUEwUSxFQUExUSxFQUE4USxFQUE5USxFQUFrUixFQUFsUixFQUFzUixFQUF0UixFQUEwUixFQUExUixFQUE4UixFQUE5UixFQUFrUyxFQUFsUyxFQUFzUyxFQUF0UyxFQUEwUyxFQUExUyxFQUE4UyxFQUE5UyxFQUFrVCxFQUFsVCxFQUFzVCxFQUF0VCxFQUEwVCxFQUExVCxFQUE4VCxFQUE5VCxFQUFrVSxFQUFsVSxFQUFzVSxFQUF0VSxFQUEwVSxFQUExVSxFQUE4VSxFQUE5VSxFQUFrVixFQUFsVixFQUFzVixFQUF0VixFQUEwVixFQUExVixFQUE4VixFQUE5VixFQUFrVyxFQUFsVyxFQUFzVyxFQUF0VyxFQUEwVyxFQUExVyxFQUE4VyxFQUE5VyxFQUFrWCxFQUFsWCxFQUFzWCxFQUF0WCxFQUEwWCxFQUExWCxFQUE4WCxHQUE5WCxFQUFtWSxHQUFuWTtBQUhQLEdBdEZYO0FBMkZJLFNBQU87QUFDSCxXQUFPLElBREo7QUFFSCxZQUFRLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxFQUE4SCxFQUE5SCxFQUFrSSxFQUFsSSxFQUFzSSxFQUF0SSxFQUEwSSxFQUExSSxFQUE4SSxFQUE5SSxFQUFrSixFQUFsSixFQUFzSixFQUF0SixFQUEwSixFQUExSixFQUE4SixFQUE5SixFQUFrSyxFQUFsSyxFQUFzSyxFQUF0SyxFQUEwSyxFQUExSyxFQUE4SyxFQUE5SyxFQUFrTCxFQUFsTCxFQUFzTCxFQUF0TCxFQUEwTCxFQUExTCxFQUE4TCxFQUE5TCxFQUFrTSxFQUFsTSxFQUFzTSxFQUF0TSxFQUEwTSxFQUExTSxFQUE4TSxFQUE5TSxFQUFrTixFQUFsTixFQUFzTixFQUF0TixFQUEwTixFQUExTixFQUE4TixFQUE5TixFQUFrTyxFQUFsTyxFQUFzTyxFQUF0TyxFQUEwTyxFQUExTyxFQUE4TyxFQUE5TyxFQUFrUCxFQUFsUCxFQUFzUCxFQUF0UCxFQUEwUCxFQUExUCxFQUE4UCxFQUE5UCxFQUFrUSxFQUFsUSxFQUFzUSxFQUF0USxFQUEwUSxFQUExUSxFQUE4USxFQUE5USxFQUFrUixFQUFsUixFQUFzUixFQUF0UixFQUEwUixFQUExUixFQUE4UixFQUE5UixFQUFrUyxFQUFsUyxDQUZMO0FBR0gsY0FBVSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUgsRUFBOEgsRUFBOUgsRUFBa0ksRUFBbEksRUFBc0ksRUFBdEksRUFBMEksRUFBMUksRUFBOEksRUFBOUksRUFBa0osRUFBbEosRUFBc0osRUFBdEosRUFBMEosRUFBMUosRUFBOEosRUFBOUosRUFBa0ssRUFBbEssRUFBc0ssRUFBdEssRUFBMEssRUFBMUssRUFBOEssRUFBOUssRUFBa0wsRUFBbEwsRUFBc0wsRUFBdEwsRUFBMEwsRUFBMUwsRUFBOEwsRUFBOUwsRUFBa00sRUFBbE0sRUFBc00sRUFBdE0sRUFBME0sRUFBMU0sRUFBOE0sRUFBOU0sRUFBa04sRUFBbE4sRUFBc04sRUFBdE4sRUFBME4sRUFBMU4sRUFBOE4sRUFBOU4sRUFBa08sRUFBbE8sRUFBc08sRUFBdE8sRUFBME8sRUFBMU8sRUFBOE8sRUFBOU8sRUFBa1AsRUFBbFAsRUFBc1AsRUFBdFAsRUFBMFAsRUFBMVAsRUFBOFAsRUFBOVAsRUFBa1EsRUFBbFEsRUFBc1EsRUFBdFEsRUFBMFEsRUFBMVEsRUFBOFEsRUFBOVEsRUFBa1IsRUFBbFIsRUFBc1IsRUFBdFIsRUFBMFIsRUFBMVIsRUFBOFIsRUFBOVIsRUFBa1MsRUFBbFM7QUFIUCxHQTNGWDtBQWdHSSxTQUFPO0FBQ0gsV0FBTyxJQURKO0FBRUgsWUFBUSxDQUFFLEVBQUYsRUFBTSxFQUFOLEVBQVUsRUFBVixFQUFjLEVBQWQsRUFBa0IsRUFBbEIsRUFBc0IsRUFBdEIsRUFBMEIsRUFBMUIsRUFBOEIsRUFBOUIsRUFBa0MsRUFBbEMsRUFBc0MsRUFBdEMsRUFBMEMsRUFBMUMsRUFBOEMsRUFBOUMsRUFBa0QsRUFBbEQsRUFBc0QsRUFBdEQsRUFBMEQsRUFBMUQsRUFBOEQsRUFBOUQsRUFBa0UsRUFBbEUsRUFBc0UsRUFBdEUsRUFBMEUsRUFBMUUsRUFBOEUsRUFBOUUsRUFBa0YsRUFBbEYsRUFBc0YsRUFBdEYsRUFBMEYsRUFBMUYsRUFBOEYsRUFBOUYsRUFBa0csRUFBbEcsRUFBc0csRUFBdEcsRUFBMEcsRUFBMUcsRUFBOEcsRUFBOUcsRUFBa0gsRUFBbEgsRUFBc0gsRUFBdEgsRUFBMEgsRUFBMUgsRUFBOEgsRUFBOUgsRUFBa0ksRUFBbEksRUFBc0ksRUFBdEksRUFBMEksRUFBMUksRUFBOEksRUFBOUksRUFBa0osRUFBbEosRUFBc0osRUFBdEosRUFBMEosRUFBMUosRUFBOEosRUFBOUosRUFBa0ssRUFBbEssRUFBc0ssRUFBdEssRUFBMEssRUFBMUssRUFBOEssRUFBOUssRUFBa0wsRUFBbEwsRUFBc0wsRUFBdEwsRUFBMEwsRUFBMUwsRUFBOEwsRUFBOUwsRUFBa00sRUFBbE0sRUFBc00sRUFBdE0sRUFBME0sRUFBMU0sRUFBOE0sRUFBOU0sRUFBa04sRUFBbE4sRUFBc04sRUFBdE4sRUFBME4sRUFBMU4sRUFBOE4sRUFBOU4sRUFBa08sRUFBbE8sRUFBc08sRUFBdE8sRUFBME8sRUFBMU8sRUFBOE8sRUFBOU8sRUFBa1AsRUFBbFAsRUFBc1AsRUFBdFAsRUFBMFAsRUFBMVAsRUFBOFAsRUFBOVAsRUFBa1EsRUFBbFEsRUFBc1EsRUFBdFEsRUFBMFEsRUFBMVEsRUFBOFEsRUFBOVEsRUFBa1IsRUFBbFIsRUFBc1IsRUFBdFIsRUFBMFIsRUFBMVIsRUFBOFIsRUFBOVIsRUFBa1MsRUFBbFMsRUFBc1MsRUFBdFMsRUFBMFMsRUFBMVMsRUFBOFMsRUFBOVMsRUFBa1QsRUFBbFQsRUFBc1QsRUFBdFQsRUFBMFQsRUFBMVQsRUFBOFQsRUFBOVQsRUFBa1UsRUFBbFUsRUFBc1UsRUFBdFUsRUFBMFUsRUFBMVUsRUFBOFUsRUFBOVUsRUFBa1YsRUFBbFYsRUFBc1YsRUFBdFYsRUFBMFYsRUFBMVYsRUFBOFYsRUFBOVYsRUFBa1csRUFBbFcsRUFBc1csRUFBdFcsRUFBMFcsRUFBMVcsRUFBOFcsRUFBOVcsRUFBa1gsRUFBbFgsRUFBc1gsRUFBdFgsRUFBMFgsRUFBMVgsRUFBOFgsRUFBOVgsRUFBa1ksRUFBbFksRUFBc1ksRUFBdFksRUFBMFksRUFBMVksRUFBOFksRUFBOVksRUFBa1osRUFBbFosRUFBc1osRUFBdFosRUFBMFosRUFBMVosRUFBOFosRUFBOVosRUFBa2EsRUFBbGEsRUFBc2EsRUFBdGEsRUFBMGEsRUFBMWEsRUFBOGEsRUFBOWEsRUFBa2IsRUFBbGIsRUFBc2IsRUFBdGIsRUFBMGIsRUFBMWIsRUFBOGIsRUFBOWIsRUFBa2MsRUFBbGMsRUFBc2MsRUFBdGMsRUFBMGMsRUFBMWMsRUFBOGMsRUFBOWMsRUFBa2QsRUFBbGQsRUFBc2QsRUFBdGQsRUFBMGQsRUFBMWQsRUFBOGQsRUFBOWQsRUFBa2UsRUFBbGUsRUFBc2UsRUFBdGUsRUFBMGUsRUFBMWUsRUFBOGUsRUFBOWUsRUFBa2YsRUFBbGYsRUFBc2YsRUFBdGYsRUFBMGYsRUFBMWYsRUFBOGYsRUFBOWYsRUFBa2dCLEVBQWxnQixFQUFzZ0IsRUFBdGdCLEVBQTBnQixFQUExZ0IsRUFBOGdCLEVBQTlnQixFQUFraEIsRUFBbGhCLEVBQXNoQixFQUF0aEIsRUFBMGhCLEVBQTFoQixFQUE4aEIsRUFBOWhCLEVBQWtpQixFQUFsaUIsRUFBc2lCLEVBQXRpQixFQUEwaUIsRUFBMWlCLEVBQThpQixFQUE5aUIsRUFBa2pCLEVBQWxqQixFQUFzakIsRUFBdGpCLEVBQTBqQixFQUExakIsRUFBOGpCLEVBQTlqQixFQUFra0IsRUFBbGtCLEVBQXNrQixFQUF0a0IsRUFBMGtCLEVBQTFrQixFQUE4a0IsRUFBOWtCLEVBQWtsQixFQUFsbEIsRUFBc2xCLEVBQXRsQixFQUEwbEIsRUFBMWxCLEVBQThsQixFQUE5bEIsRUFBa21CLEVBQWxtQixFQUFzbUIsRUFBdG1CLEVBQTBtQixFQUExbUIsRUFBOG1CLEVBQTltQixFQUFrbkIsRUFBbG5CLEVBQXNuQixFQUF0bkIsRUFBMG5CLEVBQTFuQixFQUE4bkIsR0FBOW5CLEVBQW1vQixHQUFub0IsRUFBd29CLEdBQXhvQixFQUE2b0IsR0FBN29CLEVBQWtwQixHQUFscEIsRUFBdXBCLEdBQXZwQixFQUE0cEIsR0FBNXBCLEVBQWlxQixHQUFqcUIsRUFBc3FCLEdBQXRxQixFQUEycUIsR0FBM3FCLENBRkw7QUFHSCxjQUFVLENBQUUsRUFBRixFQUFNLEVBQU4sRUFBVSxFQUFWLEVBQWMsRUFBZCxFQUFrQixFQUFsQixFQUFzQixFQUF0QixFQUEwQixFQUExQixFQUE4QixFQUE5QixFQUFrQyxFQUFsQyxFQUFzQyxFQUF0QyxFQUEwQyxFQUExQyxFQUE4QyxFQUE5QyxFQUFrRCxFQUFsRCxFQUFzRCxFQUF0RCxFQUEwRCxFQUExRCxFQUE4RCxFQUE5RCxFQUFrRSxFQUFsRSxFQUFzRSxFQUF0RSxFQUEwRSxFQUExRSxFQUE4RSxFQUE5RSxFQUFrRixFQUFsRixFQUFzRixFQUF0RixFQUEwRixFQUExRixFQUE4RixFQUE5RixFQUFrRyxFQUFsRyxFQUFzRyxFQUF0RyxFQUEwRyxFQUExRyxFQUE4RyxFQUE5RyxFQUFrSCxFQUFsSCxFQUFzSCxFQUF0SCxFQUEwSCxFQUExSCxFQUE4SCxFQUE5SCxFQUFrSSxFQUFsSSxFQUFzSSxFQUF0SSxFQUEwSSxFQUExSSxFQUE4SSxFQUE5SSxFQUFrSixFQUFsSixFQUFzSixFQUF0SixFQUEwSixFQUExSixFQUE4SixFQUE5SixFQUFrSyxFQUFsSyxFQUFzSyxFQUF0SyxFQUEwSyxFQUExSyxFQUE4SyxFQUE5SyxFQUFrTCxFQUFsTCxFQUFzTCxFQUF0TCxFQUEwTCxFQUExTCxFQUE4TCxFQUE5TCxFQUFrTSxFQUFsTSxFQUFzTSxFQUF0TSxFQUEwTSxFQUExTSxFQUE4TSxFQUE5TSxFQUFrTixFQUFsTixFQUFzTixFQUF0TixFQUEwTixFQUExTixFQUE4TixFQUE5TixFQUFrTyxFQUFsTyxFQUFzTyxFQUF0TyxFQUEwTyxFQUExTyxFQUE4TyxFQUE5TyxFQUFrUCxFQUFsUCxFQUFzUCxFQUF0UCxFQUEwUCxFQUExUCxFQUE4UCxFQUE5UCxFQUFrUSxFQUFsUSxFQUFzUSxFQUF0USxFQUEwUSxFQUExUSxFQUE4USxFQUE5USxFQUFrUixFQUFsUixFQUFzUixFQUF0UixFQUEwUixFQUExUixFQUE4UixFQUE5UixFQUFrUyxFQUFsUyxFQUFzUyxFQUF0UyxFQUEwUyxFQUExUyxFQUE4UyxFQUE5UyxFQUFrVCxFQUFsVCxFQUFzVCxFQUF0VCxFQUEwVCxFQUExVCxFQUE4VCxFQUE5VCxFQUFrVSxFQUFsVSxFQUFzVSxFQUF0VSxFQUEwVSxFQUExVSxFQUE4VSxFQUE5VSxFQUFrVixFQUFsVixFQUFzVixFQUF0VixFQUEwVixFQUExVixFQUE4VixFQUE5VixFQUFrVyxFQUFsVyxFQUFzVyxFQUF0VyxFQUEwVyxFQUExVyxFQUE4VyxFQUE5VyxFQUFrWCxFQUFsWCxFQUFzWCxFQUF0WCxFQUEwWCxFQUExWCxFQUE4WCxFQUE5WCxFQUFrWSxFQUFsWSxFQUFzWSxFQUF0WSxFQUEwWSxFQUExWSxFQUE4WSxFQUE5WSxFQUFrWixFQUFsWixFQUFzWixFQUF0WixFQUEwWixFQUExWixFQUE4WixFQUE5WixFQUFrYSxFQUFsYSxFQUFzYSxFQUF0YSxFQUEwYSxFQUExYSxFQUE4YSxFQUE5YSxFQUFrYixFQUFsYixFQUFzYixFQUF0YixFQUEwYixFQUExYixFQUE4YixFQUE5YixFQUFrYyxFQUFsYyxFQUFzYyxFQUF0YyxFQUEwYyxFQUExYyxFQUE4YyxFQUE5YyxFQUFrZCxFQUFsZCxFQUFzZCxFQUF0ZCxFQUEwZCxFQUExZCxFQUE4ZCxFQUE5ZCxFQUFrZSxFQUFsZSxFQUFzZSxFQUF0ZSxFQUEwZSxFQUExZSxFQUE4ZSxFQUE5ZSxFQUFrZixFQUFsZixFQUFzZixFQUF0ZixFQUEwZixFQUExZixFQUE4ZixFQUE5ZixFQUFrZ0IsRUFBbGdCLEVBQXNnQixFQUF0Z0IsRUFBMGdCLEVBQTFnQixFQUE4Z0IsRUFBOWdCLEVBQWtoQixFQUFsaEIsRUFBc2hCLEVBQXRoQixFQUEwaEIsRUFBMWhCLEVBQThoQixFQUE5aEIsRUFBa2lCLEVBQWxpQixFQUFzaUIsRUFBdGlCLEVBQTBpQixFQUExaUIsRUFBOGlCLEVBQTlpQixFQUFrakIsRUFBbGpCLEVBQXNqQixFQUF0akIsRUFBMGpCLEVBQTFqQixFQUE4akIsRUFBOWpCLEVBQWtrQixFQUFsa0IsRUFBc2tCLEVBQXRrQixFQUEwa0IsRUFBMWtCLEVBQThrQixFQUE5a0IsRUFBa2xCLEVBQWxsQixFQUFzbEIsRUFBdGxCLEVBQTBsQixFQUExbEIsRUFBOGxCLEVBQTlsQixFQUFrbUIsRUFBbG1CLEVBQXNtQixFQUF0bUIsRUFBMG1CLEVBQTFtQixFQUE4bUIsRUFBOW1CLEVBQWtuQixFQUFsbkIsRUFBc25CLEVBQXRuQixFQUEwbkIsRUFBMW5CLEVBQThuQixFQUE5bkIsRUFBa29CLEVBQWxvQixFQUFzb0IsRUFBdG9CLEVBQTBvQixFQUExb0IsRUFBOG9CLEVBQTlvQixFQUFrcEIsRUFBbHBCLEVBQXNwQixFQUF0cEIsRUFBMHBCLEVBQTFwQixFQUE4cEIsRUFBOXBCLEVBQWtxQixFQUFscUI7QUFIUDtBQWhHWCxDQURBOztBQXdHQSxTQUFTQyx3QkFBVCxDQUFrQ0MsTUFBbEMsRUFBMENDLEdBQTFDLEVBQThDO0FBQzFDLE1BQUlDLGdCQUFnQixHQUFHO0FBQUUsV0FBTyxDQUFUO0FBQ25CLFdBQU9GLE1BQU0sQ0FBQyxNQUFELENBQU4sR0FBaUJBLE1BQU0sQ0FBQyxLQUFELENBQXZCLEdBQWlDQSxNQUFNLENBQUMsSUFBRCxDQUF2QyxHQUFnREEsTUFBTSxDQUFDLElBQUQsQ0FEMUM7QUFFbkIsV0FBUUEsTUFBTSxDQUFDLEtBQUQsQ0FBTixHQUFnQkEsTUFBTSxDQUFDLElBQUQsQ0FBdEIsR0FBK0JBLE1BQU0sQ0FBQyxNQUFEO0FBRjFCLEdBQXZCO0FBSUFFLGtCQUFnQixDQUFDLEtBQUQsQ0FBaEIsR0FBMEJBLGdCQUFnQixDQUFDLEtBQUQsQ0FBaEIsR0FBMEJBLGdCQUFnQixDQUFDLEtBQUQsQ0FBcEU7O0FBRUEsT0FBSSxJQUFJQyxRQUFSLElBQW9CQyxNQUFNLENBQUNDLElBQVAsQ0FBWUgsZ0JBQVosQ0FBcEIsRUFBa0Q7QUFDOUMsVUFBTUksS0FBSyxHQUFHUixjQUFjLENBQUNLLFFBQVEsQ0FBQ0ksV0FBVCxFQUFELENBQTVCO0FBQ0FMLG9CQUFnQixDQUFDQyxRQUFELENBQWhCLEdBQTZCRyxLQUFLLENBQUNMLEdBQUQsQ0FBTCxDQUFXTyxJQUFJLENBQUNDLEtBQUwsQ0FBV1AsZ0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJHLEtBQUssQ0FBQ0ksR0FBOUMsQ0FBWCxDQUE3QjtBQUNIOztBQUVELFFBQU1DLFNBQVMsR0FBR1AsTUFBTSxDQUFDQyxJQUFQLENBQVlMLE1BQVosQ0FBbEI7O0FBRUEsT0FBSSxJQUFJRyxRQUFSLElBQW9CUSxTQUFwQixFQUE4QjtBQUMxQixVQUFNTCxLQUFLLEdBQUdSLGNBQWMsQ0FBQ0ssUUFBUSxDQUFDSSxXQUFULEVBQUQsQ0FBNUI7QUFDQUwsb0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJHLEtBQUssQ0FBQ0wsR0FBRCxDQUFMLENBQVdPLElBQUksQ0FBQ0MsS0FBTCxDQUFXVCxNQUFNLENBQUNHLFFBQUQsQ0FBTixHQUFtQkcsS0FBSyxDQUFDSSxHQUFwQyxDQUFYLENBQTdCO0FBQ0g7O0FBRUQsU0FBT1IsZ0JBQVA7QUFDSDs7QUFFRCxTQUFTVSxzQkFBVCxDQUFnQ1osTUFBaEMsRUFBdUM7QUFDbkMsTUFBSUUsZ0JBQWdCLEdBQUcsRUFBdkI7O0FBQ0EsT0FBSSxJQUFJQyxRQUFSLElBQW9CQyxNQUFNLENBQUNDLElBQVAsQ0FBWUwsTUFBWixDQUFwQixFQUF3QztBQUNwQyxRQUFJYSxLQUFLLEdBQUdiLE1BQU0sQ0FBQ0csUUFBRCxDQUFsQjs7QUFDQSxRQUFHQSxRQUFRLElBQUksWUFBZixFQUE0QjtBQUN4QkQsc0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJVLEtBQUssR0FBRyxFQUFyQztBQUNILEtBRkQsTUFHSyxJQUFHVixRQUFRLElBQUksY0FBZixFQUE4QjtBQUMvQkQsc0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJVLEtBQUssR0FBRyxFQUFyQztBQUNILEtBRkksTUFHQSxJQUFHVixRQUFRLElBQUksS0FBZixFQUFxQjtBQUN0QkQsc0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJVLEtBQUssR0FBRyxDQUFyQztBQUNILEtBRkksTUFHQSxJQUFHVixRQUFRLElBQUksTUFBZixFQUFzQjtBQUN2QkQsc0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJVLEtBQUssR0FBRyxDQUFyQztBQUNILEtBRkksTUFHQSxJQUFHVixRQUFRLElBQUksS0FBZixFQUFxQjtBQUN0QkQsc0JBQWdCLENBQUNDLFFBQUQsQ0FBaEIsR0FBNkJVLEtBQUssR0FBRyxDQUFyQztBQUNIO0FBQ0o7O0FBRUQsU0FBT1gsZ0JBQVA7QUFDSDs7QUFFRCxTQUFTTCxlQUFULENBQXlCTSxRQUF6QixFQUFtQ0gsTUFBbkMsRUFBMkNDLEdBQTNDLEVBQStDO0FBQzNDLFVBQVFFLFFBQVEsQ0FBQ1csV0FBVCxFQUFSO0FBQ0ksU0FBSyxPQUFMO0FBQ0ksYUFBT2Ysd0JBQXdCLENBQUNDLE1BQUQsRUFBU0MsR0FBVCxDQUEvQjtBQUNKO0FBQ0E7O0FBQ0E7QUFDSTtBQUNBLGFBQU8sS0FBUDtBQVBSO0FBU0gsQzs7Ozs7Ozs7Ozs7O0FDaktELE1BQUliLE1BQUo7QUFBVzJCLFNBQU8sQ0FBQzdCLElBQVIsQ0FBYSxlQUFiLEVBQTZCO0FBQUNFLFVBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFlBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixHQUE3QixFQUFtRCxDQUFuRDtBQUFzRCxNQUFJNkIsUUFBSjtBQUFhRCxTQUFPLENBQUM3QixJQUFSLENBQWEsc0JBQWIsRUFBb0M7QUFBQzhCLFlBQVEsQ0FBQzdCLENBQUQsRUFBRztBQUFDNkIsY0FBUSxHQUFDN0IsQ0FBVDtBQUFXOztBQUF4QixHQUFwQyxFQUE4RCxDQUE5RDtBQUFpRSxNQUFJOEIsS0FBSjtBQUFVRixTQUFPLENBQUM3QixJQUFSLENBQWEsdUJBQWIsRUFBcUM7QUFBQytCLFNBQUssQ0FBQzlCLENBQUQsRUFBRztBQUFDOEIsV0FBSyxHQUFDOUIsQ0FBTjtBQUFROztBQUFsQixHQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxNQUFJVSxlQUFKO0FBQW9Ca0IsU0FBTyxDQUFDN0IsSUFBUixDQUFhLDJCQUFiLEVBQXlDO0FBQUNXLG1CQUFlLENBQUNWLENBQUQsRUFBRztBQUFDVSxxQkFBZSxHQUFDVixDQUFoQjtBQUFrQjs7QUFBdEMsR0FBekMsRUFBaUYsQ0FBakY7QUFBb0YsTUFBSStCLElBQUo7QUFBU0gsU0FBTyxDQUFDN0IsSUFBUixDQUFhLHdCQUFiLEVBQXNDO0FBQUNnQyxRQUFJLENBQUMvQixDQUFELEVBQUc7QUFBQytCLFVBQUksR0FBQy9CLENBQUw7QUFBTzs7QUFBaEIsR0FBdEMsRUFBd0QsQ0FBeEQ7QUFNdFUsUUFBTWdDLFVBQVUsR0FBRztBQUNmQyxZQUFRLEVBQUUsV0FESztBQUVmQyxZQUFRLEVBQUUsVUFGSztBQUdmQyxTQUFLLEVBQUUsdUJBSFE7QUFJZkMsYUFBUyxFQUFFLFFBSkk7QUFLZkMsWUFBUSxFQUFFLE1BTEs7QUFNZkMsT0FBRyxFQUFHLEVBTlM7QUFPZkMsZ0JBQVksRUFBRSxHQVBDO0FBUWZDLFFBQUksRUFBRSxPQVJTO0FBU2ZDLHdCQUFvQixFQUFFLE9BVFA7QUFVZjNCLE9BQUcsRUFBRSxRQVZVO0FBV2Y0QixZQUFRLEVBQUUsRUFYSztBQVlmQyxjQUFVLEVBQUUsQ0FBQztBQVpFLEdBQW5CO0FBY0EsUUFBTUMsZUFBZSxHQUFHO0FBQ3BCWCxZQUFRLEVBQUUsZ0JBRFU7QUFFcEJDLFlBQVEsRUFBRSxVQUZVO0FBR3BCQyxTQUFLLEVBQUUsNEJBSGE7QUFJcEJDLGFBQVMsRUFBRSxZQUpTO0FBS3BCQyxZQUFRLEVBQUUsTUFMVTtBQU1wQkMsT0FBRyxFQUFHLEVBTmM7QUFPcEJDLGdCQUFZLEVBQUUsR0FQTTtBQVFwQkMsUUFBSSxFQUFFLFlBUmM7QUFTcEJDLHdCQUFvQixFQUFFLE9BVEY7QUFVcEIzQixPQUFHLEVBQUUsTUFWZTtBQVdwQjRCLFlBQVEsRUFBRSxFQVhVO0FBWXBCQyxjQUFVLEVBQUUsQ0FBQztBQVpPLEdBQXhCO0FBY0EsUUFBTUUsU0FBUyxHQUFHO0FBQ2RaLFlBQVEsRUFBRSxVQURJO0FBRWRDLFlBQVEsRUFBRSxVQUZJO0FBR2RDLFNBQUssRUFBRSxzQkFITztBQUlkQyxhQUFTLEVBQUUsTUFKRztBQUtkQyxZQUFRLEVBQUUsTUFMSTtBQU1kQyxPQUFHLEVBQUcsRUFOUTtBQU9kQyxnQkFBWSxFQUFFLEdBUEE7QUFRZEMsUUFBSSxFQUFFLE1BUlE7QUFTZEMsd0JBQW9CLEVBQUUsSUFUUjtBQVVkM0IsT0FBRyxFQUFFLFFBVlM7QUFXZDRCLFlBQVEsRUFBRSxFQVhJO0FBWWRJLCtCQUEyQixFQUFFLEtBWmY7QUFhZEgsY0FBVSxFQUFFO0FBYkUsR0FBbEI7QUFlQSxRQUFNSSxVQUFVLEdBQUc7QUFDZmQsWUFBUSxFQUFFLGtCQURLO0FBRWZDLFlBQVEsRUFBRSxVQUZLO0FBR2ZDLFNBQUssRUFBRSw4QkFIUTtBQUlmQyxhQUFTLEVBQUUsTUFKSTtBQUtmQyxZQUFRLEVBQUUsTUFMSztBQU1mQyxPQUFHLEVBQUcsZUFOUztBQU9mQyxnQkFBWSxFQUFFLEdBUEM7QUFRZkMsUUFBSSxFQUFFLE1BUlM7QUFTZkMsd0JBQW9CLEVBQUUsSUFUUDtBQVVmM0IsT0FBRyxFQUFFLE1BVlU7QUFXZjRCLFlBQVEsRUFBRSxFQVhLO0FBWWZJLCtCQUEyQixFQUFFLEtBWmQ7QUFhZkgsY0FBVSxFQUFFO0FBYkcsR0FBbkI7QUFlQSxRQUFNSyxVQUFVLEdBQUcsQ0FBQ2hCLFVBQUQsRUFBYVksZUFBYixFQUE4QkMsU0FBOUIsRUFBeUNFLFVBQXpDLENBQW5CO0FBQ0EsUUFBTUUsVUFBVSxHQUFHLENBQUMsTUFBRCxFQUFTLFlBQVQsRUFBdUIsT0FBdkIsQ0FBbkIsQyxDQUVBOztBQUNBQyxvQkFBa0IsR0FBRyxJQUFyQjtBQUNBbkIsTUFBSSxDQUFDb0IsU0FBTCxDQUFlO0FBQ1hDLFdBQU8sRUFBRSxLQURFO0FBRVhDLGlCQUFhLEVBQUU7QUFDYkgsd0JBRGE7QUFFYkksaUJBQVcsRUFBRTtBQUZBLEtBRko7QUFNWEMsWUFBUSxFQUFFO0FBQ1I7QUFDQUMsbUJBQWEsRUFBRSxDQUZQO0FBRW1CO0FBQzNCQyxrQkFBWSxFQUFFLElBSE47QUFJUkMsdUJBQWlCLEVBQUUsS0FKWDtBQUltQjtBQUMzQkMsZ0JBQVUsRUFBRSxJQUxKO0FBS21CO0FBQzNCQyxpQkFBVyxFQUFFLEtBTkw7QUFNbUI7QUFFM0I7QUFDQVIsYUFBTyxFQUFFLEtBVEQ7QUFTZTtBQUN2QlMsV0FBSyxFQUFFLE1BVkM7QUFVbUI7QUFDM0JDLFVBQUksRUFBRSxJQVhFO0FBV21CO0FBQzNCQyxjQUFRLEVBQUUsaUNBWkY7QUFhUkMsV0FBSyxFQUFFLENBYkM7QUFhbUI7QUFDM0JDLGFBQU8sRUFBRSxDQWREO0FBY21CO0FBQzNCQyx3QkFBa0IsRUFBRSxLQWZaO0FBZW1CO0FBQzNCQyxvQkFBYyxFQUFFLGVBaEJSO0FBZ0IyQjtBQUVuQztBQUNBQyxrQkFBWSxFQUFFLElBbkJOO0FBb0JSQyxXQUFLLEVBQUUsZ0JBcEJDO0FBb0JtQjtBQUMzQkMsaUJBQVcsRUFBRSxFQXJCTDtBQXFCbUI7QUFDM0JDLGFBQU8sRUFBRSxJQXRCRDtBQXNCbUI7QUFFM0I7QUFDQUMsVUFBSSxFQUFFLGVBekJFO0FBeUJtQjtBQUMzQkMsV0FBSyxFQUFFLFNBMUJDO0FBMEJtQjtBQUMzQkMsU0FBRyxFQUFFLFFBM0JHO0FBMkJtQjtBQUMzQkMsY0FBUSxFQUFFLE1BNUJGO0FBNEJtQjtBQUMzQkMsMEJBQW9CLEVBQUUsa0JBN0JkO0FBNkJrQztBQUMxQ0MsaUJBQVcsRUFBRSxDQTlCTDtBQThCbUI7QUFDM0JDLGlCQUFXLEVBQUUsSUEvQkw7QUErQnFCO0FBQzdCQyxnQkFBVSxFQUFFLFNBaENKO0FBZ0NlO0FBRXZCO0FBQ0FDLGFBQU8sRUFBRSwrQkFuQ0Q7QUFvQ1JDLGFBQU8sRUFBRSxJQXBDRDtBQW9DdUI7QUFDL0JDLFlBQU0sWUFBSyxPQUFPLElBQVosQ0FyQ0UsQ0FxQ3VCOztBQXJDdkI7QUFOQyxHQUFmO0FBZ0RBakYsUUFBTSxDQUFDa0YsT0FBUCxDQUFlLE1BQU07QUFFakI7QUFDQUMsVUFBTSxDQUFDQyxLQUFQLENBQWEsTUFBYixFQUFvQjtBQUNwQkMsV0FBSyxFQUFFLFFBRGE7QUFFcEJDLFlBQU0sRUFBRSxZQUFXO0FBQ2YsYUFBS0MsUUFBTCxDQUFjQyxTQUFkLENBQXdCLEdBQXhCLEVBQTZCO0FBQ3pCLDBCQUFnQixrQkFEUztBQUV6Qix5Q0FBK0I7QUFGTixTQUE3QjtBQUlBQyxlQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFLQyxPQUFMLENBQWFDLE9BQXpCO0FBQ0E1RCxnQkFBUSxHQUFHLEtBQUsyRCxPQUFMLENBQWFDLE9BQWIsQ0FBcUIsV0FBckIsQ0FBWDtBQUNBQyxrQkFBVSxHQUFHLEtBQUtGLE9BQUwsQ0FBYUMsT0FBYixDQUFxQixjQUFyQixDQUFiO0FBQ0FFLFlBQUksR0FBRzlGLE1BQU0sQ0FBQytGLEtBQVAsQ0FBYUMsT0FBYixDQUFxQjtBQUFDaEUsa0JBQVEsRUFBRUE7QUFBWCxTQUFyQixDQUFQO0FBQ0FpRSxzQkFBYyxHQUFHLElBQWpCO0FBQ0FoRixZQUFJLEdBQUc2RSxJQUFJLENBQUNJLEdBQVo7QUFDQUMsV0FBRyxHQUFHLElBQUlDLElBQUosRUFBTjtBQUNBQyxlQUFPLEdBQUdwRixJQUFJLENBQUNxRixPQUFmO0FBQ0FELGVBQU8sQ0FBQ0UsT0FBUixDQUFnQkYsT0FBTyxDQUFDRyxPQUFSLEVBQWhCO0FBQ0FmLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JTLEdBQXBCLEVBQXlCRSxPQUF6QixFQUFrQ3BGLElBQUksQ0FBQ3FGLE9BQXZDOztBQUNBLFlBQUdILEdBQUcsR0FBR0UsT0FBVCxFQUFpQjtBQUNiSix3QkFBYyxHQUFHLEtBQWpCO0FBQ0g7O0FBQ0QsWUFBRyxDQUFDSCxJQUFELElBQVNBLElBQUksQ0FBQ0ksR0FBTCxDQUFTTyxLQUFULElBQWtCWixVQUEzQixJQUF5Q0ksY0FBYyxJQUFJLElBQTlELEVBQW1FO0FBQy9ELGVBQUtWLFFBQUwsQ0FBY21CLEdBQWQsQ0FBa0IsaUVBQWxCO0FBQ0gsU0FGRCxNQUVPO0FBQ0hDLHNCQUFZLEdBQUcxRyxJQUFJLENBQUMrRixPQUFMLENBQWE7QUFBQ1ksc0JBQVUsRUFBRWQsSUFBSSxDQUFDZTtBQUFsQixXQUFiLENBQWY7QUFDQUMsa0JBQVEsR0FBRzlHLE1BQU0sQ0FBQytGLEtBQVAsQ0FBYWdCLElBQWIsQ0FBa0I7QUFBQ0osd0JBQVksRUFBRUEsWUFBWSxDQUFDRTtBQUE1QixXQUFsQixFQUFvRDtBQUMzREcsa0JBQU0sRUFBRTtBQUNKQyx1QkFBUyxFQUFFLENBRFA7QUFFSkMsc0JBQVEsRUFBRSxDQUZOO0FBR0pDLG9CQUFNLEVBQUUsQ0FISjtBQUlKbkYsc0JBQVEsRUFBRSxDQUpOO0FBS0pPLGtCQUFJLEVBQUUsQ0FMRjtBQU1KQyxrQ0FBb0IsRUFBRSxDQU5sQjtBQU9KNEUsc0JBQVEsRUFBRSxDQVBOO0FBUUpULDBCQUFZLEVBQUUsQ0FSVjtBQVNKVCxpQkFBRyxFQUFFO0FBVEQ7QUFEbUQsV0FBcEQsRUFZUm1CLEtBWlEsRUFBWDtBQWFBQywwQkFBZ0IsR0FBRyxFQUFuQjs7QUFDQSxlQUFJQyxDQUFDLEdBQUcsQ0FBUixFQUFXQSxDQUFDLEdBQUdULFFBQVEsQ0FBQ1UsTUFBeEIsRUFBZ0NELENBQUMsRUFBakMsRUFBb0M7QUFDaENFLHNCQUFVLEdBQUdySCxNQUFNLENBQUMyRyxJQUFQLENBQVk7QUFBQ1csb0JBQU0sRUFBRVosUUFBUSxDQUFDUyxDQUFELENBQVIsQ0FBWVY7QUFBckIsYUFBWixFQUF1Q1EsS0FBdkMsRUFBYjtBQUNBTSx1QkFBVyxHQUFHdEgsT0FBTyxDQUFDMEcsSUFBUixDQUFhO0FBQUNXLG9CQUFNLEVBQUVaLFFBQVEsQ0FBQ1MsQ0FBRCxDQUFSLENBQVlWO0FBQXJCLGFBQWIsRUFBd0NRLEtBQXhDLEVBQWQ7QUFDQU8sbUJBQU8sR0FBR2QsUUFBUSxDQUFDUyxDQUFELENBQWxCO0FBQ0FLLG1CQUFPLENBQUNDLE1BQVIsR0FBaUJDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLFNBQUwsQ0FBZVAsVUFBZixDQUFYLENBQWpCO0FBQ0FHLG1CQUFPLENBQUNLLE9BQVIsR0FBa0JILElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLFNBQUwsQ0FBZUwsV0FBZixDQUFYLENBQWxCO0FBQ0FMLDRCQUFnQixDQUFDWSxJQUFqQixDQUFzQk4sT0FBdEI7QUFDSDs7QUFDRGpCLHNCQUFZLENBQUNaLEtBQWIsR0FBcUJ1QixnQkFBckI7QUFDQSxlQUFLL0IsUUFBTCxDQUFjbUIsR0FBZCxDQUFrQm9CLElBQUksQ0FBQ0UsU0FBTCxDQUFlckIsWUFBZixDQUFsQjtBQUNDO0FBQ0o7QUFqRGUsS0FBcEIsRUFIaUIsQ0F1RGpCOztBQUNBLFFBQUd4RyxXQUFXLENBQUM0RyxJQUFaLEdBQW1Cb0IsS0FBbkIsT0FBK0IsQ0FBbEMsRUFBb0M7QUFDaEMxQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSwyQ0FBWjtBQUNBLFVBQUk3QixJQUFJLEdBQUdpRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0ssTUFBTSxDQUFDQyxPQUFQLENBQWUseUJBQWYsQ0FBWCxDQUFYOztBQUNBLFdBQUssSUFBSWQsQ0FBQyxHQUFFLENBQVosRUFBZUEsQ0FBQyxHQUFHMUQsSUFBSSxDQUFDLGFBQUQsQ0FBSixDQUFvQjJELE1BQXZDLEVBQStDRCxDQUFDLEVBQWhELEVBQW1EO0FBQy9DZSxrQkFBVSxHQUFHekUsSUFBSSxDQUFDLGFBQUQsQ0FBSixDQUFvQjBELENBQXBCLEVBQXVCLFlBQXZCLENBQWI7QUFDQXBILG1CQUFXLENBQUNvSSxNQUFaLENBQW1CRCxVQUFuQjtBQUNIOztBQUFBO0FBQ0osS0EvRGdCLENBaUVqQjs7O0FBQ0EsUUFBR2pJLE9BQU8sQ0FBQzBHLElBQVIsR0FBZW9CLEtBQWYsT0FBMkIsQ0FBOUIsRUFBZ0M7QUFDNUIxQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWjtBQUNBLFVBQUk3QixJQUFJLEdBQUdpRSxJQUFJLENBQUNDLEtBQUwsQ0FBV0ssTUFBTSxDQUFDQyxPQUFQLENBQWUscUJBQWYsQ0FBWCxDQUFYOztBQUNBLFdBQUssSUFBSWQsQ0FBQyxHQUFFLENBQVosRUFBZUEsQ0FBQyxHQUFHMUQsSUFBSSxDQUFDLFNBQUQsQ0FBSixDQUFnQjJELE1BQW5DLEVBQTJDRCxDQUFDLEVBQTVDLEVBQStDO0FBQzNDaUIsaUJBQVMsR0FBRzNFLElBQUksQ0FBQyxTQUFELENBQUosQ0FBZ0IwRCxDQUFoQixFQUFtQixRQUFuQixDQUFaO0FBQ0FsSCxlQUFPLENBQUNrSSxNQUFSLENBQWVDLFNBQWY7QUFDSDs7QUFBQTtBQUNKLEtBekVnQixDQTJFakI7OztBQUNBLFNBQUksSUFBSWpHLElBQVIsSUFBZ0JTLFVBQWhCLEVBQTJCO0FBQ3ZCLFVBQUcsQ0FBQ2hELE1BQU0sQ0FBQ3lJLEtBQVAsQ0FBYXpDLE9BQWIsQ0FBcUI7QUFBRSxlQUFRekQ7QUFBVixPQUFyQixDQUFKLEVBQTJDO0FBQ3ZDVixhQUFLLENBQUM2RyxVQUFOLENBQWlCbkcsSUFBakI7QUFDSDtBQUNKOztBQUNELFFBQUlvRyxRQUFKLENBakZpQixDQWtGakI7O0FBQ0EsU0FBSSxJQUFJN0MsSUFBUixJQUFnQi9DLFVBQWhCLEVBQTJCO0FBQ3ZCLFVBQUksQ0FBQ25CLFFBQVEsQ0FBQ2dILGtCQUFULENBQTRCOUMsSUFBSSxDQUFDOUQsUUFBakMsQ0FBTCxFQUFpRDtBQUM3QyxjQUFNNkcsR0FBRyxHQUFHakgsUUFBUSxDQUFDa0gsVUFBVCxDQUFvQjtBQUM1QjlHLGtCQUFRLEVBQUU4RCxJQUFJLENBQUM5RCxRQURhO0FBRTVCQyxrQkFBUSxFQUFFNkQsSUFBSSxDQUFDN0QsUUFGYTtBQUc1QkMsZUFBSyxFQUFFNEQsSUFBSSxDQUFDNUQ7QUFIZ0IsU0FBcEIsQ0FBWjtBQU1BNkcsc0JBQWMsQ0FBQ0YsR0FBRCxFQUFNL0MsSUFBSSxDQUFDdkQsSUFBWCxDQUFkOztBQUNBLFlBQUd1RCxJQUFJLENBQUN2RCxJQUFMLElBQWEsT0FBaEIsRUFBd0I7QUFDcEJ0QyxjQUFJLENBQUNzSSxNQUFMLENBQVk7QUFDUlMsbUJBQU8sRUFBRSxLQUREO0FBRVJwQyxzQkFBVSxFQUFFaUMsR0FGSjtBQUdSSSxtQkFBTyxFQUFFLFNBSEQ7QUFJUkMsOEJBQWtCLEVBQUU7QUFKWixXQUFaO0FBTUFQLGtCQUFRLEdBQUcxSSxJQUFJLENBQUMrRixPQUFMLENBQWE7QUFBQ1ksc0JBQVUsRUFBRWlDO0FBQWIsV0FBYixFQUFnQ2hDLEdBQTNDO0FBQ0EsZ0JBQU1zQyxDQUFDLEdBQUcsSUFBSS9DLElBQUosRUFBVjtBQUNBLGNBQUlnRCxLQUFLLEdBQUdELENBQUMsQ0FBQ0UsUUFBRixFQUFaO0FBQ0EsY0FBSUMsR0FBRyxHQUFHSCxDQUFDLENBQUMzQyxPQUFGLEVBQVY7QUFDQSxjQUFJK0MsSUFBSSxHQUFHSixDQUFDLENBQUNLLFdBQUYsRUFBWDtBQUNBLGNBQUlDLEtBQUssR0FBRyxZQUFaO0FBQ0FsSixnQkFBTSxDQUFDZ0ksTUFBUCxDQUFjO0FBQ1ZtQixnQkFBSSxFQUFFLEtBREk7QUFFVnJILGVBQUcsRUFBRXNHLFFBRks7QUFHVlMsaUJBQUssRUFBRUEsS0FIRztBQUlWRSxlQUFHLEVBQUVBLEdBSks7QUFLVkMsZ0JBQUksRUFBRUEsSUFMSTtBQU1WRSxpQkFBSyxFQUFFQSxLQU5HO0FBT1ZFLHFCQUFTLEVBQUVkO0FBUEQsV0FBZDtBQVNBN0ksZ0JBQU0sQ0FBQzRKLElBQVAsQ0FBWSxnQkFBWixFQUE2QmYsR0FBN0I7QUFDSDs7QUFFRCxZQUFJdkcsWUFBWSxHQUFHLEVBQW5COztBQUNBLFlBQUd3RCxJQUFJLENBQUM5RCxRQUFMLElBQWlCLFVBQXBCLEVBQStCO0FBQzNCTSxzQkFBWSxHQUFJVixRQUFRLENBQUNnSCxrQkFBVCxDQUE0QmpHLGVBQWUsQ0FBQ1gsUUFBNUMsRUFBc0Q2RSxHQUF0RTtBQUNIOztBQUNEN0csY0FBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQjtBQUFFaEQsYUFBRyxFQUFFZ0M7QUFBUCxTQUFwQixFQUNJO0FBQUlpQixjQUFJLEVBQ0o7QUFDSWpKLGVBQUcsRUFBRWlGLElBQUksQ0FBQ2pGLEdBRGQ7QUFFSW9HLHFCQUFTLEVBQUVuQixJQUFJLENBQUMzRCxTQUZwQjtBQUdJK0Usb0JBQVEsRUFBRXBCLElBQUksQ0FBQzFELFFBSG5CO0FBSUkySCxzQkFBVSxFQUFFekgsWUFKaEI7QUFLSXFFLHdCQUFZLEVBQUViLElBQUksQ0FBQ3pELEdBQUwsR0FBV3lELElBQUksQ0FBQ3pELEdBQWhCLEdBQXFCc0csUUFMdkM7QUFNSTlILGVBQUcsRUFBRWlGLElBQUksQ0FBQ2pGLEdBTmQ7QUFPSTRCLG9CQUFRLEVBQUVxRCxJQUFJLENBQUNyRCxRQVBuQjtBQVFJSSx1Q0FBMkIsRUFBRWlELElBQUksQ0FBQ2pELDJCQVJ0QztBQVNJSCxzQkFBVSxFQUFFO0FBVGhCO0FBREosU0FESjtBQWVIO0FBQ0o7QUFDSixHQTFJRCxFLENBNElBOztBQUNBMUMsUUFBTSxDQUFDZ0ssT0FBUCxDQUFlO0FBQ1hDLGlCQURXO0FBRVhDLGlCQUFhLEVBQUUsVUFBU3BFLElBQVQsRUFBZXFFLElBQWYsRUFBcUJDLFNBQXJCLEVBQWdDakksU0FBaEMsRUFBMkNDLFFBQTNDLEVBQXFEdkIsR0FBckQsRUFBMER3SixNQUExRCxFQUE0RTtBQUFBLFVBQVZDLE1BQVUsdUVBQUgsRUFBRzs7QUFDdkYsVUFBR0EsTUFBSCxFQUFVO0FBQ04sWUFBSTtBQUFDQyxxQkFBRDtBQUFjQyx1QkFBZDtBQUE2QkMsNEJBQTdCO0FBQWlEQztBQUFqRCxZQUF5RVQsYUFBYSxDQUFDSyxNQUFELENBQTFGO0FBQ0EsWUFBSTNELFlBQVksR0FBRzFHLElBQUksQ0FBQytGLE9BQUwsQ0FBYTtBQUFDYSxhQUFHLEVBQUUwRDtBQUFOLFNBQWIsQ0FBbkI7QUFDSCxPQUhELE1BR087QUFDSCxZQUFJQSxXQUFXLEdBQUcsSUFBbEI7QUFDQSxZQUFJRSxrQkFBa0IsR0FBRyxJQUF6QjtBQUNBLFlBQUk5RCxZQUFZLEdBQUc7QUFBQ3VDLDRCQUFrQixFQUFFO0FBQXJCLFNBQW5CO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDdEgsUUFBUSxDQUFDZ0gsa0JBQVQsQ0FBNEI5QyxJQUE1QixDQUFMLEVBQXdDO0FBQ3BDLFlBQUksQ0FBQ2xFLFFBQVEsQ0FBQytJLGVBQVQsQ0FBeUJQLFNBQXpCLENBQUwsRUFBeUM7QUFDckMsZ0JBQU12QixHQUFHLEdBQUdqSCxRQUFRLENBQUNrSCxVQUFULENBQW9CO0FBQzVCOUcsb0JBQVEsRUFBRThELElBRGtCO0FBRTVCN0Qsb0JBQVEsRUFBRWtJLElBRmtCO0FBRzVCakksaUJBQUssRUFBRWtJO0FBSHFCLFdBQXBCLENBQVo7QUFLQXBLLGdCQUFNLENBQUMrRixLQUFQLENBQWE4RCxNQUFiLENBQW9CO0FBQUVoRCxlQUFHLEVBQUVnQztBQUFQLFdBQXBCLEVBQ0k7QUFBSWlCLGdCQUFJLEVBQ0o7QUFDSWpKLGlCQUFHLEVBQUVBLEdBRFQ7QUFFSW9HLHVCQUFTLEVBQUU5RSxTQUZmO0FBR0krRSxzQkFBUSxFQUFFOUUsUUFIZDtBQUlJdUUsMEJBQVksRUFBRTRELFdBSmxCO0FBS0lSLHdCQUFVLEVBQUVVLGtCQUxoQjtBQU1Jakksa0NBQW9CLEVBQUUsSUFOMUI7QUFPSUsseUNBQTJCLEVBQUUsS0FQakM7QUFRSXdILG9CQUFNLEVBQUVBLE1BUlo7QUFTSTVILHNCQUFRLEVBQUVrRSxZQUFZLENBQUN1QyxrQkFBYixJQUFtQyxFQVRqRDtBQVVJeEcsd0JBQVUsRUFBRTtBQVZoQjtBQURKLFdBREo7O0FBZUEsY0FBRzRILE1BQU0sSUFBSSxFQUFiLEVBQWdCO0FBQ1p2QiwwQkFBYyxDQUFDRixHQUFELEVBQU0sTUFBTixDQUFkO0FBQ0gsV0FGRCxNQUVPO0FBQ0hFLDBCQUFjLENBQUNGLEdBQUQsRUFBTSxPQUFOLENBQWQ7QUFDSDtBQUNKLFNBMUJELE1BMkJJO0FBQ0EsZ0JBQU0sSUFBSTdJLE1BQU0sQ0FBQzRLLEtBQVgsQ0FBa0IscUJBQWxCLGtCQUFrRFIsU0FBbEQscUJBQU47QUFDSDtBQUNKLE9BL0JELE1BZ0NJO0FBQ0EsY0FBTSxJQUFJcEssTUFBTSxDQUFDNEssS0FBWCxDQUFrQixxQkFBbEIsaUJBQWlEOUUsSUFBakQscUJBQU47QUFDSDtBQUNKLEtBOUNVO0FBK0NYK0Usc0JBQWtCLEVBQUUsVUFBU0MsVUFBVCxFQUFxQkMsV0FBckIsRUFBa0NDLFVBQWxDLEVBQTZDO0FBQzdEQyxvQkFBYyxHQUFHOUssV0FBVyxDQUFDNEcsSUFBWixHQUFtQk0sS0FBbkIsRUFBakI7QUFDQTZCLHdCQUFrQixHQUFHLEVBQXJCOztBQUNBLFdBQUkzQixDQUFDLEdBQUMsQ0FBTixFQUFTQSxDQUFDLEdBQUMwRCxjQUFjLENBQUN6RCxNQUExQixFQUFrQ0QsQ0FBQyxFQUFuQyxFQUFzQztBQUNsQzJCLDBCQUFrQixDQUFDaEIsSUFBbkIsQ0FBd0IrQyxjQUFjLENBQUMxRCxDQUFELENBQWQsQ0FBa0JWLEdBQTFDO0FBQ0g7O0FBQ0Q1RyxVQUFJLENBQUNzSSxNQUFMLENBQVk7QUFDUlMsZUFBTyxFQUFFOEIsVUFERDtBQUVSbEUsa0JBQVUsRUFBRW1FLFdBRko7QUFHUjlCLGVBQU8sRUFBRStCLFVBSEQ7QUFJUjlCLDBCQUFrQixFQUFFQTtBQUpaLE9BQVo7QUFNQVAsY0FBUSxHQUFHMUksSUFBSSxDQUFDK0YsT0FBTCxDQUFhO0FBQUNZLGtCQUFVLEVBQUVtRTtBQUFiLE9BQWIsRUFBd0NsRSxHQUFuRDtBQUNBN0csWUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQjtBQUFFaEQsV0FBRyxFQUFFa0U7QUFBUCxPQUFwQixFQUNJO0FBQUlqQixZQUFJLEVBQ0o7QUFDSW5ELHNCQUFZLEVBQUVnQztBQURsQjtBQURKLE9BREo7QUFNQSxhQUFPLElBQVA7QUFDSCxLQW5FVTtBQW9FWHVDLGtCQUFjLEVBQUUsVUFBU0MsWUFBVCxFQUFzQjtBQUNsQyxVQUFJckwsSUFBSSxHQUFHLEVBQVg7QUFDQSxVQUFJMEgsTUFBTSxHQUFHLEVBQWI7QUFDQSxVQUFJNEQsVUFBVSxHQUFTLGdFQUF2QjtBQUNBLFVBQUlDLGdCQUFnQixHQUFHRCxVQUFVLENBQUM1RCxNQUFsQztBQUNBLFVBQUk4RCxNQUFNLEdBQUcsS0FBYjs7QUFDQSxhQUFNQSxNQUFNLElBQUksS0FBaEIsRUFBc0I7QUFBQzs7QUFDbkIsYUFBTSxJQUFJL0QsQ0FBQyxHQUFHLENBQWQsRUFBaUJBLENBQUMsR0FBR0MsTUFBckIsRUFBNkJELENBQUMsRUFBOUIsRUFBbUM7QUFDL0J6SCxjQUFJLElBQUlzTCxVQUFVLENBQUNHLE1BQVgsQ0FBa0JuSyxJQUFJLENBQUNDLEtBQUwsQ0FBV0QsSUFBSSxDQUFDb0ssTUFBTCxLQUFnQkgsZ0JBQTNCLENBQWxCLENBQVI7QUFDSDs7QUFDREksaUJBQVMsR0FBR3pMLE1BQU0sQ0FBQytGLEtBQVAsQ0FBYWdCLElBQWIsQ0FBa0I7QUFBQ3ZFLDhCQUFvQixFQUFFMUM7QUFBdkIsU0FBbEIsRUFBZ0R1SCxLQUFoRCxHQUF3REcsTUFBcEU7O0FBQ0EsWUFBR2lFLFNBQVMsSUFBSSxDQUFoQixFQUFrQjtBQUNkSCxnQkFBTSxHQUFHLElBQVQ7QUFDSCxTQUZELE1BRU87QUFDSHhMLGNBQUksR0FBRyxFQUFQO0FBQ0g7QUFDSjs7QUFDREUsWUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQjtBQUFFaEQsV0FBRyxFQUFFc0U7QUFBUCxPQUFwQixFQUNBO0FBQUlyQixZQUFJLEVBQ0o7QUFDSXRILDhCQUFvQixFQUFFMUM7QUFEMUI7QUFESixPQURBO0FBTUEsYUFBT0EsSUFBUDtBQUNILEtBNUZVO0FBNkZYNEwsZUFBVyxFQUFFLFVBQVNDLE1BQVQsRUFBaUI7QUFDMUIsVUFBRzlKLEtBQUssQ0FBQytKLFlBQU4sQ0FBbUIsS0FBS2xFLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxDQUFoQyxDQUFILEVBQThDO0FBQzFDMUgsY0FBTSxDQUFDK0YsS0FBUCxDQUFhOEYsTUFBYixDQUFvQkYsTUFBcEI7QUFDSDtBQUNKLEtBakdVO0FBa0dYRyxvQkFBZ0IsRUFBRSxVQUFTcEUsTUFBVCxFQUFnQjtBQUM5QjtBQUNBLFVBQUc3RixLQUFLLENBQUMrSixZQUFOLENBQW1CLEtBQUtsRSxNQUF4QixFQUFnQyxPQUFoQyxDQUFILEVBQTRDO0FBQ3hDcUIsc0JBQWMsQ0FBQ3JCLE1BQUQsRUFBUyxNQUFULENBQWQ7QUFDQXFFLDJCQUFtQixDQUFDckUsTUFBRCxFQUFTLFlBQVQsQ0FBbkI7QUFDSDtBQUNKLEtBeEdVO0FBeUdYc0Usa0JBQWMsRUFBRSxVQUFTMUosWUFBVCxFQUF1QjtBQUNuQyxVQUFHVCxLQUFLLENBQUMrSixZQUFOLENBQW1CLEtBQUtsRSxNQUF4QixFQUFnQyxDQUFDLE9BQUQsQ0FBaEMsQ0FBSCxFQUE4QyxDQUU3QztBQUNKLEtBN0dVO0FBOEdYdUUsaUJBQWEsRUFBRSxVQUFTdkUsTUFBVCxFQUFpQjtBQUM1QjtBQUNBLFVBQUc3RixLQUFLLENBQUMrSixZQUFOLENBQW1CLEtBQUtsRSxNQUF4QixFQUFnQyxPQUFoQyxDQUFILEVBQTRDO0FBQ3hDcUIsc0JBQWMsQ0FBQ3JCLE1BQUQsRUFBUyxZQUFULENBQWQ7QUFDQXFFLDJCQUFtQixDQUFDckUsTUFBRCxFQUFTLE1BQVQsQ0FBbkI7QUFDSDtBQUNKLEtBcEhVO0FBcUhYd0UsOEJBQTBCLEVBQUUsVUFBU0MsVUFBVCxFQUFvQjtBQUM1Q2xNLFVBQUksQ0FBQ21NLE1BQUwsQ0FBWTtBQUFDdkYsV0FBRyxFQUFFN0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYTtBQUFwQixPQUFaLEVBQThDO0FBQUNtRCxZQUFJLEVBQUU7QUFBQ1osNEJBQWtCLEVBQUVpRDtBQUFyQjtBQUFQLE9BQTlDO0FBQ0gsS0F2SFU7QUF3SFhFLG9CQUFnQixFQUFFLFVBQVNGLFVBQVQsRUFBb0I7QUFDbEM5SixTQUFHLEdBQUdyQyxNQUFNLENBQUM4RixJQUFQLEdBQWNhLFlBQXBCO0FBQ0EyRixjQUFRLEdBQUd0TSxNQUFNLENBQUMrRixLQUFQLENBQWFnQixJQUFiLENBQWtCO0FBQUNKLG9CQUFZLEVBQUV0RSxHQUFmO0FBQW9CRSxZQUFJLEVBQUU7QUFBMUIsT0FBbEIsRUFBcUQ4RSxLQUFyRCxFQUFYOztBQUNBLFdBQUlFLENBQUMsR0FBRyxDQUFSLEVBQVdBLENBQUMsR0FBRytFLFFBQVEsQ0FBQzlFLE1BQXhCLEVBQWdDRCxDQUFDLEVBQWpDLEVBQW9DO0FBQ2hDZ0Ysc0JBQWMsR0FBR0QsUUFBUSxDQUFDL0UsQ0FBRCxDQUFSLENBQVk5RSxRQUE3Qjs7QUFDQSxZQUFHLENBQUM4SixjQUFjLENBQUNDLFFBQWYsQ0FBd0JMLFVBQXhCLENBQUosRUFBd0M7QUFDcENJLHdCQUFjLENBQUNyRSxJQUFmLENBQW9CaUUsVUFBcEI7QUFDSDs7QUFDRG5NLGNBQU0sQ0FBQytGLEtBQVAsQ0FBYXFHLE1BQWIsQ0FBb0I7QUFBQ3ZGLGFBQUcsRUFBRXlGLFFBQVEsQ0FBQy9FLENBQUQsQ0FBUixDQUFZVjtBQUFsQixTQUFwQixFQUE0QztBQUFDaUQsY0FBSSxFQUFFO0FBQUNySCxvQkFBUSxFQUFFOEo7QUFBWDtBQUFQLFNBQTVDO0FBQ0g7QUFDSixLQWxJVTtBQW1JWEUsMkJBQXVCLEVBQUUsVUFBU0MsS0FBVCxFQUFlO0FBQ3BDaEYsWUFBTSxHQUFHZ0YsS0FBSyxDQUFDLENBQUQsQ0FBZDtBQUNBUCxnQkFBVSxHQUFHTyxLQUFLLENBQUMsQ0FBRCxDQUFsQjtBQUNBMU0sWUFBTSxDQUFDK0YsS0FBUCxDQUFhcUcsTUFBYixDQUFvQjtBQUFDdkYsV0FBRyxFQUFFYTtBQUFOLE9BQXBCLEVBQWtDO0FBQUNvQyxZQUFJLEVBQUU7QUFBQ3JILGtCQUFRLEVBQUUwSjtBQUFYO0FBQVAsT0FBbEM7QUFDSCxLQXZJVTtBQXlJWDtBQUNBUSxzQkFBa0IsRUFBRSxVQUFTQyxPQUFULEVBQWlCO0FBQ2pDQyxhQUFPLEdBQUdELE9BQU8sQ0FBQ0MsT0FBbEI7QUFDQUMsa0JBQVksR0FBR0YsT0FBTyxDQUFDRSxZQUF2QjtBQUNBQyxvQkFBYyxHQUFHSCxPQUFPLENBQUNHLGNBQXpCO0FBQ0FyRixZQUFNLEdBQUcxSCxNQUFNLENBQUMwSCxNQUFQLEVBQVQ7QUFDQXNGLGdCQUFVLEdBQUdKLE9BQU8sQ0FBQ0ksVUFBckI7QUFDQUMsZ0JBQVUsR0FBRzdNLE1BQU0sQ0FBQzRGLE9BQVAsQ0FBZTtBQUFDYSxXQUFHLEVBQUVnRztBQUFOLE9BQWYsQ0FBYjtBQUNBLFVBQUlLLFVBQUo7O0FBRUEsVUFBRyxPQUFPRCxVQUFQLEtBQXNCLFdBQXpCLEVBQXFDO0FBQ2pDcEosWUFBSSxHQUFHLEVBQVA7QUFDQXNKLHNCQUFjLEdBQUcsRUFBakI7QUFDQUQsa0JBQVUsR0FBR04sT0FBTyxDQUFDTSxVQUFyQjtBQUNILE9BSkQsTUFJTztBQUNIckosWUFBSSxHQUFHb0osVUFBVSxDQUFDcEosSUFBbEI7QUFDQXNKLHNCQUFjLEdBQUdGLFVBQVUsQ0FBQ0UsY0FBNUI7QUFDQUQsa0JBQVUsR0FBR0QsVUFBVSxDQUFDQyxVQUF4QjtBQUNIOztBQUNEckosVUFBSSxDQUFDK0ksT0FBTyxDQUFDSSxVQUFULENBQUosR0FBMkI7QUFDdkJ6SCxnQkFBUSxFQUFFcUgsT0FBTyxDQUFDckgsUUFESztBQUV2QjZILHFCQUFhLEVBQUVSLE9BQU8sQ0FBQ1EsYUFGQTtBQUd2QjdMLGlCQUFTLEVBQUVxTCxPQUFPLENBQUNyTDtBQUhJLE9BQTNCLENBbEJpQyxDQXVCakM7O0FBQ0EsVUFBRyxDQUFDcUwsT0FBTyxDQUFDckwsU0FBWixFQUFzQjtBQUNsQjtBQUNBLFlBQUc0TCxjQUFjLENBQUMsU0FBRCxDQUFqQixFQUE2QjtBQUN6QkEsd0JBQWMsQ0FBQyxTQUFELENBQWQsSUFBNkJQLE9BQU8sQ0FBQ1EsYUFBckM7QUFDSCxTQUZELE1BR0k7QUFDQUQsd0JBQWMsQ0FBQyxTQUFELENBQWQsR0FBNEJQLE9BQU8sQ0FBQ1EsYUFBcEM7QUFDSDtBQUNKOztBQUNELFdBQUksSUFBSXJNLFFBQVIsSUFBb0I2TCxPQUFPLENBQUNyTCxTQUE1QixFQUFzQztBQUNsQyxZQUFHNEwsY0FBYyxDQUFDcE0sUUFBRCxDQUFqQixFQUE0QjtBQUN4Qm9NLHdCQUFjLENBQUNwTSxRQUFELENBQWQsSUFBNEI2TCxPQUFPLENBQUNRLGFBQXBDO0FBQ0gsU0FGRCxNQUdJO0FBQ0FELHdCQUFjLENBQUNwTSxRQUFELENBQWQsR0FBMkI2TCxPQUFPLENBQUNRLGFBQW5DO0FBQ0g7QUFDSjs7QUFDRCxVQUFJQyxNQUFNLEdBQUdqTixNQUFNLENBQUNnTSxNQUFQLENBQWM7QUFBQ3ZGLFdBQUcsRUFBRWdHO0FBQU4sT0FBZCxFQUE4QjtBQUFDL0MsWUFBSSxFQUFFO0FBQUNwQyxnQkFBTSxFQUFFQSxNQUFUO0FBQWlCb0Ysc0JBQVksRUFBRUEsWUFBL0I7QUFBNkNDLHdCQUFjLEVBQUVBLGNBQTdEO0FBQTZFTyxzQkFBWSxFQUFFLElBQUlsSCxJQUFKLEVBQTNGO0FBQXVHOEcsb0JBQVUsRUFBRUEsVUFBbkg7QUFBK0hySixjQUFJLEVBQUVBLElBQXJJO0FBQTJJc0osd0JBQWMsRUFBRUE7QUFBM0o7QUFBUCxPQUE5QixDQUFiOztBQUVBLFVBQUcsT0FBT0UsTUFBTSxDQUFDRSxVQUFkLEtBQTZCLFdBQWhDLEVBQTRDO0FBQ3hDdk4sY0FBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQm5DLE1BQXBCLEVBQTRCO0FBQ3hCb0MsY0FBSSxFQUFFO0FBQ0owRCxvQkFBUSxFQUFFO0FBQ05YLHFCQUFPLEVBQUVBLE9BREg7QUFFTkcsd0JBQVUsRUFBRUEsVUFBVSxHQUFHO0FBRm5CO0FBRE47QUFEa0IsU0FBNUI7QUFRQSxlQUFPSCxPQUFQO0FBQ0gsT0FWRCxNQVVPO0FBQ0g3TSxjQUFNLENBQUMrRixLQUFQLENBQWE4RCxNQUFiLENBQW9CbkMsTUFBcEIsRUFBNEI7QUFDeEJvQyxjQUFJLEVBQUU7QUFDRjBELG9CQUFRLEVBQUU7QUFDTlgscUJBQU8sRUFBRVEsTUFBTSxDQUFDRSxVQURWO0FBRU5QLHdCQUFVLEVBQUU7QUFGTjtBQURSO0FBRGtCLFNBQTVCO0FBUUEsZUFBT0ssTUFBTSxDQUFDRSxVQUFkO0FBQ0g7QUFDSixLQTFNVTtBQTJNWEUsaUJBQWEsRUFBRSxVQUFTWixPQUFULEVBQWtCO0FBQzdCLFVBQUlhLEtBQUssR0FBR3ROLE1BQU0sQ0FBQzRGLE9BQVAsQ0FBZTtBQUFDLGVBQU82RztBQUFSLE9BQWYsQ0FBWjtBQUNBLFlBQU1jLGNBQWMsR0FBR2xOLGVBQWUsQ0FBQ2lOLEtBQUssQ0FBQ1IsVUFBUCxFQUFtQlEsS0FBSyxDQUFDUCxjQUF6QixFQUF5Q25OLE1BQU0sQ0FBQzhGLElBQVAsR0FBY2pGLEdBQXZELENBQXRDO0FBQ0EsVUFBRzhNLGNBQUgsRUFDSXZOLE1BQU0sQ0FBQ2dNLE1BQVAsQ0FBYztBQUFDdkYsV0FBRyxFQUFFZ0c7QUFBTixPQUFkLEVBQThCO0FBQUMvQyxZQUFJLEVBQUU7QUFBQ3FELHdCQUFjLEVBQUVRO0FBQWpCO0FBQVAsT0FBOUI7QUFDUCxLQWhOVTtBQWlOWEMsMkJBQXVCLEVBQUUsWUFBVztBQUNoQ2xHLFlBQU0sR0FBRzFILE1BQU0sQ0FBQzBILE1BQVAsRUFBVDtBQUVBMUgsWUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQm5DLE1BQXBCLEVBQTRCO0FBQ3hCb0MsWUFBSSxFQUFFO0FBQ0owRCxrQkFBUSxFQUFFO0FBQ05YLG1CQUFPLEVBQUUsQ0FESDtBQUVORyxzQkFBVSxFQUFFO0FBRk47QUFETjtBQURrQixPQUE1QjtBQVFILEtBNU5VO0FBNk5YYSx3QkFBb0IsRUFBRSxVQUFTaEssSUFBVCxFQUFjO0FBQ2hDLFlBQU1pSyxPQUFPLEdBQUd4TixhQUFhLENBQUNpSSxNQUFkLENBQXFCMUUsSUFBckIsQ0FBaEI7QUFDSTdELFlBQU0sQ0FBQytGLEtBQVAsQ0FBYThELE1BQWIsQ0FBb0I3SixNQUFNLENBQUMwSCxNQUFQLEVBQXBCLEVBQXFDO0FBQ2pDb0MsWUFBSSxFQUFFO0FBQ05pRSxtQkFBUyxFQUFFO0FBQ1BDLG9CQUFRLEVBQUVGLE9BREg7QUFFUEcsa0JBQU0sRUFBRSxDQUZEO0FBR1BqQixzQkFBVSxFQUFFO0FBSEw7QUFETDtBQUQyQixPQUFyQztBQVNKLGFBQU9jLE9BQVA7QUFDSCxLQXpPVTtBQTBPWEksa0JBQWMsRUFBRSxVQUFVQyxVQUFWLEVBQXFCO0FBQ2pDN04sbUJBQWEsQ0FBQzhMLE1BQWQsQ0FBcUI7QUFBQ3ZGLFdBQUcsRUFBRXNILFVBQVUsQ0FBQ3RIO0FBQWpCLE9BQXJCLEVBQTRDO0FBQUNpRCxZQUFJLEVBQUVxRTtBQUFQLE9BQTVDO0FBQ0F6TCxnQkFBVSxHQUFHMUMsTUFBTSxDQUFDK0YsS0FBUCxDQUFhQyxPQUFiLENBQXFCO0FBQUNhLFdBQUcsRUFBRTdHLE1BQU0sQ0FBQzBILE1BQVA7QUFBTixPQUFyQixFQUE2Q2hGLFVBQTFEOztBQUNBLFVBQUd5TCxVQUFVLENBQUNGLE1BQVgsSUFBcUIsV0FBeEIsRUFBb0M7QUFDaEN2TCxrQkFBVTtBQUNiOztBQUNEMUMsWUFBTSxDQUFDK0YsS0FBUCxDQUFhcUcsTUFBYixDQUFvQnBNLE1BQU0sQ0FBQzBILE1BQVAsRUFBcEIsRUFBcUM7QUFDakNvQyxZQUFJLEVBQUU7QUFDTmlFLG1CQUFTLEVBQUU7QUFDUEMsb0JBQVEsRUFBRWhPLE1BQU0sQ0FBQzhGLElBQVAsR0FBY2lJLFNBQWQsQ0FBd0JDLFFBRDNCO0FBRVBDLGtCQUFNLEVBQUVFLFVBQVUsQ0FBQ0MsUUFGWjtBQUdQcEIsc0JBQVUsRUFBRW1CLFVBQVUsQ0FBQ0U7QUFIaEIsV0FETDtBQU1OM0wsb0JBQVUsRUFBRUE7QUFOTjtBQUQyQixPQUFyQztBQVVQLEtBMVBjO0FBMlBYNEwsbUJBQWUsRUFBRSxVQUFTQyxRQUFULEVBQWtCO0FBQy9CQyxZQUFNLEdBQUlwRyxNQUFNLENBQUNxRyxnQkFBUCxDQUF3QkYsUUFBeEIsQ0FBVjtBQUNBLGFBQU9DLE1BQVA7QUFDSCxLQTlQVTtBQStQWEUsb0JBQWdCLEVBQUUsVUFBU2hILE1BQVQsRUFBZ0I7QUFDOUIsVUFBSWlILFFBQVEsR0FBRyxFQUFmO0FBQ0EsVUFBSXZELFVBQVUsR0FBRyxnRUFBakI7QUFDQSxVQUFJQyxnQkFBZ0IsR0FBR0QsVUFBVSxDQUFDNUQsTUFBbEM7O0FBQ0EsV0FBTSxJQUFJRCxDQUFDLEdBQUcsQ0FBZCxFQUFpQkEsQ0FBQyxHQUFHLEVBQXJCLEVBQXlCQSxDQUFDLEVBQTFCLEVBQStCO0FBQzNCb0gsZ0JBQVEsSUFBSXZELFVBQVUsQ0FBQ0csTUFBWCxDQUFrQm5LLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNvSyxNQUFMLEtBQWdCSCxnQkFBM0IsQ0FBbEIsQ0FBWjtBQUNIOztBQUNELFVBQUl1RCxNQUFNLEdBQUcsSUFBSXhJLElBQUosRUFBYjtBQUNBd0ksWUFBTSxDQUFDckksT0FBUCxDQUFlcUksTUFBTSxDQUFDcEksT0FBUCxLQUFtQixFQUFsQztBQUNBeEcsWUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQm5DLE1BQXBCLEVBQTRCO0FBQ3hCb0MsWUFBSSxFQUFFO0FBQ0o1RCxhQUFHLEVBQUU7QUFDRE8saUJBQUssRUFBRWtJLFFBRE47QUFFRHJJLG1CQUFPLEVBQUVzSTtBQUZSO0FBREQ7QUFEa0IsT0FBNUI7QUFRSCxLQWhSVTtBQWlSWEMsZ0JBQVksRUFBRSxZQUFVO0FBQ3BCOUksV0FBSyxHQUFHL0YsTUFBTSxDQUFDK0YsS0FBUCxDQUFhZ0IsSUFBYixDQUFrQjtBQUFDSixvQkFBWSxFQUFFM0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYTtBQUE3QixPQUFsQixFQUE4RFUsS0FBOUQsRUFBUjtBQUNBOUYsZUFBUyxHQUFHLEVBQVo7QUFDQXVOLGtCQUFZLEdBQUcsRUFBZjtBQUNBakwsVUFBSSxHQUFHLEVBQVA7QUFDQUEsVUFBSSxDQUFDa0wsU0FBTCxHQUFpQmhKLEtBQUssQ0FBQ3lCLE1BQXZCO0FBQ0EzRCxVQUFJLENBQUNtTCxlQUFMLEdBQXVCLENBQXZCO0FBQ0FuTCxVQUFJLENBQUNvTCxXQUFMLEdBQW1CLENBQW5CO0FBQ0FDLGtCQUFZLEdBQUcsRUFBZjs7QUFDQSxXQUFJM0gsQ0FBQyxHQUFHLENBQVIsRUFBV0EsQ0FBQyxHQUFHeEIsS0FBSyxDQUFDeUIsTUFBckIsRUFBNkJELENBQUMsRUFBOUIsRUFBaUM7QUFDN0JNLGNBQU0sR0FBR3pILE1BQU0sQ0FBQzJHLElBQVAsQ0FBWTtBQUFDLG9CQUFVaEIsS0FBSyxDQUFDd0IsQ0FBRCxDQUFMLENBQVNWO0FBQXBCLFNBQVosRUFBc0NRLEtBQXRDLEVBQVQ7O0FBQ0EsYUFBSThILENBQUMsR0FBRyxDQUFSLEVBQVdBLENBQUMsR0FBR3RILE1BQU0sQ0FBQ0wsTUFBdEIsRUFBOEIySCxDQUFDLEVBQS9CLEVBQWtDO0FBQzlCdEwsY0FBSSxDQUFDbUwsZUFBTDs7QUFDQSxlQUFJSSxDQUFDLEdBQUcsQ0FBUixFQUFXQSxDQUFDLEdBQUdwTyxNQUFNLENBQUNxTyxtQkFBUCxDQUEyQnhILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBckMsRUFBcUQzRixNQUFwRSxFQUE0RTRILENBQUMsRUFBN0UsRUFBZ0Y7QUFDNUVyTyxvQkFBUSxHQUFHQyxNQUFNLENBQUNxTyxtQkFBUCxDQUEyQnhILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBckMsRUFBcURpQyxDQUFyRCxDQUFYO0FBQ0FFLHlCQUFhLEdBQUdSLFlBQVksQ0FBQ1MsT0FBYixDQUFxQnhPLFFBQXJCLENBQWhCOztBQUNBLGdCQUFHdU8sYUFBYSxLQUFLLENBQUMsQ0FBdEIsRUFBd0I7QUFDcEJSLDBCQUFZLENBQUM1RyxJQUFiLENBQWtCbkgsUUFBbEI7QUFDQXVPLDJCQUFhLEdBQUdSLFlBQVksQ0FBQ1MsT0FBYixDQUFxQnhPLFFBQXJCLENBQWhCO0FBQ0FtTywwQkFBWSxDQUFDSSxhQUFELENBQVosR0FBOEI7QUFDMUJFLG9CQUFJLEVBQUV6TyxRQURvQjtBQUUxQjBPLG1CQUFHLEVBQUUsQ0FBQzVILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCLENBQUQsQ0FGcUI7QUFHMUJvSCxxQkFBSyxFQUFFLENBSG1CO0FBSTFCdUgsbUJBQUcsRUFBRTdILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCLENBSnFCO0FBSzFCNE8sbUJBQUcsRUFBRzlILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCLENBTG9CO0FBTTFCNk8sc0JBQU0sRUFBRS9ILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCO0FBTmtCLGVBQTlCO0FBUUgsYUFYRCxNQVdPO0FBQ0htTywwQkFBWSxDQUFDSSxhQUFELENBQVosQ0FBNEJHLEdBQTVCLENBQWdDdkgsSUFBaEMsQ0FBcUNMLE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCLENBQXJDO0FBQ0FtTywwQkFBWSxDQUFDSSxhQUFELENBQVosQ0FBNEJuSCxLQUE1QjtBQUNBK0csMEJBQVksQ0FBQ0ksYUFBRCxDQUFaLENBQTRCSSxHQUE1QixJQUFrQzdILE1BQU0sQ0FBQ3NILENBQUQsQ0FBTixDQUFVaEMsY0FBVixDQUF5QnBNLFFBQXpCLENBQWxDO0FBQ0FtTywwQkFBWSxDQUFDSSxhQUFELENBQVosQ0FBNEJLLEdBQTVCLEdBQWtDVCxZQUFZLENBQUNJLGFBQUQsQ0FBWixDQUE0QkksR0FBNUIsR0FBa0NSLFlBQVksQ0FBQ0ksYUFBRCxDQUFaLENBQTRCbkgsS0FBaEc7QUFDQSxvQkFBTTBILE1BQU0sR0FBR1gsWUFBWSxDQUFDSSxhQUFELENBQVosQ0FBNEJHLEdBQTVCLENBQWdDSyxLQUFoQyxHQUF3Q0MsSUFBeEMsQ0FBNkMsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVELENBQUMsR0FBR0MsQ0FBM0QsQ0FBZjtBQUNBLG9CQUFNQyxNQUFNLEdBQUc5TyxJQUFJLENBQUNDLEtBQUwsQ0FBV3dPLE1BQU0sQ0FBQ3JJLE1BQVAsR0FBZ0IsQ0FBM0IsQ0FBZjs7QUFDQSxrQkFBSXFJLE1BQU0sQ0FBQ3JJLE1BQVAsR0FBZ0IsQ0FBaEIsS0FBc0IsQ0FBMUIsRUFBNkI7QUFDekJvSSxzQkFBTSxHQUFHLENBQUNDLE1BQU0sQ0FBQ0ssTUFBTSxHQUFHLENBQVYsQ0FBTixHQUFxQkwsTUFBTSxDQUFDSyxNQUFELENBQTVCLElBQXdDLENBQWpEO0FBQ0gsZUFGRCxNQUVPO0FBQ0hOLHNCQUFNLEdBQUdDLE1BQU0sQ0FBQ0ssTUFBRCxDQUFmO0FBQ0g7O0FBQ0RoQiwwQkFBWSxDQUFDSSxhQUFELENBQVosQ0FBNEJNLE1BQTVCLEdBQXFDQSxNQUFyQztBQUNIO0FBRUo7QUFDSjtBQUNKOztBQUNEL0wsVUFBSSxDQUFDcUwsWUFBTCxHQUFvQkEsWUFBcEI7QUFDQWpQLFVBQUksQ0FBQ21NLE1BQUwsQ0FBWTtBQUFDdkYsV0FBRyxFQUFFN0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYTtBQUFwQixPQUFaLEVBQThDO0FBQzFDbUQsWUFBSSxFQUFFO0FBQ0ZxRyxrQkFBUSxFQUFFdE07QUFEUjtBQURvQyxPQUE5QztBQUtILEtBcFVVO0FBcVVYdU0sZUFBVyxFQUFFLFVBQVMxRyxJQUFULEVBQWVOLEtBQWYsRUFBc0JFLEdBQXRCLEVBQTJCQyxJQUEzQixFQUFpQzhHLElBQWpDLEVBQXVDNUcsS0FBdkMsRUFBOEM2RyxVQUE5QyxFQUF5RDtBQUNsRS9QLFlBQU0sQ0FBQ2dJLE1BQVAsQ0FBYztBQUNWbUIsWUFBSSxFQUFFQSxJQURJO0FBRVZySCxXQUFHLEVBQUVyQyxNQUFNLENBQUM4RixJQUFQLEdBQWNhLFlBRlQ7QUFHVnlDLGFBQUssRUFBRUEsS0FIRztBQUlWRSxXQUFHLEVBQUVBLEdBSks7QUFLVkMsWUFBSSxFQUFFQSxJQUxJO0FBTVZFLGFBQUssRUFBRUEsS0FORztBQU9WNEcsWUFBSSxFQUFFQSxJQVBJO0FBUVZDLGtCQUFVLEVBQUVBLFVBUkY7QUFTVjNHLGlCQUFTLEVBQUUsS0FBS2pDO0FBVE4sT0FBZDtBQVdILEtBalZVO0FBa1ZYNkksZUFBVyxFQUFFLFVBQVNDLE9BQVQsRUFBaUI7QUFDMUJqUSxZQUFNLENBQUNzTCxNQUFQLENBQWM7QUFBQ2hGLFdBQUcsRUFBRTJKO0FBQU4sT0FBZDtBQUNIO0FBcFZVLEdBQWYsRSxDQXVWQTs7QUFDQSxXQUFTekgsY0FBVCxDQUF3QkYsR0FBeEIsRUFBNkJKLEtBQTdCLEVBQW1DO0FBQy9CNUcsU0FBSyxDQUFDNE8sZUFBTixDQUFzQjVILEdBQXRCLEVBQTJCSixLQUEzQjtBQUNBekksVUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQjtBQUFFaEQsU0FBRyxFQUFFZ0M7QUFBUCxLQUFwQixFQUFrQztBQUFFaUIsVUFBSSxFQUFFO0FBQUV2SCxZQUFJLEVBQUVWLEtBQUssQ0FBQzZPLGVBQU4sQ0FBc0I3SCxHQUF0QixFQUEyQixDQUEzQjtBQUFSO0FBQVIsS0FBbEM7QUFDSDs7QUFFRCxXQUFTa0QsbUJBQVQsQ0FBNkJsRCxHQUE3QixFQUFrQ0osS0FBbEMsRUFBd0M7QUFDcEM1RyxTQUFLLENBQUM4TyxvQkFBTixDQUEyQjlILEdBQTNCLEVBQWdDSixLQUFoQztBQUNBekksVUFBTSxDQUFDK0YsS0FBUCxDQUFhOEQsTUFBYixDQUFvQjtBQUFFaEQsU0FBRyxFQUFFZ0M7QUFBUCxLQUFwQixFQUFrQztBQUFFaUIsVUFBSSxFQUFFO0FBQUV2SCxZQUFJLEVBQUVWLEtBQUssQ0FBQzZPLGVBQU4sQ0FBc0I3SCxHQUF0QixFQUEyQixDQUEzQjtBQUFSO0FBQVIsS0FBbEM7QUFDSDs7QUFFRCxXQUFTK0gsYUFBVCxHQUFnQztBQUM1QixVQUFNQyxJQUFJLEdBQUcsQ0FBRSxJQUFJekssSUFBSixFQUFELENBQWEwSyxRQUFiLEVBQUQsQ0FBYjs7QUFDQSxTQUFLLElBQUl2SixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLFVBQUtDLE1BQXpCLEVBQWlDLEVBQUVELENBQW5DLEVBQXNDO0FBQ3BDc0osVUFBSSxDQUFDM0ksSUFBTCxDQUFlWCxDQUFmLDRCQUFlQSxDQUFmLHlCQUFlQSxDQUFmO0FBQ0QsS0FKMkIsQ0FLNUI7OztBQUNBOUIsV0FBTyxDQUFDQyxHQUFSLENBQVlxTCxLQUFaLENBQWtCLElBQWxCLEVBQXdCRixJQUF4QjtBQUNIOztBQUVELFdBQVM1RyxhQUFULENBQXVCK0csVUFBdkIsRUFBbUM7QUFDL0JqSCxjQUFVLEdBQUcvSixNQUFNLENBQUMrRixLQUFQLENBQWFDLE9BQWIsQ0FBcUI7QUFBQ3hELDBCQUFvQixFQUFFd087QUFBdkIsS0FBckIsQ0FBYjtBQUNBdkcsc0JBQWtCLEdBQUdWLFVBQVUsQ0FBQ2xELEdBQWhDO0FBQ0FGLGdCQUFZLEdBQUcxRyxJQUFJLENBQUMrRixPQUFMLENBQWE7QUFBQ2EsU0FBRyxFQUFFa0QsVUFBVSxDQUFDcEQ7QUFBakIsS0FBYixDQUFmO0FBQ0ErRCx3QkFBb0IsR0FBR1gsVUFBVSxDQUFDOUMsU0FBWCxHQUF1QixHQUF2QixHQUE2QjhDLFVBQVUsQ0FBQzdDLFFBQS9EO0FBQ0FxRCxlQUFXLEdBQUdSLFVBQVUsQ0FBQ3BELFlBQXpCO0FBQ0E2RCxpQkFBYSxHQUFHN0QsWUFBWSxDQUFDcUMsT0FBN0I7QUFDQXZELFdBQU8sQ0FBQ0MsR0FBUixDQUFZNkUsV0FBWixFQUF3QkMsYUFBeEIsRUFBc0NDLGtCQUF0QyxFQUF5REMsb0JBQXpEO0FBQ0EsV0FBTztBQUFDSCxpQkFBRDtBQUFjQyxtQkFBZDtBQUE2QkMsd0JBQTdCO0FBQWlEQztBQUFqRCxLQUFQO0FBQ0gsRyxDQUVEOzs7QUFDQTFLLFFBQU0sQ0FBQytGLEtBQVAsQ0FBYWtMLElBQWIsQ0FBa0I7QUFDZHBILFVBQU0sR0FBRztBQUFFLGFBQU8sSUFBUDtBQUFjOztBQURYLEdBQWxCO0FBSUE3SixRQUFNLENBQUMrRixLQUFQLENBQWFtTCxLQUFiLENBQW1CLEVBQW5CLEUsQ0FJQTs7QUFDQWxSLFFBQU0sQ0FBQ21SLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLFlBQVc7QUFDNUIsV0FBT25SLE1BQU0sQ0FBQytGLEtBQVAsQ0FBYWdCLElBQWIsQ0FBa0I7QUFBQ0YsU0FBRyxFQUFFLEtBQUthO0FBQVgsS0FBbEIsQ0FBUDtBQUNILEdBRkQsRSxDQUlBOztBQUNBMUgsUUFBTSxDQUFDbVIsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsVUFBU0MsRUFBVCxFQUFhO0FBQ3pDLFdBQU9qUixXQUFXLENBQUM0RyxJQUFaLENBQWlCO0FBQUNGLFNBQUcsRUFBRXVLO0FBQU4sS0FBakIsQ0FBUDtBQUNILEdBRkQsRSxDQUlBOztBQUNBcFIsUUFBTSxDQUFDbVIsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsWUFBVztBQUN2QyxRQUFHdFAsS0FBSyxDQUFDK0osWUFBTixDQUFtQixLQUFLbEUsTUFBeEIsRUFBZ0MsT0FBaEMsQ0FBSCxFQUE2QztBQUN6QyxhQUFPMUgsTUFBTSxDQUFDK0YsS0FBUCxDQUFhZ0IsSUFBYixDQUFrQjtBQUFFSixvQkFBWSxFQUFFM0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYSxZQUE5QjtBQUE0Q3BFLFlBQUksRUFBRTtBQUFsRCxPQUFsQixDQUFQO0FBQ0gsS0FGRCxNQUdLLElBQUdWLEtBQUssQ0FBQytKLFlBQU4sQ0FBbUIsS0FBS2xFLE1BQXhCLEVBQWdDLFlBQWhDLENBQUgsRUFBaUQ7QUFDbEQsYUFBTzFILE1BQU0sQ0FBQytGLEtBQVAsQ0FBYWdCLElBQWIsQ0FBa0I7QUFBRUosb0JBQVksRUFBRTNHLE1BQU0sQ0FBQzhGLElBQVAsR0FBY2EsWUFBOUI7QUFBNENwRSxZQUFJLEVBQUUsTUFBbEQ7QUFBMER3SCxrQkFBVSxFQUFFLEtBQUtyQztBQUEzRSxPQUFsQixDQUFQO0FBQ0g7QUFDSixHQVBEO0FBU0ExSCxRQUFNLENBQUNtUixPQUFQLENBQWUscUJBQWYsRUFBc0MsWUFBVztBQUM3QyxRQUFHdFAsS0FBSyxDQUFDK0osWUFBTixDQUFtQixLQUFLbEUsTUFBeEIsRUFBZ0MsT0FBaEMsQ0FBSCxFQUE0QztBQUN4QyxhQUFPMUgsTUFBTSxDQUFDK0YsS0FBUCxDQUFhZ0IsSUFBYixDQUFrQjtBQUFFSixvQkFBWSxFQUFFM0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYSxZQUE5QjtBQUE0Q3BFLFlBQUksRUFBRTtBQUFsRCxPQUFsQixDQUFQO0FBQ0g7QUFDSixHQUpELEUsQ0FNQTs7QUFDQXZDLFFBQU0sQ0FBQ21SLE9BQVAsQ0FBZSxJQUFmLEVBQXFCLFlBQVc7QUFDNUIsUUFBR25SLE1BQU0sQ0FBQzhGLElBQVAsRUFBSCxFQUFpQjtBQUNiLGFBQU83RixJQUFJLENBQUM4RyxJQUFMLENBQVU7QUFBQ0YsV0FBRyxFQUFFN0csTUFBTSxDQUFDOEYsSUFBUCxHQUFjYTtBQUFwQixPQUFWLENBQVA7QUFDSDtBQUNKLEdBSkQsRSxDQU1BOztBQUNBM0csUUFBTSxDQUFDbVIsT0FBUCxDQUFlLElBQWYsRUFBcUIsWUFBWTtBQUM3QixRQUFJLEtBQUt6SixNQUFULEVBQWlCO0FBQ2IsYUFBTzFILE1BQU0sQ0FBQ3FSLGNBQVAsQ0FBc0J0SyxJQUF0QixDQUEyQjtBQUFFLG9CQUFZLEtBQUtXO0FBQW5CLE9BQTNCLENBQVA7QUFDSCxLQUZELE1BR0s7QUFDRCxXQUFLNEosS0FBTDtBQUNIO0FBQ0osR0FQRCxFLENBUUE7O0FBQ0F0UixRQUFNLENBQUNtUixPQUFQLENBQWUsYUFBZixFQUE4QixZQUFZO0FBQ3RDLFdBQU9oUixXQUFXLENBQUM0RyxJQUFaLENBQWlCLEVBQWpCLENBQVA7QUFDSCxHQUZELEUsQ0FJQTs7QUFDQS9HLFFBQU0sQ0FBQ21SLE9BQVAsQ0FBZSxZQUFmLEVBQTZCLFlBQVk7QUFDckMsUUFBR3RQLEtBQUssQ0FBQytKLFlBQU4sQ0FBbUIsS0FBS2xFLE1BQXhCLEVBQWdDLENBQUMsT0FBRCxFQUFVLFlBQVYsQ0FBaEMsQ0FBSCxFQUNJLE9BQU90SCxNQUFNLENBQUMyRyxJQUFQLEVBQVA7QUFDSixXQUFPM0csTUFBTSxDQUFDMkcsSUFBUCxDQUFZO0FBQUMsZ0JBQVUsS0FBS1c7QUFBaEIsS0FBWixDQUFQO0FBQ0gsR0FKRCxFLENBTUE7QUFDQTs7QUFDQTFILFFBQU0sQ0FBQ21SLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFVBQVVDLEVBQVYsRUFBYztBQUN0QyxXQUFPL1EsT0FBTyxDQUFDMEcsSUFBUixDQUFhO0FBQUNGLFNBQUcsRUFBRXVLO0FBQU4sS0FBYixDQUFQO0FBQ0gsR0FGRCxFLENBR0E7O0FBQ0FwUixRQUFNLENBQUNtUixPQUFQLENBQWUsU0FBZixFQUEwQixZQUFZO0FBQ2xDLFdBQU85USxPQUFPLENBQUMwRyxJQUFSLENBQWEsRUFBYixDQUFQO0FBQ0gsR0FGRCxFLENBR0E7O0FBQ0EvRyxRQUFNLENBQUNtUixPQUFQLENBQWUsc0JBQWYsRUFBdUMsVUFBVUMsRUFBVixFQUFjO0FBQ2pELFdBQU85USxhQUFhLENBQUN5RyxJQUFkLENBQW1CLEVBQW5CLENBQVA7QUFDSCxHQUZEO0FBSUEvRyxRQUFNLENBQUNtUixPQUFQLENBQWUsMkJBQWYsRUFBNEMsVUFBVUMsRUFBVixFQUFjO0FBQ3RELFdBQU85USxhQUFhLENBQUN5RyxJQUFkLENBQW1CO0FBQUNGLFNBQUcsRUFBRXVLO0FBQU4sS0FBbkIsQ0FBUDtBQUNILEdBRkQsRSxDQUlBOztBQUNBcFIsUUFBTSxDQUFDbVIsT0FBUCxDQUFlLElBQWYsRUFBcUIsWUFBVztBQUM1QixXQUFPNVEsTUFBTSxDQUFDd0csSUFBUCxDQUFZO0FBQUM0QyxlQUFTLEVBQUUsS0FBS2pDO0FBQWpCLEtBQVosQ0FBUDtBQUNILEdBRkQsRSxDQUlBOztBQUNBMUgsUUFBTSxDQUFDbVIsT0FBUCxDQUFlLFFBQWYsRUFBeUIsWUFBVztBQUNoQzFMLFdBQU8sQ0FBQ0MsR0FBUixDQUFZMUYsTUFBTSxDQUFDOEYsSUFBUCxHQUFjYSxZQUExQixFQUF3QyxLQUFLZSxNQUE3Qzs7QUFDQSxRQUFHMUgsTUFBTSxDQUFDOEYsSUFBUCxFQUFILEVBQWlCO0FBQ2IsYUFBT3ZGLE1BQU0sQ0FBQ3dHLElBQVAsQ0FBWTtBQUFDd0ssV0FBRyxFQUFFLENBQUM7QUFBRUMsY0FBSSxFQUFFLENBQUM7QUFBQ25QLGVBQUcsRUFBRXJDLE1BQU0sQ0FBQzhGLElBQVAsR0FBY2E7QUFBcEIsV0FBRCxFQUFtQztBQUFDZ0QscUJBQVMsRUFBRSxLQUFLakM7QUFBakIsV0FBbkM7QUFBUixTQUFELEVBQXVFO0FBQUM4SixjQUFJLEVBQUMsQ0FBQztBQUFDN0gscUJBQVMsRUFBRTNKLE1BQU0sQ0FBQzhGLElBQVAsR0FBY2lFO0FBQTFCLFdBQUQsRUFBdUM7QUFBQ0wsZ0JBQUksRUFBQztBQUFOLFdBQXZDO0FBQU4sU0FBdkUsRUFBZ0o7QUFBQzhILGNBQUksRUFBRSxDQUFDO0FBQUNuUCxlQUFHLEVBQUVyQyxNQUFNLENBQUM4RixJQUFQLEdBQWNhO0FBQXBCLFdBQUQsRUFBbUM7QUFBQytDLGdCQUFJLEVBQUU7QUFBUCxXQUFuQztBQUFQLFNBQWhKLEVBQXVOO0FBQUNBLGNBQUksRUFBQyxLQUFLaEM7QUFBWCxTQUF2TjtBQUFOLE9BQVosRUFBK1A7QUFBQ3FJLFlBQUksRUFBRTtBQUFDeEcsY0FBSSxFQUFDLENBQU47QUFBVUgsZUFBSyxFQUFDLENBQWhCO0FBQW1CRSxhQUFHLEVBQUMsQ0FBdkI7QUFBMEIrRyxjQUFJLEVBQUM7QUFBL0I7QUFBUCxPQUEvUCxDQUFQO0FBQ0g7QUFDSixHQUxEIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xuXG4vL0RlZmluZSBDb2xsZWN0aW9uc1xuT3JncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdvcmdhbml6YXRpb25zJyk7XG5Bc3Nlc3NtZW50cyAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYXNzZXNzbWVudHMnKTtcblRyaWFscyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd0cmlhbHMnKTtcbk1vZHVsZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbW9kdWxlcycpO1xuTW9kdWxlUmVzdWx0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdtb2RyZXN1bHRzJyk7XG5FdmVudHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZXZlbnRzJyk7IiwiZXhwb3J0IHtjYWxjdWxhdGVTY29yZXN9XG5sZXQgc3Vic2NhbGVTY29yZXMgPSBcbntcbiAgICBcImNvblwiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgNDMsIDQ1LCA0OCwgNTEsIDU0LCA1NywgNTksIDYyLCA2NSwgNjgsIDcwLCA3MywgNzYsIDc5LCA4MSwgODQsIDg3LCA5MCwgOTIsIDk1LCA5OCwgMTAxLCAxMDMsIDEwNiwgMTA5IF0sXG4gICAgICAgIFwiZmVtYWxlXCI6IFsgMzksIDQxLCA0NCwgNDYsIDQ4LCA1MCwgNTIsIDU0LCA1NiwgNTgsIDYwLCA2MiwgNjQsIDY2LCA2OCwgNzEsIDczLCA3NSwgNzcsIDc5LCA4MSwgODMsIDg1LCA4NywgODkgXVxuICAgIH0sXG4gICAgXCJkZWZcIjoge1xuICAgICAgICBcIm1pblwiOiA3LjUsXG4gICAgICAgIFwibWFsZVwiOiBbIDE5LCAyMiwgMjQsIDI2LCAyOSwgMzEsIDMzLCAzNiwgMzgsIDQwLCA0MywgNDUsIDQ4LCA1MCwgNTIsIDU0LCA1NywgNTksIDYxLCA2NCwgNjYsIDY4LCA3MSwgNzMsIDc2XSxcbiAgICAgICAgXCJmZW1hbGVcIjogWyAyOSwgMzIsIDM0LCAzNiwgMzgsIDQwLCA0MiwgNDUsIDQ3LCA0OSwgNTEsIDUzLCA1NSwgNTgsIDYwLCA2MiwgNjQsIDY2LCA2OCwgNzAsIDczLCA3NSwgNzcsIDc5LCA4MV1cbiAgICB9LFxuICAgIFwibW9sbFwiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzgsIDQwLCA0MywgNDUsIDQ4LCA1MCwgNTMsIDU1LCA1OCwgNjAsIDYzLCA2NSwgNjgsIDcwLCA3MywgNzUsIDc4LCA4MCwgODMsIDg1LCA4OCwgOTAsIDkzLCA5NSwgOThdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDM3LCAzOSwgNDIsIDQ0LCA0NiwgNDgsIDUwLCA1MywgNTUsIDU3LCA2MCwgNjIsIDY0LCA2NiwgNjgsIDcxLCA3MywgNzUsIDc3LCA4MCwgODIsIDg0LCA4NiwgODksIDkxXVxuICAgIH0sXG4gICAgXCJjdXRcIjoge1xuICAgICAgICBcIm1pblwiOiA3LjUsXG4gICAgICAgIFwibWFsZVwiOiBbIDQwLCA0MiwgNDQsIDQ2LCA0OCwgNTAsIDUyLCA1NCwgNTYsIDU4LCA2MCwgNjIsIDY0LCA2NiwgNjgsIDcwLCA3MiwgNzQsIDc2LCA3OCwgODAsIDgyLCA4NCwgODYsIDg4XSxcbiAgICAgICAgXCJmZW1hbGVcIjogWyAzMywgMzQsIDM2LCAzOCwgNDAsIDQyLCA0NCwgNDYsIDQ3LCA0OSwgNTEsIDUzLCA1NSwgNTYsIDU4LCA2MCwgNjIsIDY0LCA2NiwgNjgsIDY5LCA3MSwgNzMsIDc1LCA3N11cbiAgICB9LFxuICAgIFwiZW50XCI6IHtcbiAgICAgICAgXCJtaW5cIjogNy41LFxuICAgICAgICBcIm1hbGVcIjogWyAzOCwgNDEsIDQzLCA0NiwgNDgsIDUxLCA1NCwgNTYsIDU5LCA2MSwgNjQsIDY2LCA2OSwgNzIsIDc0LCA3NywgNzksIDgyLCA4NCwgODcsIDkwLCA5MiwgOTUsIDk3LCAxMDBdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDM0LCAzNywgMzksIDQyLCA0NCwgNDcsIDQ5LCA1MiwgNTQsIDU3LCA1OSwgNjIsIDY0LCA2NywgNjksIDcyLCA3NCwgNzcsIDc5LCA4MiwgODQsIDg3LCA4OSwgOTIsIDk0XVxuICAgIH0sXG4gICAgXCJwb1wiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzksIDQyLCA0NCwgNDcsIDUwLCA1MiwgNTUsIDU3LCA2MCwgNjIsIDY1LCA2NywgNzAsIDcyLCA3NSwgNzcsIDgwLCA4MiwgODUsIDg3LCA5MCwgOTIsIDk1LCA5NywgMTAwXSxcbiAgICAgICAgXCJmZW1hbGVcIjogWyAzNywgMzksIDQxLCA0MywgNDUsIDQ4LCA1MCwgNTIsIDU0LCA1NiwgNTgsIDYwLCA2MiwgNjQsIDY2LCA2OCwgNzAsIDcyLCA3NCwgNzYsIDc4LCA4MSwgODMsIDg1LCA4N11cbiAgICB9LFxuICAgIFwic2VudFwiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMjYsIDI5LCAzMSwgMzQsIDM2LCAzOSwgNDIsIDQ0LCA0NywgNDksIDUyLCA1NSwgNTcsIDYwLCA2MiwgNjUsIDY4LCA3MCwgNzMsIDc1LCA3OCwgODEsIDgzLCA4NiwgODhdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDI0LCAyNywgMjksIDMyLCAzNCwgMzcsIDM5LCA0MiwgNDQsIDQ2LCA0OSwgNTEsIDU0LCA1NiwgNTksIDYxLCA2NCwgNjYsIDY5LCA3MSwgNzMsIDc2LCA3OCwgODEsIDgzXVxuICAgIH0sXG4gICAgXCJzb1wiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzQsIDM3LCAzOSwgNDIsIDQ0LCA0NywgNDksIDUyLCA1NCwgNTYsIDU5LCA2MSwgNjQsIDY2LCA2OSwgNzEsIDc0LCA3NiwgNzksIDgxLCA4NCwgODYsIDg4LCA5MSwgOTNdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDMxLCAzNCwgMzYsIDM4LCA0MCwgNDIsIDQ0LCA0NiwgNDgsIDUxLCA1MywgNTUsIDU3LCA1OSwgNjEsIDYzLCA2NSwgNjgsIDcwLCA3MiwgNzQsIDc2LCA3OCwgODAsIDgyXVxuICAgIH0sXG4gICAgXCJjaVwiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzYsIDM4LCA0MCwgNDIsIDQ0LCA0NiwgNDgsIDUwLCA1MiwgNTQsIDU2LCA1OCwgNjAsIDYyLCA2NCwgNjYsIDY4LCA3MCwgNzIsIDc0LCA3NiwgNzgsIDgwLCA4MiwgODRdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDMxLCAzMywgMzUsIDM3LCAzOSwgNDAsIDQyLCA0NCwgNDYsIDQ4LCA1MCwgNTIsIDU0LCA1NiwgNTgsIDYwLCA2MiwgNjQsIDY2LCA2NywgNjksIDcxLCA3MywgNzUsIDc3XVxuICAgIH0sXG4gICAgXCJkaXNjXCI6IHtcbiAgICAgICAgXCJtaW5cIjogNy41LFxuICAgICAgICBcIm1hbGVcIjogWyAzOCwgNDAsIDQyLCA0NCwgNDYsIDQ4LCA1MCwgNTIsIDU0LCA1NiwgNTgsIDYwLCA2MiwgNjQsIDY2LCA2OCwgNzAsIDcyLCA3NCwgNzYsIDc4LCA4MCwgODIsIDg0LCA4Nl0sXG4gICAgICAgIFwiZmVtYWxlXCI6IFsgMzIsIDM0LCAzNiwgMzgsIDM5LCA0MSwgNDMsIDQ1LCA0NiwgNDgsIDUwLCA1MiwgNTQsIDU1LCA1NywgNTksIDYxLCA2MiwgNjQsIDY2LCA2OCwgNzAsIDcxLCA3MywgNzVdXG4gICAgfSxcbiAgICBcImZvY1wiOiB7XG4gICAgICAgIFwibWluXCI6IDcuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzYsIDM4LCA0MSwgNDMsIDQ1LCA0NywgNDksIDUxLCA1NCwgNTYsIDU4LCA2MCwgNjIsIDY0LCA2NywgNjksIDcxLCA3MywgNzUsIDc4LCA4MCwgODIsIDg0LCA4NiwgODhdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDM2LCAzNywgMzksIDQxLCA0MywgNDUsIDQ3LCA0OSwgNTAsIDUyLCA1NCwgNTYsIDU4LCA2MCwgNjEsIDYzLCA2NSwgNjcsIDY5LCA3MSwgNzMsIDc0LCA3NiwgNzgsIDgwXVxuICAgIH0sXG4gICAgXCJjdXJcIjoge1xuICAgICAgICBcIm1pblwiOiAxMi41LFxuICAgICAgICBcIm1hbGVcIjogWyAzOSwgNDAsIDQyLCA0MywgNDQsIDQ1LCA0NiwgNDgsIDQ5LCA1MCwgNTEsIDUyLCA1NCwgNTUsIDU2LCA1NywgNTksIDYwLCA2MSwgNjIsIDYzLCA2NSwgNjYsIDY3LCA2OCwgNzAsIDcxLCA3MiwgNzMsIDc0LCA3NiwgNzcsIDc4LCA3OSwgODAsIDgyLCA4MywgODQsIDg1LCA4N10sXG4gICAgICAgIFwiZmVtYWxlXCI6IFsgMzMsIDM0LCAzNSwgMzcsIDM4LCAzOSwgNDAsIDQxLCA0MiwgNDMsIDQ0LCA0NSwgNDYsIDQ3LCA0OSwgNTAsIDUxLCA1MiwgNTMsIDU0LCA1NSwgNTYsIDU3LCA1OCwgNjAsIDYxLCA2MiwgNjMsIDY0LCA2NSwgNjYsIDY3LCA2OCwgNjksIDcwLCA3MiwgNzMsIDc0LCA3NSwgNzZdXG4gICAgfSxcbiAgICBcImhpc3RcIjoge1xuICAgICAgICBcIm1pblwiOiAxMS41LFxuICAgICAgICBcIm1hbGVcIjogWyAzOSwgNDAsIDQxLCA0MywgNDQsIDQ2LCA0NywgNDgsIDUwLCA1MSwgNTMsIDU0LCA1NSwgNTcsIDU4LCA2MCwgNjEsIDYyLCA2NCwgNjUsIDY3LCA2OCwgNzAsIDcxLCA3MiwgNzQsIDc1LCA3NiwgNzgsIDc5LCA4MSwgODIsIDgzLCA4NSwgODYsIDg4LCA4OV0sXG4gICAgICAgIFwiZmVtYWxlXCI6IFsgMzMsIDM0LCAzNiwgMzcsIDM4LCAzOSwgNDEsIDQyLCA0MywgNDUsIDQ2LCA0NywgNDgsIDUwLCA1MSwgNTIsIDU0LCA1NSwgNTYsIDU3LCA1OSwgNjAsIDYxLCA2MiwgNjQsIDY1LCA2NiwgNjgsIDY5LCA3MCwgNzIsIDczLCA3NCwgNzUsIDc3LCA3OCwgNzldXG4gICAgfSxcbiAgICBcInByb2JcIjoge1xuICAgICAgICBcIm1pblwiOiA5LjUsXG4gICAgICAgIFwibWFsZVwiOiBbIDQwLCA0MSwgNDMsIDQ0LCA0NiwgNDcsIDQ5LCA1MCwgNTIsIDUzLCA1NSwgNTYsIDU4LCA1OSwgNjEsIDYyLCA2NCwgNjUsIDY3LCA2OCwgNzAsIDcxLCA3MywgNzQsIDc1LCA3NywgNzksIDgwLCA4MiwgODQsIDg1XSxcbiAgICAgICAgXCJmZW1hbGVcIjogWyAzNCwgMzUsIDM2LCAzOCwgMzksIDQwLCA0MiwgNDMsIDQ0LCA0NiwgNDcsIDQ4LCA1MCwgNTEsIDUyLCA1NCwgNTUsIDU2LCA1OCwgNTksIDYxLCA2MiwgNjMsIDY1LCA2NiwgNjcsIDY5LCA3MCwgNzEsIDczLCA3NF1cbiAgICB9LFxuICAgIFwiaW50aG9zdFwiOiB7XG4gICAgICAgIFwibWluXCI6IDkuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgNDIsIDQ1LCA0OCwgNTEsIDU0LCA1NywgNjAsIDY0LCA2NywgNzAsIDczLCA3NiwgNzksIDgyLCA4NSwgODgsIDkyLCA5NSwgOTgsIDEwMSwgMTA0LCAxMDcsIDExMCwgMTE0LCAxMTcsIDEyMCwgMTIzLCAxMjYsIDEyOSwgMTMyLCAxMzVdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDQyLCA0NCwgNDYsIDQ5LCA1MSwgNTMsIDU1LCA1NywgNjAsIDYyLCA2NCwgNjYsIDY5LCA3MSwgNzMsIDc1LCA3OCwgODAsIDgyLCA4NCwgODYsIDg5LCA5MSwgOTMsIDk2LCA5OCwgMTAwLCAxMDIsIDEwNCwgMTA3LCAxMDldXG4gICAgfSxcbiAgICBcImFzc2VydFwiOiB7XG4gICAgICAgIFwibWluXCI6IDkuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgNDAsIDQyLCA0NCwgNDUsIDQ3LCA0OSwgNTAsIDUyLCA1NCwgNTUsIDU3LCA1OCwgNjAsIDYyLCA2MywgNjUsIDY3LCA2OCwgNzAsIDcyLCA3MywgNzUsIDc3LCA3OCwgODAsIDgyLCA4MywgODUsIDg3LCA4OCwgOTBdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDM1LCAzNywgMzgsIDQwLCA0MSwgNDMsIDQ0LCA0NiwgNDgsIDQ5LCA1MSwgNTIsIDU0LCA1NSwgNTcsIDU5LCA2MCwgNjIsIDYzLCA2NSwgNjYsIDY4LCA3MCwgNzEsIDczLCA3NCwgNzYsIDc3LCA3OSwgODEsIDgyXVxuICAgIH0sXG4gICAgXCJkbnRcIjoge1xuICAgICAgICBcIm1pblwiOiA5LjUsXG4gICAgICAgIFwibWFsZVwiOiBbIDI1LCAyNywgMjksIDMwLCAzMiwgMzQsIDM2LCAzOCwgNDAsIDQyLCA0NCwgNDUsIDQ3LCA0OSwgNTEsIDUzLCA1NSwgNTcsIDU5LCA2MSwgNjMsIDY0LCA2NiwgNjgsIDcwLCA3MiwgNzQsIDc2LCA3OCwgODAsIDgxXSxcbiAgICAgICAgXCJmZW1hbGVcIjogWyAyMiwgMjQsIDI2LCAyOCwgMzAsIDMyLCAzNCwgMzYsIDM4LCA0MCwgNDIsIDQ0LCA0NiwgNDgsIDUwLCA1MSwgNTMsIDU1LCA1NywgNTksIDYxLCA2MywgNjUsIDY3LCA2OSwgNzEsIDczLCA3NSwgNzcsIDc5LCA4MV1cbiAgICB9LFxuICAgIFwicGN0XCI6IHtcbiAgICAgICAgXCJtaW5cIjogMzEuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzUsIDM2LCAzNiwgMzcsIDM4LCAzOSwgMzksIDQwLCA0MSwgNDIsIDQyLCA0MywgNDQsIDQ1LCA0NSwgNDYsIDQ3LCA0OCwgNDgsIDQ5LCA1MCwgNTEsIDUxLCA1MiwgNTMsIDU0LCA1NCwgNTUsIDU2LCA1NywgNTcsIDU4LCA1OSwgNjAsIDYwLCA2MSwgNjIsIDYzLCA2MywgNjQsIDY1LCA2NiwgNjYsIDY3LCA2OCwgNjksIDY5LCA3MCwgNzEsIDcyLCA3MiwgNzMsIDc0LCA3NSwgNzYsIDc2LCA3NywgNzgsIDc4LCA3OSwgODAsIDgxLCA4MiwgODIsIDgzLCA4NCwgODQsIDg1LCA4NiwgODcsIDg4LCA4OCwgODksIDkwLCA5MSwgOTEsIDkyLCA5MywgOTQsIDk0LCA5NSwgOTYsIDk3LCA5NywgOTgsIDk4LCAxMDAsIDEwMCwgMTAxLCAxMDIsIDEwMywgMTAzLCAxMDQsIDEwNSwgMTA2LCAxMDYsIDEwN10sXG4gICAgICAgIFwiZmVtYWxlXCI6IFsgMzYsIDM2LCAzNywgMzgsIDM4LCAzOSwgNDAsIDQwLCA0MSwgNDIsIDQyLCA0MywgNDQsIDQ0LCA0NSwgNDYsIDQ2LCA0NywgNDgsIDQ4LCA0OSwgNDksIDUwLCA1MSwgNTIsIDUyLCA1MywgNTQsIDU0LCA1NSwgNTYsIDU2LCA1NywgNTgsIDU4LCA1OSwgNjAsIDYwLCA2MSwgNjIsIDYzLCA2MywgNjQsIDY1LCA2NSwgNjYsIDY3LCA2NywgNjgsIDY5LCA2OSwgNzAsIDcxLCA3MSwgNzIsIDcyLCA3MywgNzQsIDc1LCA3NiwgNzYsIDc3LCA3OCwgNzgsIDc5LCA4MCwgODAsIDgxLCA4MiwgODIsIDgzLCA4NCwgODQsIDg1LCA4NiwgODYsIDg3LCA4OCwgODgsIDg5LCA5MCwgOTAsIDkxLCA5MiwgOTIsIDkzLCA5NCwgOTQsIDk1LCA5NiwgOTYsIDk3LCA5OCwgOTksIDk5LCAxMDAsIDEwMV1cbiAgICB9LFxuICAgIFwicmN0XCI6IHtcbiAgICAgICAgXCJtaW5cIjogMjMuNSxcbiAgICAgICAgXCJtYWxlXCI6IFsgMzcsIDM3LCAzOCwgMzksIDQwLCA0MCwgNDEsIDQyLCA0MywgNDMsIDQ0LCA0NSwgNDYsIDQ2LCA0NywgNDgsIDQ4LCA0OSwgNTAsIDUxLCA1MSwgNTIsIDUzLCA1NCwgNTQsIDU1LCA1NiwgNTcsIDU3LCA1OCwgNTksIDYwLCA2MCwgNjEsIDYyLCA2MywgNjMsIDY0LCA2NSwgNjYsIDY2LCA2NywgNjgsIDY4LCA2OSwgNzAsIDcxLCA3MiwgNzIsIDczLCA3NCwgNzQsIDc1LCA3NiwgNzcsIDc4LCA3OCwgNzksIDgwLCA4MCwgODEsIDgyLCA4MywgODMsIDg0LCA4NSwgODYsIDg2LCA4NywgODgsIDg5LCA4OSwgOTBdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDI3LCAyNywgMjgsIDI5LCAyOSwgMzAsIDMxLCAzMSwgMzIsIDMzLCAzMywgMzQsIDM1LCAzNSwgMzYsIDM3LCAzNywgMzgsIDM5LCAzOSwgNDAsIDQxLCA0MSwgNDIsIDQzLCA0MywgNDQsIDQ1LCA0NSwgNDYsIDQ3LCA0NywgNDgsIDQ5LCA0OSwgNTAsIDUxLCA1MSwgNTIsIDUzLCA1MywgNTQsIDU1LCA1NSwgNTYsIDU3LCA1NywgNTgsIDU5LCA1OSwgNjAsIDYxLCA2MSwgNjIsIDYzLCA2MywgNjQsIDY1LCA2NSwgNjYsIDY3LCA2NywgNjgsIDY5LCA2OSwgNzAsIDcxLCA3MSwgNzIsIDczLCA3MywgNzQsIDc1XVxuICAgIH0sXG4gICAgXCJnY3RcIjoge1xuICAgICAgICBcIm1pblwiOiA1NS41LFxuICAgICAgICBcIm1hbGVcIjogWyAzNCwgMzUsIDM1LCAzNiwgMzYsIDM2LCAzNywgMzcsIDM4LCAzOCwgMzgsIDM5LCAzOSwgNDAsIDQwLCA0MCwgNDEsIDQxLCA0MiwgNDIsIDQzLCA0MywgNDMsIDQ0LCA0NCwgNDUsIDQ1LCA0NiwgNDYsIDQ2LCA0NywgNDcsIDQ4LCA0OCwgNDgsIDQ5LCA0OSwgNTAsIDUwLCA1MCwgNTEsIDUxLCA1MiwgNTIsIDUyLCA1MywgNTMsIDU0LCA1NCwgNTQsIDU1LCA1NSwgNTYsIDU2LCA1NiwgNTcsIDU3LCA1OCwgNTgsIDU4LCA1OSwgNTksIDYwLCA2MCwgNjAsIDYxLCA2MSwgNjIsIDYyLCA2MywgNjMsIDYzLCA2NCwgNjQsIDY1LCA2NSwgNjYsIDY2LCA2NiwgNjcsIDY3LCA2OCwgNjgsIDY4LCA2OSwgNjksIDcwLCA3MCwgNzAsIDcxLCA3MSwgNzIsIDcyLCA3MiwgNzMsIDczLCA3NCwgNzQsIDc0LCA3NSwgNzUsIDc2LCA3NiwgNzYsIDc3LCA3NywgNzgsIDc4LCA3OSwgNzksIDc5LCA4MCwgODAsIDgxLCA4MSwgODEsIDgyLCA4MiwgODMsIDgzLCA4NCwgODQsIDg0LCA4NSwgODUsIDg2LCA4NiwgODYsIDg3LCA4NywgODgsIDg4LCA4OCwgODksIDg5LCA5MCwgOTAsIDkwLCA5MSwgOTEsIDkyLCA5MiwgOTIsIDkzLCA5MywgOTQsIDk0LCA5NSwgOTUsIDk1LCA5NiwgOTYsIDk3LCA5NywgOTcsIDk4LCA5OCwgOTksIDk5LCAxMDAsIDEwMCwgMTAwLCAxMDEsIDEwMSwgMTAyLCAxMDIsIDEwMiwgMTAzLCAxMDNdLFxuICAgICAgICBcImZlbWFsZVwiOiBbIDI5LCAzMCwgMzAsIDMwLCAzMSwgMzEsIDMxLCAzMiwgMzIsIDMyLCAzMywgMzMsIDM0LCAzNCwgMzQsIDM1LCAzNSwgMzUsIDM2LCAzNiwgMzYsIDM3LCAzNywgMzgsIDM4LCAzOCwgMzksIDM5LCA0MCwgNDAsIDQwLCA0MSwgNDEsIDQxLCA0MiwgNDIsIDQyLCA0MywgNDMsIDQ0LCA0NCwgNDQsIDQ1LCA0NSwgNDUsIDQ2LCA0NiwgNDcsIDQ3LCA0NywgNDgsIDQ4LCA0OCwgNDksIDQ5LCA1MCwgNTAsIDUwLCA1MSwgNTEsIDUxLCA1MiwgNTIsIDUyLCA1MywgNTMsIDU0LCA1NCwgNTQsIDU1LCA1NSwgNTUsIDU2LCA1NiwgNTYsIDU3LCA1NywgNTgsIDU4LCA1OCwgNTksIDU5LCA2MCwgNjAsIDYwLCA2MSwgNjEsIDYxLCA2MiwgNjIsIDYyLCA2MywgNjMsIDY0LCA2NCwgNjQsIDY1LCA2NSwgNjUsIDY2LCA2NiwgNjYsIDY3LCA2NywgNjgsIDY4LCA2OCwgNjksIDY5LCA3MCwgNzAsIDcwLCA3MSwgNzEsIDcxLCA3MiwgNzIsIDcyLCA3MywgNzMsIDc0LCA3NCwgNzQsIDc1LCA3NSwgNzUsIDc2LCA3NiwgNzYsIDc3LCA3NywgNzgsIDc4LCA3OCwgNzksIDc5LCA4MCwgODAsIDgwLCA4MSwgODEsIDgxLCA4MiwgODIsIDgyLCA4MywgODMsIDg0LCA4NCwgODQsIDg1LCA4NSwgODUsIDg2LCA4NiwgODcsIDg3LCA4NywgODgsIDg4LCA4OCwgODksIDg5LCA5MCwgOTAsIDkwLCA5MSwgOTEsIDkxXVxuICAgIH1cbn1cblxuZnVuY3Rpb24gZ2V0U2NvcmVGb3JQSUNUU1N1YnNjYWxlKHNjb3Jlcywgc2V4KXtcbiAgICBsZXQgY2FsY3VsYXRlZFNjb3JlcyA9IHsgXCJHQ1RcIjogMCwgXG4gICAgICAgIFwiUENUXCI6IHNjb3Jlc1tcIk1PTExcIl0gKyBzY29yZXNbJ0VOVCddICsgc2NvcmVzW1wiUE9cIl0gKyBzY29yZXNbXCJTT1wiXSxcbiAgICAgICAgXCJSQ1RcIjogIHNjb3Jlc1tcIkNVVFwiXSArIHNjb3Jlc1snQ0knXSArIHNjb3Jlc1tcIkRJU0NcIl1cbiAgICB9O1xuICAgIGNhbGN1bGF0ZWRTY29yZXNbJ0dDVCddID0gY2FsY3VsYXRlZFNjb3Jlc1tcIlJDVFwiXSArIGNhbGN1bGF0ZWRTY29yZXNbXCJQQ1RcIl07XG5cbiAgICBmb3IobGV0IHN1YnNjYWxlIG9mIE9iamVjdC5rZXlzKGNhbGN1bGF0ZWRTY29yZXMpKXtcbiAgICAgICAgY29uc3Qgc2NhbGUgPSBzdWJzY2FsZVNjb3Jlc1tzdWJzY2FsZS50b0xvd2VyQ2FzZSgpXVxuICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjYWxlW3NleF1bTWF0aC5mbG9vcihjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSAtIHNjYWxlLm1pbildXG4gICAgfVxuXG4gICAgY29uc3Qgc3Vic2NhbGVzID0gT2JqZWN0LmtleXMoc2NvcmVzKTtcblxuICAgIGZvcihsZXQgc3Vic2NhbGUgb2Ygc3Vic2NhbGVzKXtcbiAgICAgICAgY29uc3Qgc2NhbGUgPSBzdWJzY2FsZVNjb3Jlc1tzdWJzY2FsZS50b0xvd2VyQ2FzZSgpXVxuICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjYWxlW3NleF1bTWF0aC5mbG9vcihzY29yZXNbc3Vic2NhbGVdIC0gc2NhbGUubWluKV1cbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIGNhbGN1bGF0ZWRTY29yZXM7XG59XG5cbmZ1bmN0aW9uIGdldFNjb3JlRm9yREhTU3Vic2NhbGUoc2NvcmVzKXtcbiAgICBsZXQgY2FsY3VsYXRlZFNjb3JlcyA9IHt9O1xuICAgIGZvcihsZXQgc3Vic2NhbGUgb2YgT2JqZWN0LmtleXMoc2NvcmVzKSl7XG4gICAgICAgIGxldCBzY29yZSA9IHNjb3Jlc1tzdWJzY2FsZV07XG4gICAgICAgIGlmKHN1YnNjYWxlID09ICdERVBSRVNTSU9OJyl7XG4gICAgICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjb3JlIC8gMTc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihzdWJzY2FsZSA9PSAnSE9QRUxFU1NORVNTJyl7XG4gICAgICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjb3JlIC8gMTA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZihzdWJzY2FsZSA9PSAnQ1NJJyl7XG4gICAgICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjb3JlIC8gMjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmKHN1YnNjYWxlID09ICdISVNUJyl7XG4gICAgICAgICAgICBjYWxjdWxhdGVkU2NvcmVzW3N1YnNjYWxlXSA9IHNjb3JlIC8gNTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmKHN1YnNjYWxlID09ICdDVVInKXtcbiAgICAgICAgICAgIGNhbGN1bGF0ZWRTY29yZXNbc3Vic2NhbGVdID0gc2NvcmUgLyAzO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGNhbGN1bGF0ZWRTY29yZXM7XG59XG5cbmZ1bmN0aW9uIGNhbGN1bGF0ZVNjb3JlcyhzdWJzY2FsZSwgc2NvcmVzLCBzZXgpe1xuICAgIHN3aXRjaCAoc3Vic2NhbGUudG9VcHBlckNhc2UoKSl7XG4gICAgICAgIGNhc2UgJ1BJQ1RTJzpcbiAgICAgICAgICAgIHJldHVybiBnZXRTY29yZUZvclBJQ1RTU3Vic2NhbGUoc2NvcmVzLCBzZXgpO1xuICAgICAgICAvLyBjYXNlICdESFMnOlxuICAgICAgICAvLyAgICAgcmV0dXJuIGdldFNjb3JlRm9yREhTU3Vic2NhbGUoc2NvcmVzLCBzZXgpO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgLy8gbm8gZXh0cmEgY2FsY3VsYXRpb24gbmVlZGVkLiByZXR1cm5cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBBY2NvdW50cyB9IGZyb20gJ21ldGVvci9hY2NvdW50cy1iYXNlJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJzsgLy8gaHR0cHM6Ly9naXRodWIuY29tL01ldGVvci1Db21tdW5pdHktUGFja2FnZXMvbWV0ZW9yLXJvbGVzXG5pbXBvcnQgeyBjYWxjdWxhdGVTY29yZXMgfSBmcm9tICcuL3N1YnNjYWxlQ2FsY3VsYXRpb25zLmpzJztcbmltcG9ydCB7IFB1c2ggfSBmcm9tICdtZXRlb3IvYWN0aXZpdHJlZTpwdXNoJztcblxuY29uc3QgU0VFRF9BRE1JTiA9IHtcbiAgICB1c2VybmFtZTogJ3Rlc3RBZG1pbicsXG4gICAgcGFzc3dvcmQ6ICdwYXNzd29yZCcsXG4gICAgZW1haWw6ICd0ZXN0QWRtaW5AbWVtcGhpcy5lZHUnLFxuICAgIGZpcnN0TmFtZTogJ0pvaG5ueScsXG4gICAgbGFzdE5hbWU6ICdUZXN0JyxcbiAgICBvcmcgOiBcIlwiLFxuICAgIHN1cGVydmlzb3JJRDogXCIwXCIsXG4gICAgcm9sZTogJ2FkbWluJyxcbiAgICBzdXBlcnZpc29ySW52aXRlQ29kZTogXCIxMjM0NVwiLFxuICAgIHNleDogJ2ZlbWFsZScsXG4gICAgYXNzaWduZWQ6IFtdLFxuICAgIG5leHRNb2R1bGU6IC0xXG59O1xuY29uc3QgU0VFRF9TVVBFUlZJU09SID0ge1xuICAgIHVzZXJuYW1lOiAndGVzdFN1cGVydmlzb3InLFxuICAgIHBhc3N3b3JkOiAncGFzc3dvcmQnLFxuICAgIGVtYWlsOiAndGVzdFN1cGVydmlzb3JAbWVtcGhpcy5lZHUnLFxuICAgIGZpcnN0TmFtZTogJ1N1cGVydmlzb3InLFxuICAgIGxhc3ROYW1lOiAnVGVzdCcsXG4gICAgb3JnIDogXCJcIixcbiAgICBzdXBlcnZpc29ySUQ6IFwiMFwiLFxuICAgIHJvbGU6ICdzdXBlcnZpc29yJyxcbiAgICBzdXBlcnZpc29ySW52aXRlQ29kZTogXCIxMjM0NVwiLFxuICAgIHNleDogJ21hbGUnLFxuICAgIGFzc2lnbmVkOiBbXSxcbiAgICBuZXh0TW9kdWxlOiAtMVxufTtcbmNvbnN0IFNFRURfVVNFUiA9IHtcbiAgICB1c2VybmFtZTogJ3Rlc3RVc2VyJyxcbiAgICBwYXNzd29yZDogJ3Bhc3N3b3JkJyxcbiAgICBlbWFpbDogJ3Rlc3RVc2VyQG1lbXBoaXMuZWR1JyxcbiAgICBmaXJzdE5hbWU6ICdVc2VyJyxcbiAgICBsYXN0TmFtZTogJ1Rlc3QnLFxuICAgIG9yZyA6IFwiXCIsXG4gICAgc3VwZXJ2aXNvcklEOiBcIjBcIixcbiAgICByb2xlOiAndXNlcicsXG4gICAgc3VwZXJ2aXNvckludml0ZUNvZGU6IG51bGwsXG4gICAgc2V4OiAnZmVtYWxlJyxcbiAgICBhc3NpZ25lZDogW10sXG4gICAgaGFzQ29tcGxldGVkRmlyc3RBc3Nlc3NtZW50OiBmYWxzZSxcbiAgICBuZXh0TW9kdWxlOiAwXG59O1xuY29uc3QgU0VFRF9VU0VSMiA9IHtcbiAgICB1c2VybmFtZTogJ3Rlc3RVc2VyTm90SW5JSVMnLFxuICAgIHBhc3N3b3JkOiAncGFzc3dvcmQnLFxuICAgIGVtYWlsOiAndGVzdFVzZXJOb3RJbklJU0BtZW1waGlzLmVkdScsXG4gICAgZmlyc3ROYW1lOiAnVXNlcicsXG4gICAgbGFzdE5hbWU6ICdUZXN0JyxcbiAgICBvcmcgOiBcImFsa3NkamhmYXNsa2RcIixcbiAgICBzdXBlcnZpc29ySUQ6IFwiMFwiLFxuICAgIHJvbGU6ICd1c2VyJyxcbiAgICBzdXBlcnZpc29ySW52aXRlQ29kZTogbnVsbCxcbiAgICBzZXg6ICdtYWxlJyxcbiAgICBhc3NpZ25lZDogW10sXG4gICAgaGFzQ29tcGxldGVkRmlyc3RBc3Nlc3NtZW50OiBmYWxzZSxcbiAgICBuZXh0TW9kdWxlOiAwXG59O1xuY29uc3QgU0VFRF9VU0VSUyA9IFtTRUVEX0FETUlOLCBTRUVEX1NVUEVSVklTT1IsIFNFRURfVVNFUiwgU0VFRF9VU0VSMl07XG5jb25zdCBTRUVEX1JPTEVTID0gWyd1c2VyJywgJ3N1cGVydmlzb3InLCAnYWRtaW4nXVxuXG4vL0NvbmZpZ3VyZSBQdXNoIE5vdGlmaWNhdGlvbnNcbnNlcnZpY2VBY2NvdW50RGF0YSA9IG51bGw7XG5QdXNoLkNvbmZpZ3VyZSh7XG4gICAgYXBwTmFtZTogJ09qaScsXG4gICAgZmlyZWJhc2VBZG1pbjoge1xuICAgICAgc2VydmljZUFjY291bnREYXRhLFxuICAgICAgZGF0YWJhc2VVUkw6ICdfX19fZmlyZWJhc2VfZGF0YWJhc2VfdXJsX19fXydcbiAgICB9LFxuICAgIGRlZmF1bHRzOiB7XG4gICAgICAvLyAqKioqKioqKiBNZXRlb3IgUHVzaCBNZXNzYWdpbmcgUHJvY2Vzc29yICoqKioqKipcbiAgICAgIHNlbmRCYXRjaFNpemU6IDUsICAgICAgICAgIC8vIENvbmZpZ3VyYWJsZSBudW1iZXIgb2Ygbm90aWZpY2F0aW9ucyB0byBzZW5kIHBlciBiYXRjaFxuICAgICAgc2VuZEludGVydmFsOiAzMDAwLFxuICAgICAga2VlcE5vdGlmaWNhdGlvbnM6IGZhbHNlLCAgLy8gdGhlIGZvbGxvd2luZyBrZWVwcyB0aGUgbm90aWZpY2F0aW9ucyBpbiB0aGUgREJcbiAgICAgIGRlbGF5VW50aWw6IG51bGwsICAgICAgICAgIC8vIERhdGVcbiAgICAgIHNlbmRUaW1lb3V0OiA2MDAwMCwgICAgICAgIC8vIG1pbGlzZWNvbmRzIDYwIHggMTAwMCA9IDEgbWluXG4gIFxuICAgICAgLy8gKioqKioqKiogR2xvYmFsIE1lc3NhZ2UgKioqKioqKlxuICAgICAgYXBwTmFtZTogJ09qaScsICAgICAgICAvLyBTZXJ2ZSBpdCBhcyBhICdmcm9tJyBkZWZhdWx0IGZvciBJT1Mgbm90aWZpY2F0aW9uc1xuICAgICAgc291bmQ6ICdub3RlJywgICAgICAgICAgICAgLy8gU3RyaW5nIChmaWxlIGhhcyB0byBleGlzdCBpbiBhcHAvc3JjL3Jlcy8uLi4gb3IgZGVmYXVsdCBvbiB0aGUgbW9iaWxlIHdpbGwgYmUgdXNlZCkuIEZvciBBbmRyb2lkIG5vIGV4dGVuc2lvbiwgZm9yIElPUyBhZGQgJy5jYWYnXG4gICAgICBkYXRhOiBudWxsLCAgICAgICAgICAgICAgICAvLyBHbG9iYWwgRGF0YSBvYmplY3QgLSBhcHBsaWVzIHRvIGFsbCB2ZW5kb3JzIGlmIHNwZWNpZmljIHZlbmRvciBkYXRhIG9iamVjdCBkb2VzIG5vdCBleGlzdC5cbiAgICAgIGltYWdlVXJsOiAnaHR0cHM6Ly9hX2RlZmF1bHRfaW1hZ2VfdXJsLmpwZycsXG4gICAgICBiYWRnZTogMSwgICAgICAgICAgICAgICAgICAvLyBJbnRlZ2VyXG4gICAgICB2aWJyYXRlOiAxLCAgICAgICAgICAgICAgICAvLyBCb29sZWFuIC8vIFRPRE8gc2VlIGlmIEkgcmVhbGx5IHVzZSB0aGlzLlxuICAgICAgcmVxdWlyZUludGVyYWN0aW9uOiBmYWxzZSwgLy8gVE9ETyBJbXBsZW1lbnQgdGhpcyBhbmQgbW92ZSBpdCB0byB3aGVyZSBpdCBiZWxvbmdzXG4gICAgICBhbmFseXRpY3NMYWJlbDogJ2FjdGl2aXRyZWVPamknLCAgIC8vIEFuZHJvaWQsIElPUzogTGFiZWwgYXNzb2NpYXRlZCB3aXRoIHRoZSBtZXNzYWdlJ3MgYW5hbHl0aWNzIGRhdGEuXG4gIFxuICAgICAgLy8gKioqKioqKiBJT1MgU3BlY2lmaWNzICoqKioqKlxuICAgICAgYXBuc1ByaW9yaXR5OiAnMTAnLFxuICAgICAgdG9waWM6ICdjb20uYWN0aXZpdHJlZScsICAgLy8gU3RyaW5nID0gdGhlIElPUyBBcHAgaWRcbiAgICAgIGxhdW5jaEltYWdlOiAnJywgICAgICAgICAgIC8vIElPUzogU3RyaW5nXG4gICAgICBpb3NEYXRhOiBudWxsLCAgICAgICAgICAgICAvLyBEYXRhIG9iamVjdCB0YXJnZXRlZCB0byB0aGUgSU9TIG5vdGlmaWNhdGlvblxuICBcbiAgICAgIC8vICoqKioqKiogQW5kcm9pZCBTcGVjaWZpY2FzICoqKioqKipcbiAgICAgIGljb246ICdzdGF0dXNiYXJpY29uJywgICAgIC8vIFN0cmluZyAobmFtZSBvZiBpY29uIGZvciBBbmRyb2lkIGhhcyB0byBleGlzdCBpbiBhcHAvc3JjL3Jlcy8uLi4uKVxuICAgICAgY29sb3I6ICcjMzM3RkFFJywgICAgICAgICAgLy8gU3RyaW5nIGUuZyAzIHJyZ2diYlxuICAgICAgdHRsOiAnODY0MDBzJywgICAgICAgICAgICAgLy8gaWYgbm90IHNldCwgdXNlIGRlZmF1bHQgbWF4IG9mIDQgd2Vla3NcbiAgICAgIHByaW9yaXR5OiAnSElHSCcsICAgICAgICAgIC8vIEFuZHJvaWQ6IG9uZSBvZiBOT1JNQUwgb3IgSElHSFxuICAgICAgbm90aWZpY2F0aW9uUHJpb3JpdHk6ICdQUklPUklUWV9ERUZBVUxUJywgLy8gQW5kcm9pZDogb25lIG9mIG5vbmUsIG9yIFBSSU9SSVRZX01JTiwgUFJJT1JJVFlfTE9XLCBQUklPUklUWV9ERUZBVUxULCBQUklPUklUWV9ISUdILCBQUklPUklUWV9NQVhcbiAgICAgIGNvbGxhcHNlS2V5OiAxLCAgICAgICAgICAgIC8vIFN0cmluZy8gSW50ZWdlcj8/LCBBbmRyb2lkOiAgQSBtYXhpbXVtIG9mIDQgZGlmZmVyZW50IGNvbGxhcHNlIGtleXMgaXMgYWxsb3dlZCBhdCBhbnkgZ2l2ZW4gdGltZS5cbiAgICAgIGFuZHJvaWREYXRhOiBudWxsLCAgICAgICAgICAgLy8gRGF0YSBvYmplY3QgdGFyZ2V0ZWQgdG8gdGhlIEFuZHJvaWQgbm90aWZmaWNhdGlvblxuICAgICAgdmlzaWJpbGl0eTogJ1BSSVZBVEUnLCAvLyBBbmRyb2lkOiBPbmUgb2YgJ1BSSVZBVEUnLCAnUFVCTElDJywgJ1NFQ1JFVCcuIERlZmF1bHQgaXMgJ1BSSVZBVEUnLFxuICBcbiAgICAgIC8vICoqKioqKiogV2ViIFNwZWNpZmljcyAqKioqKioqXG4gICAgICB3ZWJJY29uOiAnaHR0cHM6Ly9saW5rX3RvX3lvdXJfbG9nby5qcGcnLFxuICAgICAgd2ViRGF0YTogbnVsbCwgICAgICAgICAgICAgICAgIC8vIERhdGEgb2JqZWN0IHRhcmdldGVkIHRvIHRoZSBXZWIgbm90aWZpY2F0aW9uXG4gICAgICB3ZWJUVEw6IGAkezM2MDAgKiAxMDAwfWAgICAgICAgLy8gTnVtYmVyIG9mIHNlY29uZHMgYXMgYSBzdHJpbmdcbiAgICB9XG4gIH0pXG5cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgIFxuICAgIC8vSXJvbiBSb3V0ZXIgQXBpXG4gICAgUm91dGVyLnJvdXRlKCcvYXBpJyx7XG4gICAgd2hlcmU6IFwic2VydmVyXCIsXG4gICAgYWN0aW9uOiBmdW5jdGlvbiAoKXtcbiAgICAgICAgdGhpcy5yZXNwb25zZS53cml0ZUhlYWQoMjAwLCB7XG4gICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICAgICAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJ1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5yZXF1ZXN0LmhlYWRlcnMpO1xuICAgICAgICB1c2VybmFtZSA9IHRoaXMucmVxdWVzdC5oZWFkZXJzWyd4LXVzZXItaWQnXTtcbiAgICAgICAgbG9naW5Ub2tlbiA9IHRoaXMucmVxdWVzdC5oZWFkZXJzWyd4LWF1dGgtdG9rZW4nXTtcbiAgICAgICAgdXNlciA9IE1ldGVvci51c2Vycy5maW5kT25lKHt1c2VybmFtZTogdXNlcm5hbWV9KTtcbiAgICAgICAgaXNUb2tlbkV4cGlyZWQgPSB0cnVlO1xuICAgICAgICBrZXlzID0gdXNlci5hcGk7XG4gICAgICAgIG5vdyA9IG5ldyBEYXRlKCk7XG4gICAgICAgIGV4cERhdGUgPSBrZXlzLmV4cGlyZXM7XG4gICAgICAgIGV4cERhdGUuc2V0RGF0ZShleHBEYXRlLmdldERhdGUoKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKCdkYXRlJywgbm93LCBleHBEYXRlLCBrZXlzLmV4cGlyZXMpO1xuICAgICAgICBpZihub3cgPCBleHBEYXRlKXtcbiAgICAgICAgICAgIGlzVG9rZW5FeHBpcmVkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYoIXVzZXIgfHwgdXNlci5hcGkudG9rZW4gIT0gbG9naW5Ub2tlbiB8fCBpc1Rva2VuRXhwaXJlZCA9PSB0cnVlKXtcbiAgICAgICAgICAgIHRoaXMucmVzcG9uc2UuZW5kKFwie3N1Y2VzczogZmFsc2UsIG1lc3NhZ2U6ICdpbmNvcnJlY3QgdXNlcm5hbWUgb3IgZXhwaXJlZCB0b2tlbid9XCIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb3JnYW5pemF0aW9uID0gT3Jncy5maW5kT25lKHtvcmdPd25lcklkOiB1c2VyLl9pZH0pO1xuICAgICAgICAgICAgdXNlcmxpc3QgPSBNZXRlb3IudXNlcnMuZmluZCh7b3JnYW5pemF0aW9uOiBvcmdhbml6YXRpb24uX2lkfSwge1xuICAgICAgICAgICAgICAgIGZpZWxkczoge1xuICAgICAgICAgICAgICAgICAgICBmaXJzdG5hbWU6IDAsXG4gICAgICAgICAgICAgICAgICAgIGxhc3RuYW1lOiAwLFxuICAgICAgICAgICAgICAgICAgICBlbWFpbHM6IDAsXG4gICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiAwLFxuICAgICAgICAgICAgICAgICAgICByb2xlOiAwLFxuICAgICAgICAgICAgICAgICAgICBzdXBlcnZpc29ySW52aXRlQ29kZTogMCxcbiAgICAgICAgICAgICAgICAgICAgc2VydmljZXM6IDAsXG4gICAgICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbjogMCxcbiAgICAgICAgICAgICAgICAgICAgYXBpOiAwXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLmZldGNoKCk7XG4gICAgICAgICAgICB1c2VyTGlzdFJlc3BvbnNlID0gW11cbiAgICAgICAgICAgIGZvcihpID0gMDsgaSA8IHVzZXJsaXN0Lmxlbmd0aDsgaSsrKXtcbiAgICAgICAgICAgICAgICB1c2VyVHJpYWxzID0gVHJpYWxzLmZpbmQoe3VzZXJJZDogdXNlcmxpc3RbaV0uX2lkfSkuZmV0Y2goKTtcbiAgICAgICAgICAgICAgICB1c2VyTW9kdWxlcyA9IE1vZHVsZXMuZmluZCh7dXNlcklkOiB1c2VybGlzdFtpXS5faWR9KS5mZXRjaCgpO1xuICAgICAgICAgICAgICAgIGN1clVzZXIgPSB1c2VybGlzdFtpXTtcbiAgICAgICAgICAgICAgICBjdXJVc2VyLnRyaWFscyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodXNlclRyaWFscykpO1xuICAgICAgICAgICAgICAgIGN1clVzZXIubW9kdWxlcyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkodXNlck1vZHVsZXMpKTtcbiAgICAgICAgICAgICAgICB1c2VyTGlzdFJlc3BvbnNlLnB1c2goY3VyVXNlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcmdhbml6YXRpb24udXNlcnMgPSB1c2VyTGlzdFJlc3BvbnNlO1xuICAgICAgICAgICAgdGhpcy5yZXNwb25zZS5lbmQoSlNPTi5zdHJpbmdpZnkob3JnYW5pemF0aW9uKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgfSk7XG5cbiAgICAvL2xvYWQgZGVmYXVsdCBKU09OIGFzc2Vzc21lbnQgaW50byBtb25nbyBjb2xsZWN0aW9uXG4gICAgaWYoQXNzZXNzbWVudHMuZmluZCgpLmNvdW50KCkgPT09IDApe1xuICAgICAgICBjb25zb2xlLmxvZygnSW1wb3J0aW5nIERlZmF1bHQgQXNzZXNzbWVudHMgaW50byBNb25nby4nKVxuICAgICAgICB2YXIgZGF0YSA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQoJ2RlZmF1bHRBc3Nlc3NtZW50cy5qc29uJykpO1xuICAgICAgICBmb3IgKHZhciBpID0wOyBpIDwgZGF0YVsnYXNzZXNzbWVudHMnXS5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICBhc3Nlc3NtZW50ID0gZGF0YVsnYXNzZXNzbWVudHMnXVtpXVsnYXNzZXNzbWVudCddO1xuICAgICAgICAgICAgQXNzZXNzbWVudHMuaW5zZXJ0KGFzc2Vzc21lbnQpO1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8vbG9hZCBkZWZhdWx0IEpTT04gbW9kdWxlcyBpbnRvIG1vbmdvIGNvbGxlY3Rpb25cbiAgICBpZihNb2R1bGVzLmZpbmQoKS5jb3VudCgpID09PSAwKXtcbiAgICAgICAgY29uc29sZS5sb2coJ0ltcG9ydGluZyBEZWZhdWx0IE1vZHVsZXMgaW50byBNb25nby4nKVxuICAgICAgICB2YXIgZGF0YSA9IEpTT04ucGFyc2UoQXNzZXRzLmdldFRleHQoJ2RlZmF1bHRNb2R1bGVzLmpzb24nKSk7XG4gICAgICAgIGZvciAodmFyIGkgPTA7IGkgPCBkYXRhWydtb2R1bGVzJ10ubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAgbmV3TW9kdWxlID0gZGF0YVsnbW9kdWxlcyddW2ldWydtb2R1bGUnXTtcbiAgICAgICAgICAgIE1vZHVsZXMuaW5zZXJ0KG5ld01vZHVsZSk7XG4gICAgICAgIH07XG4gICAgfVxuXG4gICAgLy9jcmVhdGUgc2VlZCByb2xlc1xuICAgIGZvcihsZXQgcm9sZSBvZiBTRUVEX1JPTEVTKXtcbiAgICAgICAgaWYoIU1ldGVvci5yb2xlcy5maW5kT25lKHsgJ19pZCcgOiByb2xlIH0pKXtcbiAgICAgICAgICAgIFJvbGVzLmNyZWF0ZVJvbGUocm9sZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgbGV0IG5ld09yZ0lkO1xuICAgIC8vY3JlYXRlIHNlZWQgdXNlclxuICAgIGZvcihsZXQgdXNlciBvZiBTRUVEX1VTRVJTKXtcbiAgICAgICAgaWYgKCFBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUodXNlci51c2VybmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHVpZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIoe1xuICAgICAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VyLnVzZXJuYW1lLFxuICAgICAgICAgICAgICAgIHBhc3N3b3JkOiB1c2VyLnBhc3N3b3JkLFxuICAgICAgICAgICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGFkZFVzZXJUb1JvbGVzKHVpZCwgdXNlci5yb2xlKTtcbiAgICAgICAgICAgIGlmKHVzZXIucm9sZSA9PSBcImFkbWluXCIpe1xuICAgICAgICAgICAgICAgIE9yZ3MuaW5zZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgb3JnTmFtZTogXCJJSVNcIixcbiAgICAgICAgICAgICAgICAgICAgb3JnT3duZXJJZDogdWlkLFxuICAgICAgICAgICAgICAgICAgICBvcmdEZXNjOiBcIlRlc3RpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgbmV3VXNlckFzc2lnbm1lbnRzOiBbXVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIG5ld09yZ0lkID0gT3Jncy5maW5kT25lKHtvcmdPd25lcklkOiB1aWR9KS5faWQ7XG4gICAgICAgICAgICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgbGV0IG1vbnRoID0gZC5nZXRNb250aCgpOyBcbiAgICAgICAgICAgICAgICBsZXQgZGF5ID0gZC5nZXREYXRlKCk7XG4gICAgICAgICAgICAgICAgbGV0IHllYXIgPSBkLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgICAgICAgICAgbGV0IHRpdGxlID0gXCJ0ZXN0IGV2ZW50XCI7XG4gICAgICAgICAgICAgICAgRXZlbnRzLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwib3JnXCIsXG4gICAgICAgICAgICAgICAgICAgIG9yZzogbmV3T3JnSWQsXG4gICAgICAgICAgICAgICAgICAgIG1vbnRoOiBtb250aCxcbiAgICAgICAgICAgICAgICAgICAgZGF5OiBkYXksXG4gICAgICAgICAgICAgICAgICAgIHllYXI6IHllYXIsXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiB0aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEJ5OiB1aWRcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBNZXRlb3IuY2FsbCgnZ2VuZXJhdGVJbnZpdGUnLHVpZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCBzdXBlcnZpc29ySUQgPSAnJztcbiAgICAgICAgICAgIGlmKHVzZXIudXNlcm5hbWUgPT0gJ3Rlc3RVc2VyJyl7XG4gICAgICAgICAgICAgICAgc3VwZXJ2aXNvcklEID0gIEFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZShTRUVEX1NVUEVSVklTT1IudXNlcm5hbWUpLl9pZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6IHVpZCB9LCBcbiAgICAgICAgICAgICAgICB7ICAgJHNldDpcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V4OiB1c2VyLnNleCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpcnN0bmFtZTogdXNlci5maXJzdE5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBsYXN0bmFtZTogdXNlci5sYXN0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1cGVydmlzb3I6IHN1cGVydmlzb3JJRCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbjogdXNlci5vcmcgPyB1c2VyLm9yZzogbmV3T3JnSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXg6IHVzZXIuc2V4LFxuICAgICAgICAgICAgICAgICAgICAgICAgYXNzaWduZWQ6IHVzZXIuYXNzaWduZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNDb21wbGV0ZWRGaXJzdEFzc2Vzc21lbnQ6IHVzZXIuaGFzQ29tcGxldGVkRmlyc3RBc3Nlc3NtZW50LFxuICAgICAgICAgICAgICAgICAgICAgICAgbmV4dE1vZHVsZTogMFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG4vL0dsb2JhbCBNZXRob2RzXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgZ2V0SW52aXRlSW5mbyxcbiAgICBjcmVhdGVOZXdVc2VyOiBmdW5jdGlvbih1c2VyLCBwYXNzLCBlbWFpbEFkZHIsIGZpcnN0TmFtZSwgbGFzdE5hbWUsIHNleCwgZ2VuZGVyLCBsaW5rSWQ9XCJcIil7XG4gICAgICAgIGlmKGxpbmtJZCl7XG4gICAgICAgICAgICB2YXIge3RhcmdldE9yZ0lkLCB0YXJnZXRPcmdOYW1lLCB0YXJnZXRTdXBlcnZpc29ySWQsIHRhcmdldFN1cGVydmlzb3JOYW1lfSA9IGdldEludml0ZUluZm8obGlua0lkKTsgICAgXG4gICAgICAgICAgICB2YXIgb3JnYW5pemF0aW9uID0gT3Jncy5maW5kT25lKHtfaWQ6IHRhcmdldE9yZ0lkfSk7ICAgICAgICAgIFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIHRhcmdldE9yZ0lkID0gbnVsbFxuICAgICAgICAgICAgdmFyIHRhcmdldFN1cGVydmlzb3JJZCA9IG51bGw7ICBcbiAgICAgICAgICAgIHZhciBvcmdhbml6YXRpb24gPSB7bmV3VXNlckFzc2lnbm1lbnRzOiBbXX07ICAgXG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUodXNlcikpIHtcbiAgICAgICAgICAgIGlmICghQWNjb3VudHMuZmluZFVzZXJCeUVtYWlsKGVtYWlsQWRkcikpe1xuICAgICAgICAgICAgICAgIGNvbnN0IHVpZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIoe1xuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTogdXNlcixcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHBhc3MsXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiBlbWFpbEFkZHJcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiB1aWQgfSwgXG4gICAgICAgICAgICAgICAgICAgIHsgICAkc2V0OiBcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXg6IHNleCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaXJzdG5hbWU6IGZpcnN0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXN0bmFtZTogbGFzdE5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3JnYW5pemF0aW9uOiB0YXJnZXRPcmdJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdXBlcnZpc29yOiB0YXJnZXRTdXBlcnZpc29ySWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VwZXJ2aXNvckludml0ZUNvZGU6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFzQ29tcGxldGVkRmlyc3RBc3Nlc3NtZW50OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZW5kZXI6IGdlbmRlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25lZDogb3JnYW5pemF0aW9uLm5ld1VzZXJBc3NpZ25tZW50cyB8fCBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXh0TW9kdWxlOiAwXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGlmKGxpbmtJZCAhPSBcIlwiKXtcbiAgICAgICAgICAgICAgICAgICAgYWRkVXNlclRvUm9sZXModWlkLCAndXNlcicpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGFkZFVzZXJUb1JvbGVzKHVpZCwgJ2FkbWluJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZXtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yICgndXNlci1hbHJlYWR5LWV4aXN0cycsIGBFbWFpbCAke2VtYWlsQWRkcn0gYWxyZWFkeSBpbiB1c2VgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvciAoJ3VzZXItYWxyZWFkeS1leGlzdHMnLCBgVXNlciAke3VzZXJ9IGFscmVhZHkgZXhpc3RzYCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIGNyZWF0ZU9yZ2FuaXphdGlvbjogZnVuY3Rpb24obmV3T3JnTmFtZSwgbmV3T3JnT3duZXIsIG5ld09yZ0Rlc2Mpe1xuICAgICAgICBhbGxBc3Nlc3NtZW50cyA9IEFzc2Vzc21lbnRzLmZpbmQoKS5mZXRjaCgpO1xuICAgICAgICBuZXdVc2VyQXNzaWdubWVudHMgPSBbXTtcbiAgICAgICAgZm9yKGk9MDsgaTxhbGxBc3Nlc3NtZW50cy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICBuZXdVc2VyQXNzaWdubWVudHMucHVzaChhbGxBc3Nlc3NtZW50c1tpXS5faWQpO1xuICAgICAgICB9XG4gICAgICAgIE9yZ3MuaW5zZXJ0KHtcbiAgICAgICAgICAgIG9yZ05hbWU6IG5ld09yZ05hbWUsXG4gICAgICAgICAgICBvcmdPd25lcklkOiBuZXdPcmdPd25lcixcbiAgICAgICAgICAgIG9yZ0Rlc2M6IG5ld09yZ0Rlc2MsXG4gICAgICAgICAgICBuZXdVc2VyQXNzaWdubWVudHM6IG5ld1VzZXJBc3NpZ25tZW50c1xuICAgICAgICB9KTtcbiAgICAgICAgbmV3T3JnSWQgPSBPcmdzLmZpbmRPbmUoe29yZ093bmVySWQ6IG5ld09yZ093bmVyfSkuX2lkO1xuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiBuZXdPcmdPd25lciB9LCBcbiAgICAgICAgICAgIHsgICAkc2V0OiBcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG9yZ2FuaXphdGlvbjogbmV3T3JnSWQsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gICAgZ2VuZXJhdGVJbnZpdGU6IGZ1bmN0aW9uKHN1cGVydmlzb3JJZCl7XG4gICAgICAgIHZhciBsaW5rID0gJyc7XG4gICAgICAgIHZhciBsZW5ndGggPSAxNjtcbiAgICAgICAgdmFyIGNoYXJhY3RlcnMgICAgICAgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODknO1xuICAgICAgICB2YXIgY2hhcmFjdGVyc0xlbmd0aCA9IGNoYXJhY3RlcnMubGVuZ3RoO1xuICAgICAgICB2YXIgdW5pcXVlID0gZmFsc2U7XG4gICAgICAgIHdoaWxlKHVuaXF1ZSA9PSBmYWxzZSl7O1xuICAgICAgICAgICAgZm9yICggdmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKysgKSB7XG4gICAgICAgICAgICAgICAgbGluayArPSBjaGFyYWN0ZXJzLmNoYXJBdChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjaGFyYWN0ZXJzTGVuZ3RoKSk7XG4gICAgICAgICAgICB9ICBcbiAgICAgICAgICAgIGxpbmtGb3VuZCA9IE1ldGVvci51c2Vycy5maW5kKHtzdXBlcnZpc29ySW52aXRlQ29kZTogbGlua30pLmZldGNoKCkubGVuZ3RoOyBcbiAgICAgICAgICAgIGlmKGxpbmtGb3VuZCA9PSAwKXtcbiAgICAgICAgICAgICAgICB1bmlxdWUgPSB0cnVlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBsaW5rID0gXCJcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHsgX2lkOiBzdXBlcnZpc29ySWQgfSwgXG4gICAgICAgIHsgICAkc2V0OiBcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBzdXBlcnZpc29ySW52aXRlQ29kZTogbGlua1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGxpbms7XG4gICAgfSxcbiAgICBkZXN0cm95VXNlcjogZnVuY3Rpb24odXNlcklEKSB7XG4gICAgICAgIGlmKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSl7XG4gICAgICAgICAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHVzZXJJRCk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIHJlbW92ZVN1cGVydmlzb3I6IGZ1bmN0aW9uKHVzZXJJZCl7XG4gICAgICAgIC8vcmVtb3ZlcyBhIHVzZXIgZnJvbSBzdXBlcnZpc29ycyBsaXN0IGlmIGFkZGVkIGJ5IG1pc3Rha2UuIFxuICAgICAgICBpZihSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdhZG1pbicpKXtcbiAgICAgICAgICAgIGFkZFVzZXJUb1JvbGVzKHVzZXJJZCwgJ3VzZXInKTtcbiAgICAgICAgICAgIHJlbW92ZVVzZXJGcm9tUm9sZXModXNlcklkLCAnc3VwZXJ2aXNvcicpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICBlZGl0U3VwZXJ2aXNvcjogZnVuY3Rpb24oc3VwZXJ2aXNvcklEKSB7XG4gICAgICAgIGlmKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbiddKSl7XG5cbiAgICAgICAgfVxuICAgIH0sXG4gICAgYWRkU3VwZXJ2aXNvcjogZnVuY3Rpb24odXNlcklkKSB7XG4gICAgICAgIC8vZWxldmF0ZSB1c2VyIHdpdGggdXNlciByb2xlIHRvIHN1cGVydmlzb3JcbiAgICAgICAgaWYoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnYWRtaW4nKSl7XG4gICAgICAgICAgICBhZGRVc2VyVG9Sb2xlcyh1c2VySWQsICdzdXBlcnZpc29yJyk7XG4gICAgICAgICAgICByZW1vdmVVc2VyRnJvbVJvbGVzKHVzZXJJZCwgJ3VzZXInKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY2hhbmdlQXNzaWdubWVudFRvTmV3VXNlcnM6IGZ1bmN0aW9uKGFzc2lnbm1lbnQpe1xuICAgICAgICBPcmdzLnVwc2VydCh7X2lkOiBNZXRlb3IudXNlcigpLm9yZ2FuaXphdGlvbn0seyRzZXQ6IHtuZXdVc2VyQXNzaWdubWVudHM6IGFzc2lnbm1lbnR9fSk7XG4gICAgfSxcbiAgICBhc3NpZ25Ub0FsbFVzZXJzOiBmdW5jdGlvbihhc3NpZ25tZW50KXtcbiAgICAgICAgb3JnID0gTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb247XG4gICAgICAgIGFsbFVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoe29yZ2FuaXphdGlvbjogb3JnLCByb2xlOiAndXNlcid9KS5mZXRjaCgpO1xuICAgICAgICBmb3IoaSA9IDA7IGkgPCBhbGxVc2Vycy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICBjdXJBc3NpZ25tZW50cyA9IGFsbFVzZXJzW2ldLmFzc2lnbmVkO1xuICAgICAgICAgICAgaWYoIWN1ckFzc2lnbm1lbnRzLmluY2x1ZGVzKGFzc2lnbm1lbnQpKXtcbiAgICAgICAgICAgICAgICBjdXJBc3NpZ25tZW50cy5wdXNoKGFzc2lnbm1lbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwc2VydCh7X2lkOiBhbGxVc2Vyc1tpXS5faWR9LCB7JHNldDoge2Fzc2lnbmVkOiBjdXJBc3NpZ25tZW50c319KTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgY2hhbmdlQXNzaWdubWVudE9uZVVzZXI6IGZ1bmN0aW9uKGlucHV0KXtcbiAgICAgICAgdXNlcklkID0gaW5wdXRbMF07XG4gICAgICAgIGFzc2lnbm1lbnQgPSBpbnB1dFsxXTtcbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwc2VydCh7X2lkOiB1c2VySWR9LHskc2V0OiB7YXNzaWduZWQ6IGFzc2lnbm1lbnR9fSk7XG4gICAgfSxcblxuICAgIC8vYXNzZXNzbWVudCBkYXRhIGNvbGxlY3Rpb25cbiAgICBzYXZlQXNzZXNzbWVudERhdGE6IGZ1bmN0aW9uKG5ld0RhdGEpe1xuICAgICAgICB0cmlhbElkID0gbmV3RGF0YS50cmlhbElkO1xuICAgICAgICBhc3Nlc3NtZW50SWQgPSBuZXdEYXRhLmFzc2Vzc21lbnRJZFxuICAgICAgICBhc3Nlc3NtZW50TmFtZSA9IG5ld0RhdGEuYXNzZXNzbWVudE5hbWVcbiAgICAgICAgdXNlcklkID0gTWV0ZW9yLnVzZXJJZCgpO1xuICAgICAgICBxdWVzdGlvbklkID0gbmV3RGF0YS5xdWVzdGlvbklkO1xuICAgICAgICBvbGRSZXN1bHRzID0gVHJpYWxzLmZpbmRPbmUoe19pZDogdHJpYWxJZH0pO1xuICAgICAgICBsZXQgaWRlbnRpZmllcjtcbiAgICAgICAgXG4gICAgICAgIGlmKHR5cGVvZiBvbGRSZXN1bHRzID09PSBcInVuZGVmaW5lZFwiKXtcbiAgICAgICAgICAgIGRhdGEgPSBbXTtcbiAgICAgICAgICAgIHN1YnNjYWxlVG90YWxzID0ge307XG4gICAgICAgICAgICBpZGVudGlmaWVyID0gbmV3RGF0YS5pZGVudGlmaWVyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZGF0YSA9IG9sZFJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgIHN1YnNjYWxlVG90YWxzID0gb2xkUmVzdWx0cy5zdWJzY2FsZVRvdGFscztcbiAgICAgICAgICAgIGlkZW50aWZpZXIgPSBvbGRSZXN1bHRzLmlkZW50aWZpZXI7XG4gICAgICAgIH1cbiAgICAgICAgZGF0YVtuZXdEYXRhLnF1ZXN0aW9uSWRdID0ge1xuICAgICAgICAgICAgcmVzcG9uc2U6IG5ld0RhdGEucmVzcG9uc2UsXG4gICAgICAgICAgICByZXNwb25zZVZhbHVlOiBuZXdEYXRhLnJlc3BvbnNlVmFsdWUsXG4gICAgICAgICAgICBzdWJzY2FsZXM6IG5ld0RhdGEuc3Vic2NhbGVzXG4gICAgICAgIH1cbiAgICAgICAgLy9zdW0gdGhlIHJlc3BvbnNlIHZhbHVlcyBieSBzdWJzY2FsZSBmb3IgZGF0YSByZXBvcnRpbmdcbiAgICAgICAgaWYoIW5ld0RhdGEuc3Vic2NhbGVzKXtcbiAgICAgICAgICAgIC8vY3VycmVudCBhc3Nlc3NtZW50IGRvZXNudCB1c2Ugc3Vic2NhbGVzLCBqdXN0IHRhbGx5IHRoZSB0b3RhbGxzXG4gICAgICAgICAgICBpZihzdWJzY2FsZVRvdGFsc1snZGVmYXVsdCddKXtcbiAgICAgICAgICAgICAgICBzdWJzY2FsZVRvdGFsc1snZGVmYXVsdCddICs9IG5ld0RhdGEucmVzcG9uc2VWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgc3Vic2NhbGVUb3RhbHNbJ2RlZmF1bHQnXSA9IG5ld0RhdGEucmVzcG9uc2VWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IobGV0IHN1YnNjYWxlIG9mIG5ld0RhdGEuc3Vic2NhbGVzKXtcbiAgICAgICAgICAgIGlmKHN1YnNjYWxlVG90YWxzW3N1YnNjYWxlXSl7XG4gICAgICAgICAgICAgICAgc3Vic2NhbGVUb3RhbHNbc3Vic2NhbGVdICs9IG5ld0RhdGEucmVzcG9uc2VWYWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgc3Vic2NhbGVUb3RhbHNbc3Vic2NhbGVdID0gbmV3RGF0YS5yZXNwb25zZVZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciBvdXRwdXQgPSBUcmlhbHMudXBzZXJ0KHtfaWQ6IHRyaWFsSWR9LCB7JHNldDoge3VzZXJJZDogdXNlcklkLCBhc3Nlc3NtZW50SWQ6IGFzc2Vzc21lbnRJZCwgYXNzZXNzbWVudE5hbWU6IGFzc2Vzc21lbnROYW1lLCBsYXN0QWNjZXNzZWQ6IG5ldyBEYXRlKCksIGlkZW50aWZpZXI6IGlkZW50aWZpZXIsIGRhdGE6IGRhdGEsIHN1YnNjYWxlVG90YWxzOiBzdWJzY2FsZVRvdGFsc319KTtcblxuICAgICAgICBpZih0eXBlb2Ygb3V0cHV0Lmluc2VydGVkSWQgPT09IFwidW5kZWZpbmVkXCIpe1xuICAgICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VySWQsIHtcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICBjdXJUcmlhbDoge1xuICAgICAgICAgICAgICAgICAgICAgIHRyaWFsSWQ6IHRyaWFsSWQsXG4gICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25JZDogcXVlc3Rpb25JZCArIDFcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHRyaWFsSWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBNZXRlb3IudXNlcnMudXBkYXRlKHVzZXJJZCwge1xuICAgICAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgY3VyVHJpYWw6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyaWFsSWQ6IG91dHB1dC5pbnNlcnRlZElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgcXVlc3Rpb25JZDogMVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBvdXRwdXQuaW5zZXJ0ZWRJZDtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgZW5kQXNzZXNzbWVudDogZnVuY3Rpb24odHJpYWxJZCkge1xuICAgICAgICBsZXQgdHJpYWwgPSBUcmlhbHMuZmluZE9uZSh7J19pZCc6IHRyaWFsSWR9KTtcbiAgICAgICAgY29uc3QgYWRqdXN0ZWRTY29yZXMgPSBjYWxjdWxhdGVTY29yZXModHJpYWwuaWRlbnRpZmllciwgdHJpYWwuc3Vic2NhbGVUb3RhbHMsIE1ldGVvci51c2VyKCkuc2V4KVxuICAgICAgICBpZihhZGp1c3RlZFNjb3JlcylcbiAgICAgICAgICAgIFRyaWFscy51cHNlcnQoe19pZDogdHJpYWxJZH0sIHskc2V0OiB7c3Vic2NhbGVUb3RhbHM6IGFkanVzdGVkU2NvcmVzfX0pO1xuICAgIH0sXG4gICAgY2xlYXJBc3Nlc3NtZW50UHJvZ3Jlc3M6IGZ1bmN0aW9uICgpe1xuICAgICAgICB1c2VySWQgPSBNZXRlb3IudXNlcklkKCk7XG5cbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZSh1c2VySWQsIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgY3VyVHJpYWw6IHtcbiAgICAgICAgICAgICAgICAgIHRyaWFsSWQ6IDAsXG4gICAgICAgICAgICAgICAgICBxdWVzdGlvbklkOiAwXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICB9LFxuICAgIGNyZWF0ZU5ld01vZHVsZVRyaWFsOiBmdW5jdGlvbihkYXRhKXtcbiAgICAgICAgY29uc3QgcmVzdWx0cyA9IE1vZHVsZVJlc3VsdHMuaW5zZXJ0KGRhdGEpO1xuICAgICAgICAgICAgTWV0ZW9yLnVzZXJzLnVwZGF0ZShNZXRlb3IudXNlcklkKCksIHtcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgY3VyTW9kdWxlOiB7XG4gICAgICAgICAgICAgICAgICAgIG1vZHVsZUlkOiByZXN1bHRzLFxuICAgICAgICAgICAgICAgICAgICBwYWdlSWQ6IDAsXG4gICAgICAgICAgICAgICAgICAgIHF1ZXN0aW9uSWQ6IDAsXG4gICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgfSxcbiAgICBzYXZlTW9kdWxlRGF0YTogZnVuY3Rpb24gKG1vZHVsZURhdGEpe1xuICAgICAgICBNb2R1bGVSZXN1bHRzLnVwc2VydCh7X2lkOiBtb2R1bGVEYXRhLl9pZH0sIHskc2V0OiBtb2R1bGVEYXRhfSk7XG4gICAgICAgIG5leHRNb2R1bGUgPSBNZXRlb3IudXNlcnMuZmluZE9uZSh7X2lkOiBNZXRlb3IudXNlcklkKCl9KS5uZXh0TW9kdWxlO1xuICAgICAgICBpZihtb2R1bGVEYXRhLnBhZ2VJZCA9PSAnY29tcGxldGVkJyl7XG4gICAgICAgICAgICBuZXh0TW9kdWxlKys7XG4gICAgICAgIH1cbiAgICAgICAgTWV0ZW9yLnVzZXJzLnVwc2VydChNZXRlb3IudXNlcklkKCksIHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgIGN1ck1vZHVsZToge1xuICAgICAgICAgICAgICAgIG1vZHVsZUlkOiBNZXRlb3IudXNlcigpLmN1ck1vZHVsZS5tb2R1bGVJZCxcbiAgICAgICAgICAgICAgICBwYWdlSWQ6IG1vZHVsZURhdGEubmV4dFBhZ2UsXG4gICAgICAgICAgICAgICAgcXVlc3Rpb25JZDogbW9kdWxlRGF0YS5uZXh0UXVlc3Rpb24sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbmV4dE1vZHVsZTogbmV4dE1vZHVsZVxuICAgICAgICB9XG4gICAgfSlcbn0sXG4gICAgZ2V0UHJpdmF0ZUltYWdlOiBmdW5jdGlvbihmaWxlTmFtZSl7XG4gICAgICAgIHJlc3VsdCA9ICBBc3NldHMuYWJzb2x1dGVGaWxlUGF0aChmaWxlTmFtZSk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSxcbiAgICBnZW5lcmF0ZUFwaVRva2VuOiBmdW5jdGlvbih1c2VySWQpe1xuICAgICAgICB2YXIgbmV3VG9rZW4gPSBcIlwiO1xuICAgICAgICB2YXIgY2hhcmFjdGVycyA9ICdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSc7XG4gICAgICAgIHZhciBjaGFyYWN0ZXJzTGVuZ3RoID0gY2hhcmFjdGVycy5sZW5ndGg7XG4gICAgICAgIGZvciAoIHZhciBpID0gMDsgaSA8IDE2OyBpKysgKSB7XG4gICAgICAgICAgICBuZXdUb2tlbiArPSBjaGFyYWN0ZXJzLmNoYXJBdChNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjaGFyYWN0ZXJzTGVuZ3RoKSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGZ1dHVyZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIGZ1dHVyZS5zZXREYXRlKGZ1dHVyZS5nZXREYXRlKCkgKyAzMCk7XG4gICAgICAgIE1ldGVvci51c2Vycy51cGRhdGUodXNlcklkLCB7XG4gICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgIGFwaToge1xuICAgICAgICAgICAgICAgICAgdG9rZW46IG5ld1Rva2VuLFxuICAgICAgICAgICAgICAgICAgZXhwaXJlczogZnV0dXJlXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBjYWxjT3JnU3RhdHM6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHVzZXJzID0gTWV0ZW9yLnVzZXJzLmZpbmQoe29yZ2FuaXphdGlvbjogTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb259KS5mZXRjaCgpO1xuICAgICAgICBzdWJzY2FsZXMgPSBbXTtcbiAgICAgICAgc3Vic2NhbGVMaXN0ID0gW107XG4gICAgICAgIGRhdGEgPSB7fTtcbiAgICAgICAgZGF0YS51c2VyQ291bnQgPSB1c2Vycy5sZW5ndGg7XG4gICAgICAgIGRhdGEuYXNzZXNzbWVudENvdW50ID0gMDtcbiAgICAgICAgZGF0YS5tb2R1bGVDb3VudCA9IDA7XG4gICAgICAgIHN1YnNjYWxlRGF0YSA9IFtdO1xuICAgICAgICBmb3IoaSA9IDA7IGkgPCB1c2Vycy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICB0cmlhbHMgPSBUcmlhbHMuZmluZCh7XCJ1c2VySWRcIjogdXNlcnNbaV0uX2lkfSkuZmV0Y2goKTtcbiAgICAgICAgICAgIGZvcihqID0gMDsgaiA8IHRyaWFscy5sZW5ndGg7IGorKyl7XG4gICAgICAgICAgICAgICAgZGF0YS5hc3Nlc3NtZW50Q291bnQrKztcbiAgICAgICAgICAgICAgICBmb3IoayA9IDA7IGsgPCBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0cmlhbHNbal0uc3Vic2NhbGVUb3RhbHMpLmxlbmd0aDsgaysrKXtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NhbGUgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0cmlhbHNbal0uc3Vic2NhbGVUb3RhbHMpW2tdO1xuICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZUluZGV4ID0gc3Vic2NhbGVMaXN0LmluZGV4T2Yoc3Vic2NhbGUpO1xuICAgICAgICAgICAgICAgICAgICBpZihzdWJzY2FsZUluZGV4ID09PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZUxpc3QucHVzaChzdWJzY2FsZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZUluZGV4ID0gc3Vic2NhbGVMaXN0LmluZGV4T2Yoc3Vic2NhbGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NhbGVEYXRhW3N1YnNjYWxlSW5kZXhdID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHN1YnNjYWxlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsbDogW3RyaWFsc1tqXS5zdWJzY2FsZVRvdGFsc1tzdWJzY2FsZV1dLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50OiAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1bTogdHJpYWxzW2pdLnN1YnNjYWxlVG90YWxzW3N1YnNjYWxlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdmc6ICB0cmlhbHNbal0uc3Vic2NhbGVUb3RhbHNbc3Vic2NhbGVdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lZGlhbjogdHJpYWxzW2pdLnN1YnNjYWxlVG90YWxzW3N1YnNjYWxlXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZURhdGFbc3Vic2NhbGVJbmRleF0uYWxsLnB1c2godHJpYWxzW2pdLnN1YnNjYWxlVG90YWxzW3N1YnNjYWxlXSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZURhdGFbc3Vic2NhbGVJbmRleF0uY291bnQrKztcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1YnNjYWxlRGF0YVtzdWJzY2FsZUluZGV4XS5zdW0rPSB0cmlhbHNbal0uc3Vic2NhbGVUb3RhbHNbc3Vic2NhbGVdO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3Vic2NhbGVEYXRhW3N1YnNjYWxlSW5kZXhdLmF2ZyA9IHN1YnNjYWxlRGF0YVtzdWJzY2FsZUluZGV4XS5zdW0gLyBzdWJzY2FsZURhdGFbc3Vic2NhbGVJbmRleF0uY291bnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzb3J0ZWQgPSBzdWJzY2FsZURhdGFbc3Vic2NhbGVJbmRleF0uYWxsLnNsaWNlKCkuc29ydCgoYSwgYikgPT4gYSAtIGIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbWlkZGxlID0gTWF0aC5mbG9vcihzb3J0ZWQubGVuZ3RoIC8gMik7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc29ydGVkLmxlbmd0aCAlIDIgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZWRpYW4gPSAoc29ydGVkW21pZGRsZSAtIDFdICsgc29ydGVkW21pZGRsZV0pIC8gMjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVkaWFuID0gc29ydGVkW21pZGRsZV07XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdWJzY2FsZURhdGFbc3Vic2NhbGVJbmRleF0ubWVkaWFuID0gbWVkaWFuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBkYXRhLnN1YnNjYWxlRGF0YSA9IHN1YnNjYWxlRGF0YTtcbiAgICAgICAgT3Jncy51cHNlcnQoe19pZDogTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb259LHtcbiAgICAgICAgICAgICRzZXQ6IHtcbiAgICAgICAgICAgICAgICBvcmdTdGF0czogZGF0YVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgIH0sXG4gICAgY3JlYXRlRXZlbnQ6IGZ1bmN0aW9uKHR5cGUsIG1vbnRoLCBkYXksIHllYXIsIHRpbWUsIHRpdGxlLCBpbXBvcnRhbmNlKXtcbiAgICAgICAgRXZlbnRzLmluc2VydCh7XG4gICAgICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICAgICAgb3JnOiBNZXRlb3IudXNlcigpLm9yZ2FuaXphdGlvbixcbiAgICAgICAgICAgIG1vbnRoOiBtb250aCxcbiAgICAgICAgICAgIGRheTogZGF5LFxuICAgICAgICAgICAgeWVhcjogeWVhcixcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZSxcbiAgICAgICAgICAgIHRpbWU6IHRpbWUsXG4gICAgICAgICAgICBpbXBvcnRhbmNlOiBpbXBvcnRhbmNlLFxuICAgICAgICAgICAgY3JlYXRlZEJ5OiB0aGlzLnVzZXJJZFxuICAgICAgICB9KVxuICAgIH0sXG4gICAgZGVsZXRlRXZlbnQ6IGZ1bmN0aW9uKGV2ZW50SWQpe1xuICAgICAgICBFdmVudHMucmVtb3ZlKHtfaWQ6IGV2ZW50SWR9KVxuICAgIH0sXG59KTtcblxuLy9TZXJ2ZXIgTWV0aG9kc1xuZnVuY3Rpb24gYWRkVXNlclRvUm9sZXModWlkLCByb2xlcyl7XG4gICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVpZCwgcm9sZXMpO1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6IHVpZCB9LCB7ICRzZXQ6IHsgcm9sZTogUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHVpZClbMF0gfX0pO1xufVxuXG5mdW5jdGlvbiByZW1vdmVVc2VyRnJvbVJvbGVzKHVpZCwgcm9sZXMpe1xuICAgIFJvbGVzLnJlbW92ZVVzZXJzRnJvbVJvbGVzKHVpZCwgcm9sZXMpO1xuICAgIE1ldGVvci51c2Vycy51cGRhdGUoeyBfaWQ6IHVpZCB9LCB7ICRzZXQ6IHsgcm9sZTogUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHVpZClbMF0gfX0pO1xufVxuXG5mdW5jdGlvbiBzZXJ2ZXJDb25zb2xlKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBkaXNwID0gWyhuZXcgRGF0ZSgpKS50b1N0cmluZygpXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFyZ3MubGVuZ3RoOyArK2kpIHtcbiAgICAgIGRpc3AucHVzaChhcmdzW2ldKTtcbiAgICB9XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWludmFsaWQtdGhpc1xuICAgIGNvbnNvbGUubG9nLmFwcGx5KHRoaXMsIGRpc3ApO1xufVxuXG5mdW5jdGlvbiBnZXRJbnZpdGVJbmZvKGludml0ZUNvZGUpIHtcbiAgICBzdXBlcnZpc29yID0gTWV0ZW9yLnVzZXJzLmZpbmRPbmUoe3N1cGVydmlzb3JJbnZpdGVDb2RlOiBpbnZpdGVDb2RlfSk7XG4gICAgdGFyZ2V0U3VwZXJ2aXNvcklkID0gc3VwZXJ2aXNvci5faWQ7XG4gICAgb3JnYW5pemF0aW9uID0gT3Jncy5maW5kT25lKHtfaWQ6IHN1cGVydmlzb3Iub3JnYW5pemF0aW9ufSk7XG4gICAgdGFyZ2V0U3VwZXJ2aXNvck5hbWUgPSBzdXBlcnZpc29yLmZpcnN0bmFtZSArIFwiIFwiICsgc3VwZXJ2aXNvci5sYXN0bmFtZTtcbiAgICB0YXJnZXRPcmdJZCA9IHN1cGVydmlzb3Iub3JnYW5pemF0aW9uO1xuICAgIHRhcmdldE9yZ05hbWUgPSBvcmdhbml6YXRpb24ub3JnTmFtZTtcbiAgICBjb25zb2xlLmxvZyh0YXJnZXRPcmdJZCx0YXJnZXRPcmdOYW1lLHRhcmdldFN1cGVydmlzb3JJZCx0YXJnZXRTdXBlcnZpc29yTmFtZSk7XG4gICAgcmV0dXJuIHt0YXJnZXRPcmdJZCwgdGFyZ2V0T3JnTmFtZSwgdGFyZ2V0U3VwZXJ2aXNvcklkLCB0YXJnZXRTdXBlcnZpc29yTmFtZX07XG59XG5cbi8vUHVibGljYXRpb25zIGFuZCBNb25nbyBBY2Nlc3MgQ29udHJvbFxuTWV0ZW9yLnVzZXJzLmRlbnkoe1xuICAgIHVwZGF0ZSgpIHsgcmV0dXJuIHRydWU7IH1cbn0pO1xuXG5NZXRlb3IudXNlcnMuYWxsb3coe1xuXG59KTtcblxuLy9TaG93IGN1cnJlbnQgdXNlciBkYXRhIGZvciBjdXJyZW50IHVzZXJcbk1ldGVvci5wdWJsaXNoKG51bGwsIGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7X2lkOiB0aGlzLnVzZXJJZH0pO1xufSk7XG5cbi8vUHVibGlzaCBjdXJyZW50IGFzc2Vzc21lbnQgaW5mb3JtYXRpb25cbk1ldGVvci5wdWJsaXNoKCdjdXJBc3Nlc3NtZW50JywgZnVuY3Rpb24oaWQpIHtcbiAgICByZXR1cm4gQXNzZXNzbWVudHMuZmluZCh7X2lkOiBpZH0pO1xufSk7XG5cbi8vYWxsb3cgYWRtaW5zIHRvIHNlZSBhbGwgdXNlcnMgb2Ygb3JnLCBDYW4gb25seSBzZWUgZW1haWxzIG9mIHVzZXJzLiBDYW4gU2VlIGZ1bGwgZGF0YSBvZiBzdXBlcnZpc29yc1xuTWV0ZW9yLnB1Ymxpc2goJ2dldFVzZXJzSW5PcmcnLCBmdW5jdGlvbigpIHtcbiAgICBpZihSb2xlcy51c2VySXNJblJvbGUodGhpcy51c2VySWQsICdhZG1pbicgKSl7IFxuICAgICAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoeyBvcmdhbml6YXRpb246IE1ldGVvci51c2VyKCkub3JnYW5pemF0aW9uLCByb2xlOiAndXNlcicgfSk7XG4gICAgfVxuICAgIGVsc2UgaWYoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnc3VwZXJ2aXNvcicpKXtcbiAgICAgICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHsgb3JnYW5pemF0aW9uOiBNZXRlb3IudXNlcigpLm9yZ2FuaXphdGlvbiwgcm9sZTogJ3VzZXInLCBzdXBlcnZpc29yOiB0aGlzLnVzZXJJZH0pXG4gICAgfVxufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdnZXRTdXBlcnZpc29yc0luT3JnJywgZnVuY3Rpb24oKSB7XG4gICAgaWYoUm9sZXMudXNlcklzSW5Sb2xlKHRoaXMudXNlcklkLCAnYWRtaW4nKSl7XG4gICAgICAgIHJldHVybiBNZXRlb3IudXNlcnMuZmluZCh7IG9yZ2FuaXphdGlvbjogTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb24sIHJvbGU6ICdzdXBlcnZpc29yJyB9KTtcbiAgICB9XG59KTtcblxuLy9BbGxvdyB1c2VycyBhY2Nlc3MgdG8gT3JnIGluZm9ybWF0aW9uXG5NZXRlb3IucHVibGlzaChudWxsLCBmdW5jdGlvbigpIHtcbiAgICBpZihNZXRlb3IudXNlcigpKXtcbiAgICAgICAgcmV0dXJuIE9yZ3MuZmluZCh7X2lkOiBNZXRlb3IudXNlcigpLm9yZ2FuaXphdGlvbn0pO1xuICAgIH1cbn0pO1xuXG4vL2FsbG93IHRoZSB1c2Ugb2YgUm9sZXMudXNlcklzSW5Sb2xlKCkgYWNjb3JzcyBjbGllbnRcbk1ldGVvci5wdWJsaXNoKG51bGwsIGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy51c2VySWQpIHtcbiAgICAgICAgcmV0dXJuIE1ldGVvci5yb2xlQXNzaWdubWVudC5maW5kKHsgJ3VzZXIuX2lkJzogdGhpcy51c2VySWQgfSk7XG4gICAgfSBcbiAgICBlbHNlIHtcbiAgICAgICAgdGhpcy5yZWFkeSgpXG4gICAgfVxufSk7XG4vL2FsbG93IGFzc2Vzc21lbnRzIHRvIGJlIHB1Ymxpc2hlZFxuTWV0ZW9yLnB1Ymxpc2goJ2Fzc2Vzc21lbnRzJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBBc3Nlc3NtZW50cy5maW5kKHt9KTtcbn0pO1xuXG4vL2FsbG93IGN1cnJlbnQgdXNlcnMgdHJpYWwgZGF0YSB0byBiZSBwdWJsaXNoZWRcbk1ldGVvci5wdWJsaXNoKCd1c2VydHJpYWxzJywgZnVuY3Rpb24gKCkge1xuICAgIGlmKFJvbGVzLnVzZXJJc0luUm9sZSh0aGlzLnVzZXJJZCwgWydhZG1pbicsICdzdXBlcnZpc29yJ10pKVxuICAgICAgICByZXR1cm4gVHJpYWxzLmZpbmQoKTtcbiAgICByZXR1cm4gVHJpYWxzLmZpbmQoeyd1c2VySWQnOiB0aGlzLnVzZXJJZH0pO1xufSk7XG5cbi8vYWxsb3cgY3VyXG4vL2FsbG93IGN1cnJlbnQgbW9kdWxlIHBhZ2VzIHRvIGJlIHB1Ymxpc2hlZFxuTWV0ZW9yLnB1Ymxpc2goJ2N1ck1vZHVsZScsIGZ1bmN0aW9uIChpZCkge1xuICAgIHJldHVybiBNb2R1bGVzLmZpbmQoe19pZDogaWR9KTtcbn0pO1xuLy9hbGxvdyBhbGwgbW9kdWxlcyB0byBiZSBzZWVuXG5NZXRlb3IucHVibGlzaCgnbW9kdWxlcycsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gTW9kdWxlcy5maW5kKHt9KTtcbn0pO1xuLy9nZXQgbW9kdWxlIHJlc3VsdHNcbk1ldGVvci5wdWJsaXNoKCdnZXRVc2VyTW9kdWxlUmVzdWx0cycsIGZ1bmN0aW9uIChpZCkge1xuICAgIHJldHVybiBNb2R1bGVSZXN1bHRzLmZpbmQoe30pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdnZXRNb2R1bGVSZXN1bHRzQnlUcmlhbElkJywgZnVuY3Rpb24gKGlkKSB7XG4gICAgcmV0dXJuIE1vZHVsZVJlc3VsdHMuZmluZCh7X2lkOiBpZH0pO1xufSk7XG5cbi8vZ2V0IG15IGV2ZW50c1xuTWV0ZW9yLnB1Ymxpc2gobnVsbCwgZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIEV2ZW50cy5maW5kKHtjcmVhdGVkQnk6IHRoaXMudXNlcklkfSk7XG59KTtcblxuLy9nZXQgYWxsIG9yZ2FuaXphdGlvbiBldmVudHNcbk1ldGVvci5wdWJsaXNoKCdldmVudHMnLCBmdW5jdGlvbigpIHtcbiAgICBjb25zb2xlLmxvZyhNZXRlb3IudXNlcigpLm9yZ2FuaXphdGlvbiwgdGhpcy51c2VySWQpXG4gICAgaWYoTWV0ZW9yLnVzZXIoKSl7XG4gICAgICAgIHJldHVybiBFdmVudHMuZmluZCh7JG9yOiBbeyAkYW5kOiBbe29yZzogTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb259LHtjcmVhdGVkQnk6IHRoaXMudXNlcklkfV19LHskYW5kOlt7Y3JlYXRlZEJ5OiBNZXRlb3IudXNlcigpLnN1cGVydmlzb3J9LHt0eXBlOlwiU3VwZXJ2aXNvciBHcm91cFwifV19LHskYW5kOiBbe29yZzogTWV0ZW9yLnVzZXIoKS5vcmdhbml6YXRpb259LHt0eXBlOiBcIkFsbCBPcmdhbml6YXRpb25cIn1dfSx7dHlwZTp0aGlzLnVzZXJJZH1dfSwge3NvcnQ6IHt5ZWFyOjEgLCBtb250aDoxLCBkYXk6MSwgdGltZToxfX0pXG4gICAgfVxufSk7Il19
